import os
import shutil
import subprocess
import zipfile
import time
import stat
import logging
from PySide6.QtCore import QObject, Signal

from .constants import DEFAULT_EXCLUDE_DIRS, SETUP_VENV_BAT
from .utils import safe_archive_name, setup_venv_path, timestamp

logger = logging.getLogger("JA_SMART_BK.logic")


class BackupRunner(QObject):
    log_received = Signal(str)
    progress_updated = Signal(int)
    finished = Signal(bool, str)

    def __init__(self):
        super().__init__()
        self._stop_requested = False

    def request_stop(self):
        self._stop_requested = True

    def start_backup(self, config):
        self._stop_requested = False
        project_dirs = config.get("project_dirs")
        if not project_dirs:
            project_dirs = [config.get("project_dir")]
            
        selected_files_by_proj = config.get("selected_files_by_proj") or {}
        success_count = 0
        total_projects = len(project_dirs)
        last_archive_path = ""
        
        try:
            for idx, proj_dir in enumerate(project_dirs, 1):
                if self._stop_requested:
                    self.log_received.emit("\n[INFO] Backup cancelled by user.\n")
                    break
                    
                if not proj_dir:
                    continue
                    
                self.log_received.emit(f"\n--- [{idx}/{total_projects}] BACKING UP: {proj_dir} ---\n")
                
                proj_config = {
                    "project_dir": proj_dir,
                    "output_dir": config["output_dir"],
                    "format": config["format"],
                    "compression_level": config["compression_level"],
                    "ensure_setup_venv": config["ensure_setup_venv"],
                    "autodelete": config.get("autodelete", False),
                }
                
                if selected_files_by_proj:
                    if proj_dir in selected_files_by_proj:
                        proj_config["selected_files"] = selected_files_by_proj[proj_dir]
                    else:
                        self.log_received.emit(f"[INFO] Skipping {proj_dir} (unchecked in tree).\n")
                        continue
                
                def scaled_progress(val):
                    overall_val = int(((idx - 1) * 100 + val) / total_projects)
                    self.progress_updated.emit(overall_val)
                    
                archive_path = run_backup(
                    proj_config,
                    log_callback=self.log_received.emit,
                    progress_callback=scaled_progress,
                    stop_check=lambda: self._stop_requested,
                )
                success_count += 1
                last_archive_path = archive_path
                
            if success_count == total_projects and total_projects > 0:
                self.finished.emit(True, last_archive_path if total_projects == 1 else config["output_dir"])
            elif success_count > 0:
                self.finished.emit(True, config["output_dir"])
            else:
                self.finished.emit(False, "")
        except Exception as exc:
            logger.exception("Backup runner failed")
            self.log_received.emit(f"[ERROR] {exc}\n")
            self.finished.emit(False, "")


def robust_rmtree(path, max_retries=5, delay=0.1):
    import sys
    
    def force_delete(func, p, excinfo):
        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except Exception:
            pass

    if os.path.isdir(path):
        for root, dirs, files in os.walk(path, topdown=False):
            for name in files:
                filepath = os.path.join(root, name)
                try:
                    os.chmod(filepath, stat.S_IWRITE)
                except Exception:
                    pass
            for name in dirs:
                dirpath = os.path.join(root, name)
                try:
                    os.chmod(dirpath, stat.S_IWRITE)
                except Exception:
                    pass
        try:
            os.chmod(path, stat.S_IWRITE)
        except Exception:
            pass

    for attempt in range(max_retries):
        try:
            if os.path.isdir(path):
                if sys.version_info >= (3, 12):
                    def on_exc(func, p, exc):
                        try:
                            os.chmod(p, stat.S_IWRITE)
                            func(p)
                        except Exception:
                            pass
                    shutil.rmtree(path, onexc=on_exc)
                else:
                    shutil.rmtree(path, onerror=force_delete)
            else:
                os.chmod(path, stat.S_IWRITE)
                os.remove(path)
            return
        except Exception as e:
            if attempt == max_retries - 1:
                raise e
            time.sleep(delay * (2 ** attempt))


def run_backup(config, log_callback=None, progress_callback=None, stop_check=None):
    source_path = os.path.abspath(config["project_dir"])
    output_dir = os.path.abspath(config["output_dir"])
    fmt = config.get("format", "zip").lower()
    level = int(config.get("compression_level", 5))
    ensure_setup = bool(config.get("ensure_setup_venv", True))
    selected_files = config.get("selected_files")

    if not os.path.exists(source_path):
        raise FileNotFoundError(f"Source not found: {source_path}")

    os.makedirs(output_dir, exist_ok=True)

    is_file_backup = os.path.isfile(source_path)
    archive_root = os.path.dirname(source_path) if is_file_backup else source_path

    if ensure_setup and not is_file_backup:
        ensure_setup_venv(source_path, log_callback)

    if selected_files is not None:
        files = []
        for rel_path in selected_files:
            full_path = os.path.abspath(os.path.join(archive_root, rel_path))
            if os.path.exists(full_path) and os.path.isfile(full_path):
                files.append((full_path, rel_path))
    else:
        files = collect_backup_files(source_path)
    if not files:
        raise RuntimeError("No files found to backup.")

    archive_base = f"{safe_archive_name(source_path)}_{timestamp()}"
    if fmt == "7z" and not find_7z():
        if log_callback:
            log_callback("[WARNING] 7-Zip not found. Falling back to ZIP format.\n")
        fmt = "zip"
    archive_path = os.path.join(output_dir, f"{archive_base}.{fmt}")

    if log_callback:
        log_callback(f"[INFO] Source: {source_path}\n")
        log_callback(f"[INFO] Output: {archive_path}\n")
        if is_file_backup:
            log_callback("[INFO] File backup mode.\n")
        else:
            log_callback("[INFO] Excluding .venv\\Lib, logs, and cache/build folders.\n")
        log_callback(f"[INFO] Files queued: {len(files)}\n")

    if fmt == "zip":
        create_zip(archive_root, archive_path, files, level, log_callback, progress_callback, stop_check)
    elif fmt == "7z":
        create_7z(archive_root, archive_path, files, level, log_callback, progress_callback, stop_check)
    else:
        raise ValueError(f"Unsupported format: {fmt}")

    if progress_callback:
        progress_callback(100)
    if log_callback:
        log_callback("[OK] Backup completed.\n")

    if config.get("autodelete"):
        try:
            robust_rmtree(source_path)
            if log_callback:
                log_callback(f"[INFO] Auto-deleted source: {source_path}\n")
            logger.info("Auto-deleted source successfully: %s", source_path)
        except Exception as exc:
            logger.exception("Failed to auto-delete source %s", source_path)
            if log_callback:
                log_callback(f"[WARNING] Failed to auto-delete source {source_path}: {exc}\n")

    return archive_path


def ensure_setup_venv(project_dir, log_callback=None):
    if not os.path.isdir(os.path.join(project_dir, ".venv")):
        return

    path = setup_venv_path(project_dir)
    if os.path.exists(path):
        if log_callback:
            log_callback("[OK] setup_venv.bat already exists.\n")
        return

    with open(path, "w", encoding="utf-8", newline="\r\n") as file:
        file.write(SETUP_VENV_BAT)
    if log_callback:
        log_callback("[OK] Created setup_venv.bat for restoring .venv\\Lib.\n")


def collect_backup_files(project_dir):
    if os.path.isfile(project_dir):
        return [(project_dir, os.path.basename(project_dir))]

    files = []
    for root, dirs, names in os.walk(project_dir):
        dirs[:] = [
            d for d in dirs
            if not should_skip_dir(project_dir, os.path.join(root, d))
        ]
        for name in names:
            full_path = os.path.join(root, name)
            rel_path = os.path.relpath(full_path, project_dir)
            if should_skip_file(rel_path):
                continue
            files.append((full_path, rel_path))
    return files


def should_skip_dir(project_dir, path):
    rel = os.path.relpath(path, project_dir).replace("/", "\\")
    parts = rel.split("\\")
    if len(parts) >= 2 and parts[0].lower() == ".venv" and parts[1].lower() == "lib":
        return True
    return os.path.basename(path) in DEFAULT_EXCLUDE_DIRS


def should_skip_file(rel_path):
    lower = rel_path.replace("/", "\\").lower()
    return lower.endswith((".pyc", ".pyo", ".log"))


def create_zip(project_dir, archive_path, files, level, log_callback, progress_callback, stop_check):
    compression = zipfile.ZIP_DEFLATED if level > 0 else zipfile.ZIP_STORED
    kwargs = {"compression": compression}
    if compression == zipfile.ZIP_DEFLATED:
        kwargs["compresslevel"] = max(1, min(level, 9))

    with zipfile.ZipFile(archive_path, "w", **kwargs) as zf:
        total = len(files)
        for index, (full_path, rel_path) in enumerate(files, start=1):
            if stop_check and stop_check():
                raise RuntimeError("Backup cancelled by user.")
            zf.write(full_path, rel_path)
            if log_callback and (index == 1 or index % 25 == 0 or index == total):
                log_callback(f"[ZIP] {index}/{total}: {rel_path}\n")
            if progress_callback:
                progress_callback(int(index * 100 / total))


def find_7z():
    # 1. Try finding in PATH
    seven_zip = shutil.which("7z") or shutil.which("7za")
    if seven_zip:
        return seven_zip
        
    # 2. Try looking in Windows registry
    if os.name == 'nt':
        try:
            import winreg
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                try:
                    with winreg.OpenKey(hive, r"Software\7-Zip") as key:
                        val, _ = winreg.QueryValueEx(key, "Path")
                        if val:
                            candidate = os.path.join(val, "7z.exe")
                            if os.path.exists(candidate):
                                return candidate
                            candidate_a = os.path.join(val, "7za.exe")
                            if os.path.exists(candidate_a):
                                return candidate_a
                except Exception:
                    pass
        except Exception:
            pass

        # 3. Check common folder paths on Windows
        common_paths = [
            os.path.join(os.environ.get("ProgramFiles", "C:\\Program Files"), "7-Zip", "7z.exe"),
            os.path.join(os.environ.get("ProgramW6432", "C:\\Program Files"), "7-Zip", "7z.exe"),
            os.path.join(os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)"), "7-Zip", "7z.exe"),
        ]
        for path in common_paths:
            if os.path.exists(path):
                return path
                
    return None


def create_7z(project_dir, archive_path, files, level, log_callback, progress_callback, stop_check):
    seven_zip = find_7z()
    if not seven_zip:
        raise RuntimeError("7-Zip not found. Install 7-Zip or use ZIP format.")

    list_file = os.path.join(os.path.dirname(archive_path), f"__ja_smart_bk_{os.getpid()}.lst")
    try:
        with open(list_file, "w", encoding="utf-8") as file:
            for _, rel_path in files:
                file.write(rel_path + "\n")

        cmd = [
            seven_zip,
            "a",
            "-t7z",
            f"-mx={max(0, min(level, 9))}",
            archive_path,
            f"@{list_file}",
        ]
        if log_callback:
            log_callback("[7Z] Running external 7-Zip compressor.\n")

        process = subprocess.Popen(
            cmd,
            cwd=project_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        while True:
            if stop_check and stop_check():
                process.terminate()
                raise RuntimeError("Backup cancelled by user.")
            line = process.stdout.readline()
            if line:
                if log_callback:
                    log_callback(line)
            elif process.poll() is not None:
                break

        if process.returncode != 0:
            raise RuntimeError(f"7-Zip failed with exit code {process.returncode}.")
        if progress_callback:
            progress_callback(100)
    finally:
        if os.path.exists(list_file):
            os.remove(list_file)
