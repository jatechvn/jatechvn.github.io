# 🤖 JA_SMART_BK

<p align="center">
  <br>
  <i>**JA_SMART_BK** — это приложение, разработанное на Python.</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=flat-square&logo=python" alt="Python Version">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square" alt="License">
</p>

<p align="center"><a href="#quick-start">🚀 Quick Start</a> • <a href="#features">💡 Features</a> • <a href="#setup">📖 Setup</a> • <a href="https://jatechvn.github.io/">🌐 Website</a></p>

<p align="center"><a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="README.zh-CN.md">🇨🇳 中文</a> • <a href="README.ja-JP.md">🇯🇵 日本語</a> • <a href="README.es.md">🇪🇸 Español</a> • <a href="README.fr.md">🇫🇷 Français</a> • <a href="README.de.md">🇩🇪 Deutsch</a> • 🇷🇺 Русский • <a href="README.pt.md">🇵🇹 Português</a> • <a href="README.ko.md">🇰🇷 한국어</a></p>

---

<a id="introduction"></a>
## Описание проекта

Проект стандартизирован в соответствии с профессиональной структурой проекта и поддерживает эффективное управление исходным кодом с помощью Git.

<a id="features"></a>
## Ключевые возможности

- Быстрая настройка и профессиональная упаковка.
- Легковесная конфигурация, простота поддержки и расширения.
- Автоматизированный процесс отправки изменений в Git с помощью встроенного скрипта.

---

## Структура каталогов

```text
JA_SMART_BK/
├── main.py                    # Точка входа в приложение
├── run.bat                    # Скрипт запуска для Windows
├── requirements.txt           # Список зависимостей
├── config.ini                 # Простой файл конфигурации
├── config.json                # Файл конфигурации JSON
├── .gitignore                 # Файл исключений Git
├── README.md                  # Документация проекта (этот файл)
├── LICENSE                    # Файл лицензии
├── ABOUT.txt                  # Краткое описание проекта
├── git_push.bat               # Скрипт автоотправки кода на GitHub
│
├── logs/                      # Журналы работы приложения
│
├── modules/                   # Основные модули с бизнес-логикой
│   ├── ui/                    # User Interface package
│   │   ├── __init__.py        # UI package marker
│   │   ├── main_window.py     # Main window interface
│   │   ├── styles.py          # UI stylesheet & styling
│   │   └── dialogs.py         # Popup dialogs (optional)
│   ├── native/                # Hybrid core engine package
│   │   ├── __init__.py        # Native core package marker
│   │   ├── win_core.py        # Windows optimized core (PowerShell/C++)
│   │   ├── mac_core.py        # macOS optimized core
│   │   └── linux_core.py      # Linux optimized core
│   ├── native_bridge.py       # Dynamic routing bridge to active OS core
│   ├── logic.py               # Core logic / Business rules
│   ├── utils.py               # Shared helper functions
│   ├── constants.py           # Global constants
│   └── logger_config.py       # Logger configuration
│
└── assets/                    # Статические ресурсы приложения
```

---

<a id="setup"></a>
## Руководство по установке и запуску

### Системные требования
*   Операционная система: **Windows 10/11**
*   Интерпретатор: **Python 3.13** или соответствующая среда.

<a id="quick-start"></a>
### Запуск
1. Установите необходимые зависимости:
   ```cmd
   pip install -r requirements.txt
   ```
2. Запустите приложение:
   ```cmd
   run.bat
   ```

---

## Лицензия

Этот проект распространяется под **лицензией MIT**. Подробности см. в файле [LICENSE](LICENSE).
