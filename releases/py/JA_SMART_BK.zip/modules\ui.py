import os
import threading
import darkdetect
from PySide6.QtCore import Qt, QPoint, QTimer
from PySide6.QtGui import QColor, QFont, QTextCursor, QCursor, QAction
from PySide6.QtWidgets import (
    QCheckBox,
    QFileDialog,
    QFrame,
    QGraphicsDropShadowEffect,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSlider,
    QTextEdit,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from BlurWindow.blurWindow import GlobalBlur

from .constants import *
from .logic import BackupRunner, should_skip_dir, should_skip_file, find_7z
from .utils import default_output_dir, load_app_settings, save_app_settings
from .translation import TRANSLATIONS


class LanguageHoverButton(QPushButton):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_app = parent
        self.menu = QMenu(self)
        self.menu.setWindowFlags(self.menu.windowFlags() | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.menu.setAttribute(Qt.WA_TranslucentBackground)
        
        self.timer = QTimer(self)
        self.timer.setInterval(100)
        self.timer.timeout.connect(self.check_mouse_position)
        
        self.menu.aboutToHide.connect(self.on_menu_hide)
        self.setup_menu()

    def setup_menu(self):
        self.act_eng = QAction("English (ENG)", self)
        self.act_cn = QAction("中文 (CN)", self)
        self.act_vi = QAction("Tiếng Việt (VI)", self)
        
        self.menu.addAction(self.act_eng)
        self.menu.addAction(self.act_cn)
        self.menu.addAction(self.act_vi)
        
        self.act_eng.triggered.connect(lambda: self.parent_app.change_language("ENG"))
        self.act_cn.triggered.connect(lambda: self.parent_app.change_language("CN"))
        self.act_vi.triggered.connect(lambda: self.parent_app.change_language("VI"))

    def on_menu_hide(self):
        self.setProperty("menuOpen", False)
        self.style().unpolish(self)
        self.style().polish(self)

    def enterEvent(self, event):
        super().enterEvent(event)
        if self.menu and not self.menu.isVisible():
            pos = self.mapToGlobal(self.rect().bottomLeft())
            self.menu.popup(pos)
            self.timer.start()
            self.setProperty("menuOpen", True)
            self.style().unpolish(self)
            self.style().polish(self)

    def check_mouse_position(self):
        if not self.menu or not self.menu.isVisible():
            self.timer.stop()
            return
            
        cursor_pos = QCursor.pos()
        
        btn_rect = self.rect()
        btn_global_topleft = self.mapToGlobal(btn_rect.topLeft())
        btn_global_rect = btn_rect.translated(btn_global_topleft)
        
        menu_rect = self.menu.rect()
        menu_global_topleft = self.menu.mapToGlobal(menu_rect.topLeft())
        menu_global_rect = menu_rect.translated(menu_global_topleft)
        
        btn_global_rect = btn_global_rect.adjusted(-10, -10, 10, 10)
        menu_global_rect = menu_global_rect.adjusted(-10, -10, 10, 10)
        
        if not btn_global_rect.contains(cursor_pos) and not menu_global_rect.contains(cursor_pos):
            self.menu.close()
            self.timer.stop()


class SourceBrowseWidget(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_app = parent
        self.setMouseTracking(True)
        self.setObjectName("SourceBrowseWidget")
        
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(4)
        
        self.btn_folder = QPushButton("📁")
        self.btn_folder.setFixedSize(30, 30)
        self.btn_folder.setProperty("iconBtn", True)
        self.btn_folder.clicked.connect(self.parent_app.browse_project_folder)
        
        self.btn_file = QPushButton("📄")
        self.btn_file.setFixedSize(30, 30)
        self.btn_file.setProperty("iconBtn", True)
        self.btn_file.clicked.connect(self.parent_app.browse_project_file)
        self.btn_file.setVisible(False)
        
        self.layout.addWidget(self.btn_file)
        self.layout.addWidget(self.btn_folder)
        
        self.setFixedSize(30, 30)
        
    def enterEvent(self, event):
        super().enterEvent(event)
        self.btn_file.setVisible(True)
        self.setFixedSize(64, 30)
        
    def leaveEvent(self, event):
        super().leaveEvent(event)
        self.btn_file.setVisible(False)
        self.setFixedSize(30, 30)


class SmartBackupApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(DEFAULT_WIDTH, DEFAULT_HEIGHT)
        self.is_dark = darkdetect.isDark()
        self._drag_pos = QPoint()
        self.worker_thread = None
        self.settings = load_app_settings()

        self.current_lang = self.settings.get("language", "ENG")
        if self.current_lang not in ("ENG", "CN", "VI"):
            self.current_lang = "ENG"
        self.is_compact = self.settings.get("is_compact", True)
        self.autodelete_active = self.settings.get("autodelete", False)
        self.current_format = self.settings.get("format", "zip")
        self.backup_state = "idle"

        self.setAcceptDrops(True)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.WindowMinMaxButtonsHint | Qt.WindowSystemMenuHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.runner = BackupRunner()
        self.runner.log_received.connect(self.append_log)
        self.runner.progress_updated.connect(self.update_progress)
        self.runner.finished.connect(self.on_backup_finished)

        self.init_ui()
        self.apply_theme()

    def init_ui(self):
        self.central_widget = QFrame()
        self.central_widget.setObjectName("CentralWidget")
        self.setCentralWidget(self.central_widget)

        self.main_layout = QVBoxLayout(self.central_widget)
        self.main_layout.setContentsMargins(20, 15, 20, 20)
        self.main_layout.setSpacing(14)

        title_bar = QHBoxLayout()
        self.close_btn = QPushButton("")
        self.close_btn.setObjectName("CloseBtn")
        self.close_btn.setFixedSize(16, 16)
        self.close_btn.clicked.connect(self.close)

        self.min_btn = QPushButton("")
        self.min_btn.setObjectName("MinBtn")
        self.min_btn.setFixedSize(16, 16)
        self.min_btn.clicked.connect(self.showMinimized)

        self.max_btn = QPushButton("")
        self.max_btn.setObjectName("MaxBtn")
        self.max_btn.setFixedSize(16, 16)
        self.max_btn.clicked.connect(self.toggle_maximize)

        title_bar.addWidget(self.close_btn)
        title_bar.addSpacing(2)
        title_bar.addWidget(self.min_btn)
        title_bar.addSpacing(2)
        title_bar.addWidget(self.max_btn)
        title_bar.addSpacing(15)

        self.lbl_title = QLabel("")
        self.add_shadow(self.lbl_title)
        title_bar.addWidget(self.lbl_title)
        title_bar.addStretch()

        self.btn_autodelete = QPushButton()
        self.btn_autodelete.setFixedSize(30, 30)
        self.btn_autodelete.setProperty("iconBtn", True)
        self.btn_autodelete.setProperty("active", self.autodelete_active)
        self.btn_autodelete.clicked.connect(self.toggle_autodelete)
        title_bar.addWidget(self.btn_autodelete)

        self.btn_format = QPushButton()
        self.btn_format.setFixedSize(65, 30)
        self.btn_format.setProperty("iconBtn", True)
        self.btn_format.clicked.connect(self.toggle_format)
        title_bar.addWidget(self.btn_format)

        self.btn_lang = LanguageHoverButton(self)
        self.btn_lang.setFixedSize(30, 30)
        self.btn_lang.setProperty("iconBtn", True)
        title_bar.addWidget(self.btn_lang)

        self.btn_theme = QPushButton()
        self.btn_theme.setFixedSize(30, 30)
        self.btn_theme.setProperty("iconBtn", True)
        self.btn_theme.clicked.connect(self.toggle_theme)
        title_bar.addWidget(self.btn_theme)

        self.btn_compact = QPushButton()
        self.btn_compact.setFixedSize(30, 30)
        self.btn_compact.setProperty("iconBtn", True)
        self.btn_compact.clicked.connect(self.toggle_compact_mode)
        title_bar.addWidget(self.btn_compact)

        self.main_layout.addLayout(title_bar)

        split_layout = QHBoxLayout()
        split_layout.setSpacing(20)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area.setFrameShape(QFrame.NoFrame)
        self.scroll_area.setStyleSheet("QScrollArea { background: transparent; }")

        left_widget = QWidget()
        left_widget.setStyleSheet("background: transparent;")
        self.left_layout = QVBoxLayout(left_widget)
        self.left_layout.setContentsMargins(0, 0, 10, 0)
        self.left_layout.setSpacing(14)

        self.grp_project = QGroupBox("")
        project_layout = QVBoxLayout(self.grp_project)

        self.lbl_src_label = QLabel("")
        project_layout.addWidget(self.lbl_src_label)
        h_project = QHBoxLayout()
        self.txt_project = QLineEdit(self.settings.get("project_dir", ""))
        self.txt_project.setPlaceholderText("")
        
        self.btn_browse_src = SourceBrowseWidget(self)
        
        
        h_project.addWidget(self.txt_project)
        h_project.addWidget(self.btn_browse_src)
        project_layout.addLayout(h_project)

        self.lbl_out_label = QLabel("")
        project_layout.addWidget(self.lbl_out_label)
        h_output = QHBoxLayout()
        self.txt_output = QLineEdit(self.settings.get("output_dir") or default_output_dir())
        
        self.btn_browse_output = QPushButton("")
        self.btn_browse_output.setFixedSize(30, 30)
        self.btn_browse_output.setProperty("iconBtn", True)
        self.btn_browse_output.clicked.connect(self.browse_output)
        
        h_output.addWidget(self.txt_output)
        h_output.addWidget(self.btn_browse_output)
        project_layout.addLayout(h_output)

        self.left_layout.addWidget(self.grp_project)

        # File Selection Tree Group
        self.grp_files = QGroupBox("")
        files_layout = QVBoxLayout(self.grp_files)
        self.tree_files = QTreeWidget()
        self.tree_files.setHeaderHidden(True)
        self.tree_files.setFixedHeight(220)
        self.tree_files.itemChanged.connect(self.on_tree_item_changed)
        files_layout.addWidget(self.tree_files)
        self.left_layout.addWidget(self.grp_files)

        self.txt_project.textChanged.connect(self.on_project_path_changed)
        self.txt_output.textChanged.connect(self.on_output_path_changed)

        # Compression controls directly in left_layout
        self.lbl_level = QLabel("")
        self.slider_level = QSlider(Qt.Horizontal)
        self.slider_level.setRange(0, 9)
        self.slider_level.setValue(max(0, min(int(self.settings.get("compression_level", 5)), 9)))
        self.slider_level.valueChanged.connect(self.on_level_changed)
        
        self.chk_setup_venv = QCheckBox("")
        self.chk_setup_venv.setChecked(True)
        self.chk_exclude_lib = QCheckBox("")
        self.chk_exclude_lib.setChecked(True)
        self.chk_exclude_lib.setEnabled(False)

        self.left_layout.addWidget(self.lbl_level)
        self.left_layout.addWidget(self.slider_level)
        self.left_layout.addWidget(self.chk_setup_venv)
        self.left_layout.addWidget(self.chk_exclude_lib)

        self.grp_note = QGroupBox("")
        note_layout = QVBoxLayout(self.grp_note)
        self.lbl_note = QLabel("")
        self.lbl_note.setWordWrap(True)
        note_layout.addWidget(self.lbl_note)
        self.left_layout.addWidget(self.grp_note)
        self.left_layout.addStretch()

        self.scroll_area.setWidget(left_widget)
        split_layout.addWidget(self.scroll_area, 4)

        self.right_widget = QWidget()
        self.right_widget.setStyleSheet("background: transparent;")
        right_panel = QVBoxLayout(self.right_widget)
        right_panel.setContentsMargins(0, 0, 0, 0)
        right_panel.setSpacing(12)
        
        self.lbl_console = QLabel("")
        self.lbl_console.setObjectName("ConsoleLabel")
        self.add_shadow(self.lbl_console)
        right_panel.addWidget(self.lbl_console)

        h_console = QHBoxLayout()
        h_console.addStretch()
        self.btn_clear_console = QPushButton("")
        self.btn_clear_console.clicked.connect(self.txt_console_clear)
        h_console.addWidget(self.btn_clear_console)
        right_panel.addLayout(h_console)

        self.txt_console = QTextEdit()
        self.txt_console.setReadOnly(True)
        self.txt_console.setPlaceholderText("")
        right_panel.addWidget(self.txt_console)
        
        split_layout.addWidget(self.right_widget, 5)
        self.main_layout.addLayout(split_layout)

        self.lbl_status = QLabel("")
        self.main_layout.addWidget(self.lbl_status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(5)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.main_layout.addWidget(self.progress_bar)

        self.btn_backup = QPushButton("")
        self.btn_backup.setObjectName("BuildBtn")
        self.btn_backup.setFixedHeight(52)
        self.btn_backup.setFont(QFont(FONT_PRIMARY, 12, QFont.Bold))
        self.btn_backup.clicked.connect(self.start_backup)
        self.add_shadow(self.btn_backup)
        self.main_layout.addWidget(self.btn_backup)

        self.retranslate_ui()
        self.apply_compact_mode()
        self.populate_file_tree(self.txt_project.text().strip())

    def get_translation(self, key, **kwargs):
        lang = self.current_lang
        if lang not in TRANSLATIONS:
            lang = "ENG"
        text = TRANSLATIONS[lang].get(key, "")
        if kwargs:
            return text.format(**kwargs)
        return text

    def retranslate_ui(self):
        if self.is_compact:
            self.btn_lang.setText("🌐")
            self.btn_autodelete.setText("🗑️")
            self.btn_theme.setText("🌙" if self.is_dark else "☀️")
            self.btn_compact.setText("↗")
            self.btn_autodelete.setToolTip(
                self.get_translation("tooltip_autodelete") + 
                f" ({self.get_translation('btn_autodelete_on') if self.autodelete_active else self.get_translation('btn_autodelete_off')})"
            )
        else:
            self.btn_lang.setText(self.current_lang)
            self.btn_autodelete.setText(
                self.get_translation("btn_autodelete_on") if self.autodelete_active else self.get_translation("btn_autodelete_off")
            )
            self.btn_theme.setText(self.get_translation("theme_dark" if self.is_dark else "theme_light"))
            self.btn_compact.setText(self.get_translation("btn_compact_collapse"))
            self.btn_autodelete.setToolTip(self.get_translation("tooltip_autodelete"))

        self.btn_lang.setToolTip(f"Language: {self.current_lang}")
        
        self.btn_format.setText(f"{self.current_format.upper()} 📦")
        self.btn_format.setToolTip(f"Compression format: {self.current_format.upper()}")
        
        self.btn_theme.setToolTip(self.get_translation("theme_dark" if self.is_dark else "theme_light"))
        self.btn_compact.setToolTip("Collapse UI" if not self.is_compact else "Expand UI")

        if self.is_compact:
            self.lbl_title.setText("JA BACKUP")
        else:
            self.lbl_title.setText(self.get_translation("title"))
            
        self.grp_project.setTitle(self.get_translation("cfg_group"))
        self.grp_files.setTitle(self.get_translation("files_group"))
        self.lbl_src_label.setText(self.get_translation("src_label"))
        self.txt_project.setPlaceholderText(self.get_translation("src_placeholder"))
        
        self.btn_browse_src.btn_folder.setToolTip(self.get_translation("btn_folder"))
        self.btn_browse_src.btn_file.setToolTip(self.get_translation("btn_file"))
        
        self.lbl_out_label.setText(self.get_translation("out_label"))
        self.txt_output.setPlaceholderText(self.get_translation("out_label"))
        
        self.btn_browse_output.setText("📂")
        self.btn_browse_output.setToolTip(self.get_translation("btn_browse"))
        
        self.on_level_changed(self.slider_level.value())
        self.chk_setup_venv.setText(self.get_translation("chk_venv"))
        self.chk_exclude_lib.setText(self.get_translation("chk_exclude"))
        self.grp_note.setTitle(self.get_translation("note_group"))
        self.lbl_note.setText(self.get_translation("note_text"))
        self.lbl_console.setText(self.get_translation("console_title"))
        self.btn_clear_console.setText(self.get_translation("btn_clear"))
        self.txt_console.setPlaceholderText(self.get_translation("console_placeholder"))

        if self.backup_state == "idle":
            self.lbl_status.setText(self.get_translation("status_idle"))
        elif self.backup_state == "running":
            self.lbl_status.setText(self.get_translation("status_running"))
        elif self.backup_state == "success":
            self.lbl_status.setText(self.get_translation("status_success"))
        elif self.backup_state == "failed":
            self.lbl_status.setText(self.get_translation("status_failed"))

        if self.btn_backup.isEnabled():
            self.btn_backup.setText(self.get_translation("btn_backup"))
        else:
            self.btn_backup.setText(self.get_translation("btn_backup_running"))

    def change_language(self, lang_code):
        self.current_lang = lang_code
        self.save_current_settings()
        self.retranslate_ui()

    def toggle_compact_mode(self):
        self.is_compact = not self.is_compact
        self.save_current_settings()
        self.apply_compact_mode()

    def apply_compact_mode(self):
        if self.is_compact:
            self.right_widget.setVisible(False)
            self.grp_files.setVisible(False)
            self.grp_note.setVisible(False)
            self.btn_backup.setVisible(False)
            
            self.lbl_src_label.setVisible(False)
            self.lbl_out_label.setVisible(False)
            self.lbl_level.setVisible(False)
            self.slider_level.setVisible(False)
            self.chk_setup_venv.setVisible(False)
            self.chk_exclude_lib.setVisible(False)
            
            self.main_layout.setContentsMargins(12, 10, 12, 12)
            self.main_layout.setSpacing(6)
            self.left_layout.setSpacing(6)
            self.left_layout.setContentsMargins(0, 0, 0, 0)
            
            self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            
            self.setMinimumSize(450, 200)
            self.setMaximumSize(450, 200)
            self.resize(450, 200)
            self.max_btn.setEnabled(False)
            self.max_btn.setVisible(False)
            
            self.grp_project.setProperty("compact", True)
            self.grp_project.setTitle("")
            
            self.btn_lang.setFixedSize(30, 30)
            self.btn_autodelete.setFixedSize(30, 30)
            self.btn_theme.setFixedSize(30, 30)
            self.btn_compact.setFixedSize(30, 30)
        else:
            self.lbl_src_label.setVisible(True)
            self.lbl_out_label.setVisible(True)
            self.lbl_level.setVisible(True)
            self.slider_level.setVisible(True)
            self.chk_setup_venv.setVisible(True)
            self.chk_exclude_lib.setVisible(True)
            
            self.grp_files.setVisible(True)
            self.grp_note.setVisible(True)
            self.btn_backup.setVisible(True)
            self.right_widget.setVisible(True)
            
            self.main_layout.setContentsMargins(20, 15, 20, 20)
            self.main_layout.setSpacing(14)
            self.left_layout.setSpacing(14)
            self.left_layout.setContentsMargins(0, 0, 10, 0)
            
            self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            
            self.setMinimumSize(DEFAULT_WIDTH, DEFAULT_HEIGHT)
            self.setMaximumSize(16777215, 16777215)
            self.resize(DEFAULT_WIDTH, DEFAULT_HEIGHT)
            self.max_btn.setEnabled(True)
            self.max_btn.setVisible(True)
            
            self.grp_project.setProperty("compact", False)
            self.grp_project.setTitle(self.get_translation("cfg_group"))
            
            self.btn_lang.setFixedSize(50, 30)
            self.btn_autodelete.setFixedSize(120, 30)
            self.btn_theme.setFixedSize(80, 30)
            self.btn_compact.setFixedSize(110, 30)
            
        self.grp_project.style().unpolish(self.grp_project)
        self.grp_project.style().polish(self.grp_project)
        self.retranslate_ui()

    def auto_start_backup_compact(self):
        self.slider_level.setValue(9)
        self.start_backup()

    def on_project_path_changed(self, text):
        self.txt_project.setToolTip(text)
        QTimer.singleShot(50, lambda: self.txt_project.setCursorPosition(len(text)))
        self.populate_file_tree(text)

    def on_output_path_changed(self, text):
        self.txt_output.setToolTip(text)
        QTimer.singleShot(50, lambda: self.txt_output.setCursorPosition(len(text)))

    def toggle_format(self):
        self.current_format = "7z" if self.current_format == "zip" else "zip"
        self.save_current_settings()
        self.retranslate_ui()

    def on_tree_item_changed(self, item, column):
        try:
            self.tree_files.itemChanged.disconnect(self.on_tree_item_changed)
        except Exception:
            pass
        try:
            state = item.checkState(0)
            self.set_children_check_state(item, state)
            self.update_parent_check_state(item)
        finally:
            try:
                self.tree_files.itemChanged.connect(self.on_tree_item_changed)
            except Exception:
                pass

    def set_children_check_state(self, item, state):
        for i in range(item.childCount()):
            child = item.child(i)
            child.setCheckState(0, state)
            self.set_children_check_state(child, state)

    def update_parent_check_state(self, item):
        parent = item.parent()
        if not parent:
            return
        
        checked_count = 0
        partially_checked_count = 0
        child_count = parent.childCount()
        
        for i in range(child_count):
            child_state = parent.child(i).checkState(0)
            if child_state == Qt.Checked:
                checked_count += 1
            elif child_state == Qt.PartiallyChecked:
                partially_checked_count += 1
                
        if checked_count == child_count:
            parent.setCheckState(0, Qt.Checked)
        elif checked_count > 0 or partially_checked_count > 0:
            parent.setCheckState(0, Qt.PartiallyChecked)
        else:
            parent.setCheckState(0, Qt.Unchecked)
            
        self.update_parent_check_state(parent)

    def populate_file_tree(self, root_path):
        self.tree_files.clear()
        root_path = root_path.strip()
        if not root_path:
            return
            
        try:
            self.tree_files.itemChanged.disconnect(self.on_tree_item_changed)
        except Exception:
            pass
            
        try:
            paths = [p.strip() for p in root_path.split(";") if p.strip()]
            for p_path in paths:
                if not os.path.exists(p_path):
                    continue
                    
                if os.path.isfile(p_path):
                    item = QTreeWidgetItem(self.tree_files)
                    item.setText(0, f"📄 {os.path.basename(p_path)}")
                    item.setCheckState(0, Qt.Checked)
                    item.setData(0, Qt.UserRole, True)
                    item.setData(0, Qt.UserRole + 1, os.path.basename(p_path))
                    item.setData(0, Qt.UserRole + 2, os.path.dirname(p_path))
                    continue
                    
                root_item = QTreeWidgetItem(self.tree_files)
                root_item.setText(0, f"📁 {os.path.basename(p_path)}")
                root_item.setCheckState(0, Qt.Checked)
                root_item.setData(0, Qt.UserRole, False)
                root_item.setData(0, Qt.UserRole + 1, "")
                root_item.setData(0, Qt.UserRole + 2, p_path)
                root_item.setExpanded(True)
                
                dir_items = {"": root_item}
                
                for root, dirs, names in os.walk(p_path):
                    dirs[:] = [d for d in dirs if not should_skip_dir(p_path, os.path.join(root, d))]
                    
                    rel_root = os.path.relpath(root, p_path)
                    if rel_root == ".":
                        rel_root = ""
                    else:
                        rel_root = rel_root.replace("/", "\\")
                        
                    parent_item = dir_items.get(rel_root.replace("\\", "/"))
                    if not parent_item:
                        continue
                        
                    for d in sorted(dirs):
                        rel_d = os.path.join(rel_root, d) if rel_root else d
                        rel_d_key = rel_d.replace("\\", "/")
                        
                        item = QTreeWidgetItem(parent_item)
                        item.setText(0, f"📁 {d}")
                        item.setCheckState(0, Qt.Checked)
                        item.setData(0, Qt.UserRole, False)
                        item.setData(0, Qt.UserRole + 1, rel_d)
                        item.setData(0, Qt.UserRole + 2, p_path)
                        dir_items[rel_d_key] = item
                        
                    for name in sorted(names):
                        rel_f = os.path.join(rel_root, name) if rel_root else name
                        if should_skip_file(rel_f):
                            continue
                            
                        item = QTreeWidgetItem(parent_item)
                        item.setText(0, f"📄 {name}")
                        item.setCheckState(0, Qt.Checked)
                        item.setData(0, Qt.UserRole, True)
                        item.setData(0, Qt.UserRole + 1, rel_f)
                        item.setData(0, Qt.UserRole + 2, p_path)
        finally:
            try:
                self.tree_files.itemChanged.connect(self.on_tree_item_changed)
            except Exception:
                pass

    def get_selected_files(self):
        selected_files_by_proj = {}
        
        def traverse(item):
            state = item.checkState(0)
            if state == Qt.Unchecked:
                return
            is_file = item.data(0, Qt.UserRole)
            rel_path = item.data(0, Qt.UserRole + 1)
            proj_root = item.data(0, Qt.UserRole + 2)
            
            if is_file:
                if proj_root not in selected_files_by_proj:
                    selected_files_by_proj[proj_root] = []
                selected_files_by_proj[proj_root].append(rel_path)
            else:
                for i in range(item.childCount()):
                    traverse(item.child(i))
                    
        for i in range(self.tree_files.topLevelItemCount()):
            traverse(self.tree_files.topLevelItem(i))
            
        return selected_files_by_proj

    def add_shadow(self, widget, color=None, radius=12):
        if color is None:
            color = QColor(0, 0, 0, 160) if self.is_dark else QColor(0, 0, 0, 50)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(radius)
        shadow.setColor(color)
        shadow.setOffset(2, 2)
        widget.setGraphicsEffect(shadow)

    def on_level_changed(self, value):
        labels = {
            0: self.get_translation("lvl_store"),
            1: self.get_translation("lvl_fast"),
            5: self.get_translation("lvl_balanced"),
            9: self.get_translation("lvl_max"),
        }
        label = labels.get(value, str(value))
        self.lbl_level.setText(self.get_translation("lbl_level", label=label))

    def browse_project_folder(self):
        start_dir = self.txt_project.text().strip()
        if start_dir and os.path.isfile(start_dir):
            start_dir = os.path.dirname(start_dir)
        path = QFileDialog.getExistingDirectory(self, self.get_translation("title_browse_proj"), start_dir or "")
        if path:
            self.txt_project.setText(path)
            self.save_current_settings()
            if self.is_compact:
                self.auto_start_backup_compact()

    def browse_project_file(self):
        start_dir = self.txt_project.text().strip()
        if start_dir and os.path.isfile(start_dir):
            start_dir = os.path.dirname(start_dir)
        path, _ = QFileDialog.getOpenFileName(self, self.get_translation("title_browse_file"), start_dir or "")
        if path:
            self.txt_project.setText(path)
            self.save_current_settings()
            if self.is_compact:
                self.auto_start_backup_compact()

    def browse_output(self):
        path = QFileDialog.getExistingDirectory(self, self.get_translation("title_browse_out"), self.txt_output.text().strip() or default_output_dir())
        if path:
            self.txt_output.setText(path)
            self.save_current_settings()

    def start_backup(self):
        project_dir = self.txt_project.text().strip()
        output_dir = self.txt_output.text().strip() or default_output_dir()

        project_dirs = [p.strip() for p in project_dir.split(";") if p.strip()]
        if not project_dirs:
            QMessageBox.critical(self, self.get_translation("err_title"), self.get_translation("err_invalid_path"))
            return

        app_dir = os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        for p_dir in project_dirs:
            if not os.path.exists(p_dir):
                QMessageBox.critical(self, self.get_translation("err_title"), self.get_translation("err_invalid_path") + f"\n({p_dir})")
                return
            if os.path.abspath(p_dir) == app_dir:
                QMessageBox.critical(self, self.get_translation("err_title"), self.get_translation("err_self_backup"))
                return

        current_fmt = self.current_format
        if current_fmt == "7z" and not find_7z():
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle(self.get_translation("msg_7z_missing_title"))
            msg_box.setText(self.get_translation("msg_7z_missing_text"))
            msg_box.setIcon(QMessageBox.Warning)
            
            btn_zip = msg_box.addButton(self.get_translation("btn_use_zip"), QMessageBox.AcceptRole)
            btn_dl = msg_box.addButton(self.get_translation("btn_download_7z"), QMessageBox.RejectRole)
            
            msg_box.setDefaultButton(btn_zip)
            msg_box.exec()
            
            if msg_box.clickedButton() == btn_dl:
                import webbrowser
                webbrowser.open("https://www.7-zip.org/download.html")
                return
            else:
                self.current_format = "zip"
                self.retranslate_ui()
                current_fmt = "zip"

        config = {
            "project_dirs": project_dirs,
            "output_dir": output_dir,
            "format": current_fmt,
            "compression_level": self.slider_level.value(),
            "ensure_setup_venv": self.chk_setup_venv.isChecked(),
            "selected_files_by_proj": self.get_selected_files(),
            "autodelete": self.autodelete_active,
        }
        self.save_current_settings()

        self.txt_console.clear()
        self.progress_bar.setValue(0)
        self.backup_state = "running"
        self.lbl_status.setText(self.get_translation("status_running"))
        self.btn_backup.setEnabled(False)
        self.btn_backup.setText(self.get_translation("btn_backup_running"))

        self.worker_thread = threading.Thread(target=self.runner.start_backup, args=(config,), daemon=True)
        self.worker_thread.start()

    def on_backup_finished(self, success, archive_path):
        self.btn_backup.setEnabled(True)
        self.btn_backup.setText(self.get_translation("btn_backup"))

        if success:
            self.backup_state = "success"
            self.lbl_status.setText(self.get_translation("status_success"))
            self.progress_bar.setValue(100)
            
            if os.path.isdir(archive_path):
                msg = self.get_translation("success_msg_multi").format(archive_path)
                output_dir = archive_path
            else:
                msg = self.get_translation("success_msg").format(archive_path)
                output_dir = os.path.dirname(archive_path)
                
            QMessageBox.information(self, self.get_translation("success_title"), msg)
            if os.path.isdir(output_dir):
                os.startfile(output_dir)
        else:
            self.backup_state = "failed"
            self.lbl_status.setText(self.get_translation("status_failed"))
            self.progress_bar.setValue(0)
            QMessageBox.critical(self, self.get_translation("failed_title"), self.get_translation("failed_msg"))

    def append_log(self, text):
        self.txt_console.moveCursor(QTextCursor.End)
        self.txt_console.insertPlainText(text)
        self.txt_console.verticalScrollBar().setValue(self.txt_console.verticalScrollBar().maximum())

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def txt_console_clear(self):
        self.txt_console.clear()

    def toggle_theme(self):
        self.is_dark = not self.is_dark
        self.apply_theme()

    def toggle_autodelete(self):
        self.autodelete_active = not self.autodelete_active
        self.btn_autodelete.setProperty("active", self.autodelete_active)
        self.btn_autodelete.style().unpolish(self.btn_autodelete)
        self.btn_autodelete.style().polish(self.btn_autodelete)
        self.save_current_settings()
        self.retranslate_ui()

    def toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def apply_theme(self):
        if self.is_dark:
            bg_main = "rgba(18, 18, 18, 0.65)"
            text_main = "#ffffff"
            input_bg = "rgba(0, 0, 0, 0.4)"
            console_bg = "rgba(0, 0, 0, 0.6)"
            border = "rgba(255, 255, 255, 0.15)"
            menu_bg = "rgba(25, 25, 25, 0.95)"
        else:
            bg_main = "rgba(240, 240, 240, 0.75)"
            text_main = "#111111"
            input_bg = "rgba(255, 255, 255, 0.6)"
            console_bg = "rgba(255, 255, 255, 0.5)"
            border = "rgba(0, 0, 0, 0.15)"
            menu_bg = "rgba(245, 245, 245, 0.95)"

        try:
            GlobalBlur(self.winId(), Dark=self.is_dark)
        except Exception:
            pass

        self.central_widget.setStyleSheet(
            f"#CentralWidget {{ background-color: {bg_main}; border: 1px solid {border}; border-radius: 16px; }}"
        )
        self.lbl_title.setStyleSheet(
            f"color: {text_main}; font-family: '{FONT_PRIMARY}'; font-weight: 800; font-size: 13px; letter-spacing: 2px;"
        )
        self.lbl_status.setStyleSheet(
            f"color: {text_main}; font-family: '{FONT_PRIMARY}'; font-weight: bold; font-size: 11px;"
        )

        self.setStyleSheet(f"""
            #SourceBrowseWidget {{
                background: transparent;
                border: none;
            }}
            QGroupBox {{
                color: {text_main};
                font-family: '{FONT_PRIMARY}';
                font-weight: bold;
                font-size: 11px;
                border: 1px solid {border};
                border-radius: 12px;
                margin-top: 10px;
                padding-top: 15px;
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.02);
            }}
            QGroupBox[compact="true"] {{
                margin-top: 2px;
                padding-top: 8px;
                border-radius: 8px;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
            }}
            QLabel {{
                color: {text_main};
                font-family: '{FONT_PRIMARY}';
                font-size: 11px;
                font-weight: 500;
            }}
            QLabel#ConsoleLabel {{
                color: {ACCENT_CYAN};
                font-weight: 800;
                font-size: 11px;
                letter-spacing: 1px;
            }}
            QLineEdit {{
                background-color: {input_bg};
                color: {text_main};
                border: 1px solid {border};
                border-radius: 8px;
                padding: 7px 10px;
                font-family: '{FONT_PRIMARY}';
                font-size: 12px;
            }}
            QLineEdit:focus {{ border: 1px solid {ACCENT_CYAN}; }}
            QCheckBox {{
                color: {text_main};
                font-family: '{FONT_PRIMARY}';
                font-size: 11px;
            }}
            QRadioButton {{
                color: {text_main};
                font-family: '{FONT_PRIMARY}';
                font-size: 11px;
                spacing: 6px;
            }}
            QRadioButton::indicator {{
                width: 14px;
                height: 14px;
                border-radius: 8px;
                border: 2px solid {border};
                background-color: {input_bg};
            }}
            QRadioButton::indicator:checked {{
                border: 2px solid {ACCENT_CYAN};
                background: qradialgradient(
                    cx:0.5, cy:0.5, radius:0.5,
                    fx:0.5, fy:0.5,
                    stop:0.0 {ACCENT_CYAN}, stop:0.4 {ACCENT_CYAN},
                    stop:0.5 transparent, stop:1.0 transparent
                );
            }}
            QRadioButton::indicator:unchecked:hover {{
                border: 2px solid {ACCENT_CYAN};
            }}
            QPushButton {{
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.05);
                color: {text_main};
                border: 1px solid {border};
                border-radius: 8px;
                font-family: '{FONT_PRIMARY}';
                font-weight: bold;
                font-size: 11px;
                padding: 6px 14px;
            }}
            QPushButton[iconBtn="true"] {{
                padding: 0px;
            }}
            QPushButton[active="true"] {{
                background-color: rgba(0, 212, 255, 0.15) !important;
                border: 1px solid {ACCENT_CYAN} !important;
                color: {ACCENT_CYAN} !important;
            }}
            QPushButton:hover, QPushButton[menuOpen="true"] {{
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.15);
                border: 1px solid {ACCENT_CYAN};
            }}
            QMenu {{
                background-color: {menu_bg};
                border: 1px solid {border};
                border-radius: 8px;
                padding: 4px 0px;
            }}
            QMenu::item {{
                color: {text_main};
                font-family: '{FONT_PRIMARY}';
                font-size: 11px;
                font-weight: bold;
                padding: 6px 20px 6px 15px;
                background-color: transparent;
                border-radius: 4px;
                margin: 2px 4px;
            }}
            QMenu::item:selected {{
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')}, 0.1);
                color: {ACCENT_CYAN};
            }}
            QTextEdit {{
                background-color: {console_bg};
                color: {ACCENT_GREEN if self.is_dark else '#0d5c3a'};
                border: 1px solid {border};
                border-radius: 12px;
                font-family: '{FONT_MONO}';
                font-size: 12px;
                padding: 10px;
            }}
            QTreeWidget {{
                background-color: {console_bg};
                border: 1px solid {border};
                border-radius: 12px;
                color: {text_main};
                font-family: '{FONT_PRIMARY}';
                font-size: 11px;
                padding: 8px;
            }}
            QTreeWidget::item {{
                padding: 4px;
                border-radius: 4px;
                color: {text_main};
            }}
            QTreeWidget::item:hover {{
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')}, 0.05);
            }}
            QTreeWidget::item:selected {{
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')}, 0.1);
                color: {ACCENT_CYAN};
            }}
            QProgressBar {{ background: transparent; border: none; }}
            QProgressBar::chunk {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {ACCENT_CYAN}, stop:1 {ACCENT_GREEN});
                border-radius: 2px;
            }}
            QPushButton#BuildBtn {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {ACCENT_CYAN}, stop:1 {ACCENT_GREEN});
                color: black;
                border: none;
                border-radius: 12px;
                font-weight: 800;
                letter-spacing: 1px;
            }}
            QPushButton#BuildBtn:hover {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00ffff, stop:1 #27ffc9);
            }}
            QPushButton#BuildBtn:disabled {{
                background: rgba(120, 120, 120, 0.2);
                color: rgba(255, 255, 255, 0.3);
            }}
            QPushButton#CloseBtn {{
                background-color: {COLOR_CLOSE_NORMAL};
                border: 1px solid {COLOR_CLOSE_BORDER};
                border-radius: 8px;
            }}
            QPushButton#CloseBtn:hover {{ background-color: {COLOR_CLOSE_HOVER}; }}
            QPushButton#MinBtn {{
                background-color: {COLOR_MIN_NORMAL};
                border: 1px solid {COLOR_MIN_BORDER};
                border-radius: 8px;
            }}
            QPushButton#MinBtn:hover {{ background-color: {COLOR_MIN_HOVER}; }}
            QPushButton#MaxBtn {{
                background-color: {COLOR_MAX_NORMAL};
                border: 1px solid {COLOR_MAX_BORDER};
                border-radius: 8px;
            }}
            QPushButton#MaxBtn:hover {{ background-color: {COLOR_MAX_HOVER}; }}
        """)
        self.retranslate_ui()

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if not urls:
            return
        paths = []
        for url in urls:
            path = url.toLocalFile()
            if os.path.exists(path):
                paths.append(path)
        if paths:
            self.txt_project.setText("; ".join(paths))
            self.save_current_settings()
            if self.is_compact:
                self.auto_start_backup_compact()

    def save_current_settings(self):
        save_app_settings({
            "project_dir": self.txt_project.text().strip(),
            "output_dir": self.txt_output.text().strip() or default_output_dir(),
            "format": self.current_format,
            "compression_level": self.slider_level.value(),
            "language": self.current_lang,
            "is_compact": self.is_compact,
            "autodelete": self.autodelete_active,
        })

    def closeEvent(self, event):
        self.save_current_settings()
        super().closeEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self._drag_pos.isNull():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        self._drag_pos = QPoint()
        event.accept()
