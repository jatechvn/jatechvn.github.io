import os
import re
from configparser import ConfigParser
from datetime import datetime


APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_INI = os.path.join(APP_ROOT, "config.ini")


def safe_archive_name(project_path):
    name = os.path.basename(os.path.abspath(project_path.rstrip("\\/"))) or "backup"
    name = re.sub(r'[<>:"/\\|?*]+', "_", name).strip(" .")
    return name or "backup"


def timestamp():
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


def default_output_dir():
    return os.path.join(os.path.expanduser("~"), "Downloads", "JA_SMART_BK")


def setup_venv_path(project_path):
    return os.path.join(project_path, "setup_venv.bat")


def load_app_settings():
    parser = ConfigParser(interpolation=None)
    parser.read(CONFIG_INI, encoding="utf-8")

    project_dir = parser.get("DEFAULT", "project_dir", fallback="")
    output_dir = parser.get("DEFAULT", "output_dir", fallback=default_output_dir())
    fmt = parser.get("DEFAULT", "format", fallback="zip")
    level = _safe_int(parser.get("DEFAULT", "compression_level", fallback="5"), 5)
    lang = parser.get("DEFAULT", "language", fallback="ENG")
    is_compact = parser.getboolean("DEFAULT", "is_compact", fallback=True)
    autodelete = parser.getboolean("DEFAULT", "autodelete", fallback=False)

    return {
        "project_dir": _expand_path(project_dir),
        "output_dir": _expand_path(output_dir),
        "format": fmt.lower(),
        "compression_level": level,
        "language": lang.upper(),
        "is_compact": is_compact,
        "autodelete": autodelete,
    }


def save_app_settings(settings):
    parser = ConfigParser(interpolation=None)
    parser["DEFAULT"] = {
        "project_dir": settings.get("project_dir", ""),
        "output_dir": settings.get("output_dir", default_output_dir()),
        "format": settings.get("format", "zip"),
        "compression_level": str(settings.get("compression_level", 5)),
        "language": settings.get("language", "ENG").upper(),
        "is_compact": str(settings.get("is_compact", True)),
        "autodelete": str(settings.get("autodelete", False)),
    }
    with open(CONFIG_INI, "w", encoding="utf-8") as file:
        parser.write(file)


def _expand_path(path):
    return os.path.expandvars(os.path.expanduser(path or ""))


def _safe_int(value, default):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
