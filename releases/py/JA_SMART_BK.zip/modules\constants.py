# Global Constants for JA Smart Backup

APP_ID = "JA_SMART_BK"
APP_NAME = "JA Smart Backup"
APP_VERSION = "1.0.0"
APP_USER_MODEL_ID = "JohnAlaa.JASmartBackup.1.0"
APP_TITLE = "JA SMART BACKUP - LIQUID GLASS"

DEFAULT_WIDTH = 1050
DEFAULT_HEIGHT = 720

FONT_PRIMARY = "Inter"
FONT_MONO = "Consolas"

ACCENT_CYAN = "#00d4ff"
ACCENT_GREEN = "#00ff9d"
COLOR_CLOSE_NORMAL = "#ff5f56"
COLOR_CLOSE_BORDER = "#e0443e"
COLOR_CLOSE_HOVER = "#ff7b72"
COLOR_MIN_NORMAL = "#ffbd2e"
COLOR_MIN_BORDER = "#dea123"
COLOR_MIN_HOVER = "#ffca52"
COLOR_MAX_NORMAL = "#27c93f"
COLOR_MAX_BORDER = "#1aab29"
COLOR_MAX_HOVER = "#38e04f"

DEFAULT_EXCLUDE_DIRS = {
    "__pycache__",
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "build",
    "dist",
    "logs",
}

SETUP_VENV_BAT = """@echo off
cd /d %~dp0

if not exist ".venv\\Scripts\\python.exe" (
    py -3.13 -m venv .venv
)

call .venv\\Scripts\\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo.
echo [OK] .venv da san sang.
pause
"""
