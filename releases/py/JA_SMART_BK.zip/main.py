import ctypes
import os
import sys

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from modules.constants import APP_NAME, APP_USER_MODEL_ID
from modules.logger_config import setup_logger
from modules.ui import SmartBackupApp


try:
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
except Exception:
    pass


def main():
    logger = setup_logger()
    logger.info("%s starting...", APP_NAME)

    app = QApplication(sys.argv)
    icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "images", "icon.ico")
    if os.path.exists(icon_path):
        app.setWindowIcon(QIcon(icon_path))

    window = SmartBackupApp()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
