# 🔑 License System — Integration Guide

This folder contains the license checker module.
Copy `ja_license_checker.py` and this guide into any Python project.

---

## 📁 What you need in your project

```text
YourSoftware/
└── modules/
    ├── ja_license_checker.py   ← license checker
    └── LICENSE_SETUP.md        ← this guide
```

---

## ✏️ Step 1 — Define `APP_ID` and `APP_NAME` in `main.py`

Set your app identity in **one place** (`main.py`) so other modules can reuse it.

```python
# main.py
APP_ID = "YOUR_APP_ID"
APP_NAME = "Your App Display Name"
APP_USER_MODEL_ID = "YourCompany.YourApp.1.0"  # optional (Windows taskbar identity)
```

### Recommended `APP_ID` format

- Use uppercase letters, numbers, underscores: `MY_TOOL_V1`
- No spaces or special characters
- Keep it stable per product/version
- Case-sensitive: must match exactly with the key generator entry

---

## 🧾 Step 2 — Register app in your key generator

When requesting key issuance, provide these fields:

```json
{
  "id": "YOUR_APP_ID",
  "name": "Your App Display Name",
  "description": "Optional app description"
}
```

A key issued for one `id` will not work for another `id`.

---

## 🔐 Step 3 — Add license check in `main.py`

Use `APP_ID` from `main.py` directly (avoid hard-coded string duplicates):

```python
import sys
from modules.ja_license_checker import check_license

APP_ID = "YOUR_APP_ID"
APP_NAME = "Your App Display Name"

ok, msg = check_license(app_id=APP_ID)
if not ok:
    print(f"[LICENSE ERROR] {msg}")
    sys.exit(1)
```

If using GUI:

```python
import sys
from PySide6.QtWidgets import QApplication, QMessageBox
from modules.ja_license_checker import check_license

APP_ID = "YOUR_APP_ID"

app = QApplication(sys.argv)
ok, msg = check_license(app_id=APP_ID)
if not ok:
    QMessageBox.critical(None, "License Error", msg)
    sys.exit(1)
```

---

## ⚙️ Optional — Use `config.ini`

```python
ok, msg = check_license(
    app_id=APP_ID,
    config_path=r"\\server\share\config.ini"
)
```

`config.ini` format:

```ini
[SECURITY]
secret = YourSecretKeyHere

[SERVER]
key_path = \\SERVER\SHARE\license.key
```

---

## 🔄 Runtime flow

```text
App starts
  ↓
Load/sync key (server → local cache)
  ↓
Decode + verify signature + validate APP_ID + expiry (+ optional HWID)
  ↓
Valid → run app
Invalid/expired → stop and show error
```

---

## ❓ Troubleshooting

| Message | Likely cause | Fix |
|---|---|---|
| No license data found | Missing key on server/local | Place/reissue key |
| Key is for a different software | `APP_ID` mismatch | Ensure exact same `APP_ID` |
| Signature mismatch | Corrupted/tampered key | Reissue fresh key |
| License expired | Expiry date passed | Generate new key |

---

**Important:** Keep this module generic for reuse across projects.
Do not hard-code project-specific names/IDs inside `ja_license_checker.py` usage examples.