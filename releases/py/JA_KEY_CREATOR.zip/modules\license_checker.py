"""
license_checker.py — Module kiểm tra bản quyền dùng chung

Import module này vào BẤT KỲ phần mềm nào trong dự án JA_PROJECT để
kiểm tra key trước khi cho phép chạy.

Cách dùng:
    from modules.license_checker import check_license
    ok, msg = check_license(app_id="SOFT_MONITOR_V1")
    if not ok:
        # Hiện thông báo lỗi và thoát
        ...

Lưu ý:
    - app_id phải khớp đúng với giá trị khi tạo key trong JA Key Creator
    - Nếu dùng key sai app → tự động bị từ chối
"""
import os
import logging
import shutil
import configparser
from datetime import datetime

logger = logging.getLogger(__name__)


def _get_default_paths(config_path: str | None = None):
    """Đọc đường dẫn từ config.ini hoặc dùng mặc định."""
    server_path = r"\\10.81.141.226\temp\FBT\JA_PROJECT\JA_key\license.key"
    secret      = "JohnAlaaSecretKey_2026!@#"

    if config_path and os.path.isfile(config_path):
        cfg = configparser.ConfigParser()
        cfg.read(config_path, encoding="utf-8")
        server_path = cfg.get("SERVER",   "key_path", fallback=server_path)
        secret      = cfg.get("SECURITY", "secret",   fallback=secret)

    local_folder = os.path.join(os.environ.get("APPDATA", "."), "JA_PROJECT")
    local_path   = os.path.join(local_folder, "local_license.key")
    sync_file    = os.path.join(local_folder, "last_sync.txt")
    return server_path, local_path, sync_file, local_folder, secret


def check_license(app_id: str, config_path: str | None = None) -> tuple[bool, str]:
    """
    Kiểm tra bản quyền phần mềm.

    Args:
        app_id      : ID phần mềm, phải khớp với giá trị khi tạo key.
                      VD: "SOFT_MONITOR_V1"
        config_path : Đường dẫn tới file config.ini (tùy chọn)

    Luồng:
        1. Nếu hôm nay chưa đồng bộ → thử copy key từ Server về Local
        2. Đọc và giải mã key từ Local
        3. Kiểm tra app_id có khớp không
        4. So sánh ngày hết hạn với ngày hôm nay

    Returns:
        (True,  "OK")                 — Bản quyền hợp lệ
        (False, "<thông báo lỗi>")   — Bản quyền không hợp lệ
    """
    from modules.logic import KeyGenerator

    server_path, local_path, sync_file, local_folder, secret = _get_default_paths(config_path)
    keygen = KeyGenerator(secret)
    today  = datetime.now().strftime("%Y%m%d")

    # Tạo thư mục local nếu chưa có
    os.makedirs(local_folder, exist_ok=True)

    # --- Đồng bộ từ Server nếu cần ---
    last_sync = ""
    if os.path.isfile(sync_file):
        try:
            with open(sync_file, "r", encoding="utf-8") as f:
                last_sync = f.read().strip()
        except Exception:
            pass

    if last_sync != today:
        if os.path.isfile(server_path):
            try:
                shutil.copy2(server_path, local_path)
                with open(sync_file, "w", encoding="utf-8") as f:
                    f.write(today)
                logger.info(f"License synced from server: {server_path}")
            except Exception as e:
                logger.warning(f"Không sync được từ server: {e} — dùng key local cũ.")
        else:
            logger.warning("Không kết nối được server hoặc file key server không tồn tại. Dùng key local.")

    # --- Kiểm tra file local ---
    if not os.path.isfile(local_path):
        msg = "Không tìm thấy dữ liệu cấp phép. Vui lòng liên hệ Admin để nhận key."
        logger.error(msg)
        return False, msg

    encoded = keygen.read_key_from_path(local_path)
    if not encoded:
        msg = "File bản quyền trống hoặc bị hỏng. Vui lòng liên hệ Admin."
        logger.error(msg)
        return False, msg

    # --- Giải mã và xác thực (kiểm tra cả app_id) ---
    result = keygen.decrypt_key(encoded, expected_app_id=app_id)

    if not result["valid"]:
        msg = result["error"] or "Key không hợp lệ."
        logger.error(f"License invalid: {msg}")
        return False, msg

    if result["expired"]:
        exp = result["expiry_date"]
        msg = f"Phần mềm đã hết hạn sử dụng (Ngày hết hạn: {exp[:4]}-{exp[4:6]}-{exp[6:]}).\nVui lòng liên hệ Admin để gia hạn."
        logger.error(msg)
        return False, msg

    exp = result["expiry_date"]
    logger.info(f"License OK — app={app_id} expires {exp[:4]}-{exp[4:6]}-{exp[6:]}")
    return True, f"Bản quyền hợp lệ (App: {app_id} | Hết hạn: {exp[:4]}-{exp[4:6]}-{exp[6:]})"
