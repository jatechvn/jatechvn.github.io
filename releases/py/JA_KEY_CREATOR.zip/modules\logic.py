"""
logic.py — KeyGenerator: mã hóa/giải mã key bản quyền cho JA Key Creator

Thuật toán:
    1. Tạo payload: "YYYYMMDD:APP_ID" (ngăn cách bằng ':')
    2. XOR từng ký tự payload với SecretPassword
    3. Thêm HMAC-SHA256 signature (chống giả mạo)
    4. Kết hợp payload + signature rồi Base64 encode → ra chuỗi key cuối cùng

Định dạng raw trước Base64:
    <HEX_XOR_payload>|<HMAC_HEX>

    Trong đó HEX_XOR_payload là XOR của chuỗi "YYYYMMDD:APP_ID"
"""
import os
import hmac
import hashlib
import base64
import shutil
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

_SEP = "|"  # ký tự phân cách payload | hmac


class KeyGenerator:
    def __init__(self, secret_password: str):
        self.secret = secret_password.encode("utf-8")

    # ------------------------------------------------------------------ #
    #  XOR helpers (tương thích với thuật toán AHK gốc)                   #
    # ------------------------------------------------------------------ #
    def _xor_hex(self, text: str) -> str:
        """Mã hóa chuỗi text bằng XOR với secret, trả về chuỗi HEX."""
        result = []
        secret_str = self.secret.decode("utf-8")
        for i, ch in enumerate(text):
            char_code = ord(ch)
            pass_char  = ord(secret_str[i % len(secret_str)])
            result.append(f"{char_code ^ pass_char:02X}")
        return "".join(result)

    def _xor_decrypt(self, hex_str: str) -> str:
        """Giải mã chuỗi HEX trở về text gốc."""
        secret_str = self.secret.decode("utf-8")
        chars = []
        for i in range(len(hex_str) // 2):
            byte_val  = int(hex_str[2*i : 2*i+2], 16)
            pass_char = ord(secret_str[i % len(secret_str)])
            chars.append(chr(byte_val ^ pass_char))
        return "".join(chars)

    # ------------------------------------------------------------------ #
    #  HMAC signature                                                       #
    # ------------------------------------------------------------------ #
    def _sign(self, payload: str) -> str:
        return hmac.new(self.secret, payload.encode("utf-8"), hashlib.sha256).hexdigest()

    def _verify_signature(self, payload: str, sig: str) -> bool:
        expected = self._sign(payload)
        return hmac.compare_digest(expected, sig)

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #
    def encrypt_key(self, expiry_date: str, app_id: str, hwid: str = "") -> str:
        """
        Mã hóa ngày hết hạn + app_id + hwid thành chuỗi key Base64 an toàn.

        Args:
            expiry_date : Chuỗi YYYYMMDD, VD: "20261231"
            app_id      : ID phần mềm, VD: "SOFT_MONITOR_V1"
            hwid        : Mã máy duy nhất của user (tuỳ chọn)

        Returns:
            Chuỗi Base64 sẵn sàng ghi vào license.key
        """
        inner = f"{expiry_date}:{app_id}:{hwid.strip()}"
        hex_payload = self._xor_hex(inner)
        signature   = self._sign(hex_payload)
        raw         = f"{hex_payload}{_SEP}{signature}"
        encoded     = base64.b64encode(raw.encode("utf-8")).decode("utf-8")
        logger.info(f"Key encrypted → expiry={expiry_date}, app_id={app_id}, hwid={hwid or '-'}, payload_len={len(raw)}")
        return encoded

    def decrypt_key(self, encoded: str, expected_app_id: str | None = None) -> dict:
        """
        Giải mã chuỗi key và xác thực chữ ký + app_id + hwid.

        Args:
            encoded         : Chuỗi key Base64
            expected_app_id : Nếu truyền vào, kiểm tra app_id trong key phải khớp

        Returns:
            dict với các trường thông tin giải mã.
        """
        result = {"valid": False, "expired": True, "expiry_date": None, "app_id": None, "hwid": "", "error": None}
        try:
            raw = base64.b64decode(encoded.encode("utf-8")).decode("utf-8")
            if _SEP not in raw:
                result["error"] = "Định dạng key không hợp lệ (thiếu separator)."
                return result
            payload, signature = raw.rsplit(_SEP, 1)

            if not self._verify_signature(payload, signature):
                result["error"] = "Chữ ký HMAC không khớp — key có thể đã bị giả mạo!"
                return result

            inner = self._xor_decrypt(payload)

            # Phân tách YYYYMMDD:APP_ID:HWID
            if ":" not in inner:
                result["error"] = "Key không chứa App ID — đây là key cũ không còn hợp lệ."
                return result

            parts = inner.split(":", 2)
            expiry_date = parts[0]
            app_id_in_key = parts[1]
            hwid_in_key = parts[2] if len(parts) > 2 else ""

            if len(expiry_date) != 8 or not expiry_date.isdigit():
                result["error"] = f"Nội dung key giải mã không hợp lệ: '{expiry_date}'"
                return result

            # Kiểm tra app_id nếu có yêu cầu
            if expected_app_id and app_id_in_key != expected_app_id:
                result["error"] = (
                    f"Key này dành cho phần mềm '{app_id_in_key}', "
                    f"không dùng được cho '{expected_app_id}'."
                )
                result["app_id"] = app_id_in_key
                return result

            today = datetime.now().strftime("%Y%m%d")
            result["valid"]       = True
            result["expiry_date"] = expiry_date
            result["app_id"]      = app_id_in_key
            result["hwid"]        = hwid_in_key
            result["expired"]     = expiry_date < today
            logger.info(f"Key decrypted → expiry={expiry_date}, app_id={app_id_in_key}, hwid={hwid_in_key or '-'}, today={today}, expired={result['expired']}")
        except Exception as e:
            result["error"] = f"Lỗi giải mã: {e}"
            logger.exception("decrypt_key error")
        return result

    # ------------------------------------------------------------------ #
    #  File I/O                                                            #
    # ------------------------------------------------------------------ #
    def write_key_to_path(self, key: str, path: str) -> bool:
        """Ghi chuỗi key ra file (hỗ trợ cả đường dẫn local lẫn network share)."""
        try:
            parent = os.path.dirname(path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(key)
            logger.info(f"Key written to: {path}")
            return True
        except PermissionError:
            logger.error(f"Không có quyền ghi vào: {path}")
            raise
        except OSError as e:
            logger.error(f"Lỗi ghi file ({path}): {e}")
            raise

    def read_key_from_path(self, path: str) -> str | None:
        """Đọc chuỗi key từ file."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read().strip()
        except FileNotFoundError:
            logger.warning(f"Không tìm thấy file key: {path}")
            return None
        except Exception as e:
            logger.error(f"Lỗi đọc file key ({path}): {e}")
            return None
