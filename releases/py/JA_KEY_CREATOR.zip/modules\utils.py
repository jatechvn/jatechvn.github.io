"""
utils.py — Hàm tiện ích dùng chung cho JA Key Creator
"""
import os
import logging
from modules.constants import LOGS_DIR, ASSETS_DIR, IMAGES_DIR, TEMP_DIR, KEYS_DIR

logger = logging.getLogger(__name__)


def ensure_project_dirs():
    """Tạo đầy đủ cây thư mục cần thiết nếu chưa tồn tại."""
    for d in [LOGS_DIR, ASSETS_DIR, IMAGES_DIR, TEMP_DIR, KEYS_DIR]:
        os.makedirs(d, exist_ok=True)
    logger.debug("Project directories verified/created.")


def copy_to_clipboard(text: str):
    """Sao chép text vào clipboard hệ thống (dùng PySide6)."""
    try:
        from PySide6.QtWidgets import QApplication
        clipboard = QApplication.clipboard()
        clipboard.setText(text)
        return True
    except Exception as e:
        logger.warning(f"Không thể copy clipboard: {e}")
        return False


def format_key_display(key_str: str, max_len: int = 60) -> str:
    """Rút gọn chuỗi key dài để hiển thị trên UI."""
    if len(key_str) <= max_len:
        return key_str
    return key_str[:max_len] + "..."


def validate_date_str(date_str: str) -> bool:
    """Kiểm tra chuỗi ngày có đúng định dạng YYYYMMDD không."""
    if len(date_str) != 8 or not date_str.isdigit():
        return False
    try:
        from datetime import datetime
        datetime.strptime(date_str, "%Y%m%d")
        return True
    except ValueError:
        return False
