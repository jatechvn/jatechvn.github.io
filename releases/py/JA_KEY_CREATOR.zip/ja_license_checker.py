"""
ja_license_checker.py — File kiểm tra bản quyền STANDALONE
============================================================

CÁCH DÙNG:
    1. Copy file này vào thư mục modules/ của phần mềm bạn muốn bảo vệ.
    2. Trong main.py của phần mềm đó, thêm:

        from modules.ja_license_checker import check_license
        ok, msg = check_license(app_id="TÊN_PHẦN_MỀM_CỦA_BẠN")
        if not ok:
            print(f"[LICENSE ERROR] {msg}")
            sys.exit(1)

    3. app_id phải KHỚP CHÍNH XÁC với ID đã chọn khi tạo key trong JA Key Creator.
       Ví dụ: nếu tạo key cho "SOFT_MONITOR_V1" thì truyền app_id="SOFT_MONITOR_V1".

KHÔNG CẦN cài thêm thư viện — chỉ dùng thư viện chuẩn của Python.

Thuật toán (tương thích với JA Key Creator v1.1+):
    Payload = XOR("YYYYMMDD:APP_ID", secret) → HMAC-SHA256 → Base64
"""
import os
import hmac
import hashlib
import base64
import shutil
import logging
import configparser
from datetime import datetime

logger = logging.getLogger(__name__)

# --- Nhập động PySide6 để hiển thị giao diện Kính Mờ (Liquid Glass) cực đẹp nếu có sẵn ---
HAS_PYSIDE6 = False
try:
    import sys
    from PySide6.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
        QPushButton, QMessageBox, QWidget
    )
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QFont, QColor
    try:
        from BlurWindow.blurWindow import GlobalBlur
        HAS_BLUR = True
    except ImportError:
        HAS_BLUR = False
    import darkdetect
    HAS_PYSIDE6 = True
except ImportError:
    HAS_PYSIDE6 = False

# ─── Cấu hình mặc định (chỉnh nếu cần) ──────────────────────────────────────
# _DEFAULT_SERVER_PATH = r"\\10.81.141.226\temp\FBT\JA_PROJECT\JA_key\license.key"
# _DEFAULT_SECRET      = "LVISecretKey_2026!@#"
# _SEP                 = "|"   # Separator trong raw key (payload|hmac)
# _INNER_SEP           = ":"   # Separator giữa date và app_id
# ─────────────────────────────────────────────────────────────────────────────

_DEFAULT_SERVER_PATH = ""  # Để trống để không tự động đồng bộ từ server
_DEFAULT_SECRET      = "JohnAlaaSecretKey_2026!@#"
_SEP                 = "|"   # Separator trong raw key (payload|hmac)
_INNER_SEP           = ":"   # Separator giữa date và app_id


# ── Key path helper ────────────────────────────────────────────────────────────
def _get_key_paths(app_id: str) -> tuple[str, str, str]:
    """
    Trả về (local_folder, local_path, sync_file) theo app_id.
    Đường dẫn: %APPDATA%\JA_PROJECT\{APP_ID}\
    Đảm bảo mỗi app có thư mục riêng, không xung đột.
    """
    base = os.path.join(os.environ.get("APPDATA", "."), "JA_PROJECT", app_id.upper())
    return base, os.path.join(base, "local_license.key"), os.path.join(base, "last_sync.txt")



# ── Crypto helpers ─────────────────────────────────────────────────────────────

def _xor_hex(text: str, secret: str) -> str:
    """XOR từng ký tự text với secret, trả về chuỗi HEX."""
    return "".join(
        f"{ord(ch) ^ ord(secret[i % len(secret)]):02X}"
        for i, ch in enumerate(text)
    )


def _xor_decrypt(hex_str: str, secret: str) -> str:
    """Giải mã chuỗi HEX trở về text gốc."""
    return "".join(
        chr(int(hex_str[2*i: 2*i+2], 16) ^ ord(secret[i % len(secret)]))
        for i in range(len(hex_str) // 2)
    )


def _sign(payload: str, secret: str) -> str:
    return hmac.new(secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()


def _verify_signature(payload: str, sig: str, secret: str) -> bool:
    return hmac.compare_digest(_sign(payload, secret), sig)


def _decrypt_key(encoded: str, secret: str, expected_app_id: str | None = None) -> dict:
    """
    Giải mã chuỗi key và xác thực chữ ký + app_id + hwid.

    Returns dict:
        valid        (bool)
        expired      (bool)
        expiry_date  (str YYYYMMDD)
        app_id       (str)
        hwid         (str)
        error        (str | None)
    """
    result = {"valid": False, "expired": True, "expiry_date": None, "app_id": None, "hwid": "", "error": None}
    try:
        raw = base64.b64decode(encoded.encode("utf-8")).decode("utf-8")
        if _SEP not in raw:
            result["error"] = "Định dạng key không hợp lệ (thiếu separator)."
            return result

        payload, signature = raw.rsplit(_SEP, 1)
        if not _verify_signature(payload, signature, secret):
            result["error"] = "Chữ ký HMAC không khớp — key có thể đã bị giả mạo!"
            return result

        inner = _xor_decrypt(payload, secret)

        if _INNER_SEP not in inner:
            result["error"] = "Key không chứa App ID — key cũ không còn hợp lệ."
            return result

        parts = inner.split(_INNER_SEP, 2)
        expiry_date = parts[0]
        app_id_in_key = parts[1]
        hwid_in_key = parts[2] if len(parts) > 2 else ""

        if len(expiry_date) != 8 or not expiry_date.isdigit():
            result["error"] = f"Nội dung key giải mã không hợp lệ: '{expiry_date}'"
            return result

        if expected_app_id and app_id_in_key != expected_app_id:
            result["error"] = (
                f"Key này dành cho phần mềm '{app_id_in_key}', "
                f"không dùng được cho '{expected_app_id}'."
            )
            result["app_id"] = app_id_in_key
            return result

        if hwid_in_key:
            current_hwid = get_hwid()
            if hwid_in_key != current_hwid:
                result["error"] = (
                    f"Key này được đăng ký cho máy '{hwid_in_key}', "
                    f"không trùng khớp với mã máy hiện tại của bạn '{current_hwid}'."
                )
                return result

        today = datetime.now().strftime("%Y%m%d")
        result["valid"]       = True
        result["expiry_date"] = expiry_date
        result["app_id"]      = app_id_in_key
        result["hwid"]        = hwid_in_key
        result["expired"]     = expiry_date < today
    except Exception as e:
        result["error"] = f"Lỗi giải mã: {e}"
    return result


def get_hwid() -> str:
    """Lấy Hardware UUID duy nhất của bo mạch chủ trên Windows làm Mã Máy."""
    import subprocess
    try:
        output = subprocess.check_output("wmic csproduct get uuid", shell=True).decode("utf-8")
        uuid = output.split("\n")[1].strip()
        if len(uuid) > 10:
            return uuid
    except Exception:
        pass
    
    try:
        import uuid as _uuid
        return f"MAC-{_uuid.getnode()}"
    except Exception:
        pass
        
    return "UNKNOWN_HWID"


import tkinter as tk
from tkinter import filedialog, messagebox

class KeyInputDialog:
    def __init__(self, prompt_msg: str):
        self.prompt_msg = prompt_msg
        self.key_string = None
        self.file_path = None
        
        self.root = tk.Tk()
        self.root.title("Kích Hoạt Bản Quyền - Activation Required")
        self.root.geometry("520x340")
        self.root.resizable(False, False)
        self.root.attributes("-topmost", True)
        
        # Center the window on screen
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
        
        # Apply clean, modern styling
        self.font_title = ("Segoe UI", 10, "bold")
        self.font_normal = ("Segoe UI", 9)
        self.font_btn = ("Segoe UI", 9, "bold")
        
        self.bg_color = "#f5f6f8"
        self.card_color = "#ffffff"
        self.text_color = "#333333"
        self.border_color = "#dcdfe6"
        
        self.root.configure(bg=self.bg_color)
        
        # Top Header (Error / Prompt Message)
        header_frame = tk.Frame(self.root, bg=self.bg_color, padx=15, pady=10)
        header_frame.pack(fill=tk.X)
        
        lbl_msg = tk.Label(
            header_frame, 
            text=self.prompt_msg, 
            font=self.font_normal, 
            fg="#e6a23c" if "hết hạn" in self.prompt_msg.lower() or "không hợp lệ" in self.prompt_msg.lower() else "#409eff",
            bg=self.bg_color,
            justify=tk.LEFT,
            wraplength=480
        )
        lbl_msg.pack(anchor="w")
        
        # Content Card Frame
        card_frame = tk.Frame(self.root, bg=self.card_color, bd=1, relief=tk.SOLID, highlightbackground=self.border_color)
        card_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=5)
        
        # Inner Frame for padding
        inner_frame = tk.Frame(card_frame, bg=self.card_color, padx=15, pady=12)
        inner_frame.pack(fill=tk.BOTH, expand=True)
        
        # Paste Key Input Section
        lbl_input = tk.Label(
            inner_frame, 
            text="Nhập hoặc dán chuỗi Key bản quyền vào đây:", 
            font=self.font_title, 
            fg=self.text_color,
            bg=self.card_color
        )
        lbl_input.pack(anchor="w", pady=(0, 5))
        
        # Scrollable entry for key
        self.entry_key = tk.Entry(
            inner_frame, 
            font=("Consolas", 10),
            bd=1,
            relief=tk.SOLID,
            bg="#fcfdfd"
        )
        self.entry_key.pack(fill=tk.X, pady=(0, 10), ipady=5)
        self.entry_key.focus_set()
        
        # HWID Section
        hwid_frame = tk.Frame(inner_frame, bg=self.card_color)
        hwid_frame.pack(fill=tk.X, pady=(0, 8))
        
        lbl_hwid_lbl = tk.Label(
            hwid_frame, 
            text="Mã máy của bạn: ", 
            font=("Segoe UI", 9),
            fg=self.text_color,
            bg=self.card_color
        )
        lbl_hwid_lbl.pack(side=tk.LEFT)
        
        self.lbl_hwid_val = tk.Label(
            hwid_frame, 
            text=get_hwid(), 
            font=("Consolas", 9, "bold"),
            fg="#00d4ff",
            bg=self.card_color
        )
        self.lbl_hwid_val.pack(side=tk.LEFT)
        
        self.btn_copy_hwid = tk.Button(
            hwid_frame, 
            text="📋 Copy Mã Máy", 
            font=("Segoe UI", 8, "bold"),
            bg="#00d4ff",
            fg="white",
            relief=tk.FLAT,
            padx=8,
            pady=2,
            command=self._on_copy_hwid
        )
        self.btn_copy_hwid.pack(side=tk.RIGHT)
        
        # Or separator line
        sep_frame = tk.Frame(inner_frame, bg=self.card_color)
        sep_frame.pack(fill=tk.X, pady=(0, 10))
        
        lbl_or = tk.Label(
            sep_frame, 
            text="— HOẶC —", 
            font=("Segoe UI", 8, "italic"),
            fg="#909399",
            bg=self.card_color
        )
        lbl_or.pack()
        
        # Action Buttons Frame
        btn_frame = tk.Frame(inner_frame, bg=self.card_color)
        btn_frame.pack(fill=tk.X)
        
        # File selector button
        self.btn_file = tk.Button(
            btn_frame, 
            text="📂 Chọn File Key...", 
            font=self.font_btn,
            bg="#e6a23c",
            fg="white",
            relief=tk.FLAT,
            padx=12,
            pady=4,
            command=self._on_choose_file
        )
        self.btn_file.pack(side=tk.LEFT)
        
        # Cancel Button
        self.btn_cancel = tk.Button(
            btn_frame, 
            text="Thoát", 
            font=self.font_normal,
            bg="#909399",
            fg="white",
            relief=tk.FLAT,
            padx=12,
            pady=4,
            command=self.root.destroy
        )
        self.btn_cancel.pack(side=tk.RIGHT, padx=(5, 0))
        
        # Submit Button
        self.btn_submit = tk.Button(
            btn_frame, 
            text="✔️ Kích Hoạt", 
            font=self.font_btn,
            bg="#67c23a",
            fg="white",
            relief=tk.FLAT,
            padx=12,
            pady=4,
            command=self._on_submit
        )
        self.btn_submit.pack(side=tk.RIGHT)
        
        self._setup_hover_effects()
        self.root.mainloop()
        
    def _setup_hover_effects(self):
        def on_enter(btn, color): btn.configure(bg=color)
        def on_leave(btn, color): btn.configure(bg=color)
        
        self.btn_file.bind("<Enter>", lambda e: on_enter(self.btn_file, "#d39330"))
        self.btn_file.bind("<Leave>", lambda e: on_leave(self.btn_file, "#e6a23c"))
        self.btn_submit.bind("<Enter>", lambda e: on_enter(self.btn_submit, "#5daf34"))
        self.btn_submit.bind("<Leave>", lambda e: on_leave(self.btn_submit, "#67c23a"))
        self.btn_cancel.bind("<Enter>", lambda e: on_enter(self.btn_cancel, "#82848a"))
        self.btn_cancel.bind("<Leave>", lambda e: on_leave(self.btn_cancel, "#909399"))

    def _on_choose_file(self):
        file_path = filedialog.askopenfilename(
            title="Chọn file License Key",
            filetypes=[("License Key Files", "*.key"), ("All Files", "*.*")]
        )
        if file_path:
            self.file_path = file_path
            self.root.destroy()
            
    def _on_submit(self):
        val = self.entry_key.get().strip()
        if not val:
            messagebox.showwarning("Cảnh Báo", "Vui lòng nhập chuỗi key bản quyền hoặc bấm chọn file key!")
            return
        self.key_string = val
        self.root.destroy()

    def _on_copy_hwid(self):
        self.root.clipboard_clear()
        self.root.clipboard_append(get_hwid())
        self.root.update()
        messagebox.showinfo("Thông báo", "Đã copy mã máy vào bộ nhớ tạm (clipboard)!")


# --- Cửa sổ hiển thị giao diện QDialog PySide6 Kính Mờ Liquid Glass nếu HAS_PYSIDE6 = True ---
if HAS_PYSIDE6:
    class PySideMessageBox(QDialog):
        def __init__(self, title: str, message: str, icon_type: str = "info", parent=None):
            super().__init__(parent)
            self.title_text = title
            self.message_text = message
            self.icon_type = icon_type  # "info", "success", "warning", "error"
            self.is_dark = darkdetect.isDark()
            self.setup_window()
            self.setup_ui()
            self.apply_theme()

        def setup_window(self):
            self.setWindowTitle(self.title_text)
            self.resize(470, 220)
            self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog | Qt.WindowStaysOnTopHint)
            self.setAttribute(Qt.WA_TranslucentBackground)
            if HAS_BLUR:
                GlobalBlur(self.winId(), Dark=self.is_dark, QWidget=self)
            self.old_pos = None

        def mousePressEvent(self, event):
            if event.button() == Qt.LeftButton:
                self.old_pos = event.globalPosition().toPoint()

        def mouseMoveEvent(self, event):
            if self.old_pos:
                delta = event.globalPosition().toPoint() - self.old_pos
                self.move(self.pos() + delta)
                self.old_pos = event.globalPosition().toPoint()

        def mouseReleaseEvent(self, event):
            self.old_pos = None

        def setup_ui(self):
            main_layout = QVBoxLayout(self)
            main_layout.setContentsMargins(10, 10, 10, 10)
            
            self.central_widget = QWidget()
            self.central_widget.setObjectName("CentralWidget")
            main_layout.addWidget(self.central_widget)
            
            layout = QVBoxLayout(self.central_widget)
            layout.setContentsMargins(24, 20, 24, 20)

            # Header
            header = QHBoxLayout()
            icon_str = "ℹ️"
            title_color = "#00d4ff"
            if self.icon_type == "success":
                icon_str = "✔️"
                title_color = "#27c93f"
            elif self.icon_type == "warning":
                icon_str = "⚠️"
                title_color = "#ffbd2e"
            elif self.icon_type == "error":
                icon_str = "❌"
                title_color = "#ff5f56"

            title_lbl = QLabel(f"{icon_str} {self.title_text.upper()}")
            title_lbl.setFont(QFont("Inter", 12, QFont.Bold))
            title_lbl.setStyleSheet(f"color: {title_color};")

            close_btn = QPushButton("X")
            close_btn.setFixedSize(30, 30)
            close_btn.setStyleSheet("""
                QPushButton { background-color: #ff5f56; border-radius: 15px; color: white; font-weight: bold; }
                QPushButton:hover { background-color: #ff7b72; }
            """)
            close_btn.clicked.connect(self.reject)

            header.addWidget(title_lbl)
            header.addStretch()
            header.addWidget(close_btn)
            layout.addLayout(header)

            msg_lbl = QLabel(self.message_text)
            msg_lbl.setFont(QFont("Inter", 10))
            msg_lbl.setWordWrap(True)
            msg_lbl.setStyleSheet("margin-top: 15px; margin-bottom: 15px;")
            layout.addWidget(msg_lbl, 1)

            btn_layout = QHBoxLayout()
            btn_layout.setContentsMargins(0, 10, 0, 0)
            
            self.ok_btn = QPushButton("OK")
            self.ok_btn.setFixedSize(100, 36)
            self.ok_btn.clicked.connect(self.accept)
            
            btn_layout.addStretch()
            btn_layout.addWidget(self.ok_btn)
            layout.addLayout(btn_layout)

        def apply_theme(self):
            bg = "rgba(15, 15, 15, 0.85)" if self.is_dark else "rgba(240, 240, 240, 0.85)"
            text_color = "white" if self.is_dark else "black"
            
            qss = f"""
                QWidget#CentralWidget {{
                    background-color: {bg};
                    border: 1px solid rgba(255, 255, 255, 0.25);
                    border-radius: 20px;
                }}
                QLabel {{
                    font-family: 'Inter', sans-serif;
                    color: {text_color};
                }}
                QPushButton {{
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00d4ff, stop:1 #0056ff);
                    color: white;
                    border-radius: 12px;
                    font-weight: bold;
                    font-family: 'Inter', sans-serif;
                    border: none;
                }}
                QPushButton:hover {{
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00e5ff, stop:1 #0066ff);
                }}
            """
            self.setStyleSheet(qss)

    class PySideKeyInputDialog(QDialog):
        def __init__(self, prompt_msg: str, parent=None):
            super().__init__(parent)
            self.prompt_msg = prompt_msg
            self.key_string = None
            self.file_path = None
            self.is_dark = darkdetect.isDark()
            
            self.setWindowTitle("Kích Hoạt Bản Quyền")
            self.resize(560, 360)
            self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog | Qt.WindowStaysOnTopHint)
            self.setAttribute(Qt.WA_TranslucentBackground)
            
            if HAS_BLUR:
                GlobalBlur(self.winId(), Dark=self.is_dark, QWidget=self)
                
            self.old_pos = None
            self.setup_ui()
            self.apply_theme()
            
        def mousePressEvent(self, event):
            if event.button() == Qt.LeftButton:
                self.old_pos = event.globalPosition().toPoint()
    
        def mouseMoveEvent(self, event):
            if self.old_pos:
                delta = event.globalPosition().toPoint() - self.old_pos
                self.move(self.pos() + delta)
                self.old_pos = event.globalPosition().toPoint()
    
        def mouseReleaseEvent(self, event):
            self.old_pos = None

        def setup_ui(self):
            main_layout = QVBoxLayout(self)
            main_layout.setContentsMargins(10, 10, 10, 10)
            
            self.central_widget = QWidget()
            self.central_widget.setObjectName("CentralWidget")
            main_layout.addWidget(self.central_widget)
            
            layout = QVBoxLayout(self.central_widget)
            layout.setContentsMargins(24, 20, 24, 20)
            
            header = QHBoxLayout()
            
            self.close_btn = QPushButton("X")
            self.close_btn.setFixedSize(30, 30)
            self.close_btn.setStyleSheet("""
                QPushButton { background-color: #ff5f56; border-radius: 15px; color: white; font-weight: bold; }
                QPushButton:hover { background-color: #ff7b72; }
            """)
            self.close_btn.clicked.connect(self.reject)
            
            title = QLabel("🔑 KÍCH HOẠT BẢN QUYỀN")
            title.setFont(QFont("Inter", 14, QFont.Bold))
            title.setStyleSheet("color: #00d4ff;")
            
            header.addWidget(title)
            header.addStretch()
            header.addWidget(self.close_btn)
            layout.addLayout(header)
            
            lbl_msg = QLabel(self.prompt_msg)
            lbl_msg.setFont(QFont("Inter", 10))
            lbl_msg.setWordWrap(True)
            lbl_msg.setStyleSheet("color: #e6a23c; margin-top: 10px; margin-bottom: 10px;")
            layout.addWidget(lbl_msg)
            
            input_row = QHBoxLayout()
            lbl_input = QLabel("Nhập hoặc dán chuỗi Key bản quyền:")
            lbl_input.setFont(QFont("Inter", 10, QFont.Bold))

            self.btn_paste_key = QPushButton("📋 Dán Key")
            self.btn_paste_key.setFixedSize(110, 30)
            self.btn_paste_key.clicked.connect(self._on_paste_key)

            input_row.addWidget(lbl_input)
            input_row.addStretch()
            input_row.addWidget(self.btn_paste_key)
            layout.addLayout(input_row)
            
            self.entry_key = QLineEdit()
            self.entry_key.setPlaceholderText("Dán chuỗi key bản quyền tại đây...")
            self.entry_key.setFont(QFont("Consolas", 10))
            layout.addWidget(self.entry_key)
            
            hwid_layout = QHBoxLayout()
            hwid_layout.setContentsMargins(0, 5, 0, 5)
            
            lbl_hwid = QLabel("Mã máy của bạn: ")
            lbl_hwid.setFont(QFont("Inter", 10))
            
            self.lbl_hwid_val = QLabel(get_hwid())
            self.lbl_hwid_val.setFont(QFont("Consolas", 10, QFont.Bold))
            self.lbl_hwid_val.setStyleSheet("color: #00d4ff;")
            
            self.btn_copy_hwid = QPushButton("📋 Copy Mã Máy")
            self.btn_copy_hwid.setFixedSize(130, 26)
            self.btn_copy_hwid.clicked.connect(self._on_copy_hwid)
            
            hwid_layout.addWidget(lbl_hwid)
            hwid_layout.addWidget(self.lbl_hwid_val)
            hwid_layout.addStretch()
            hwid_layout.addWidget(self.btn_copy_hwid)
            layout.addLayout(hwid_layout)
            
            btn_layout = QHBoxLayout()
            btn_layout.setContentsMargins(0, 15, 0, 0)
            
            self.btn_file = QPushButton("📂 Chọn File Key...")
            self.btn_file.setFixedSize(160, 36)
            self.btn_file.clicked.connect(self._on_choose_file)
            
            self.btn_cancel = QPushButton("Thoát")
            self.btn_cancel.setFixedSize(90, 36)
            self.btn_cancel.clicked.connect(self.reject)
            
            self.btn_submit = QPushButton("✔️ Kích Hoạt")
            self.btn_submit.setFixedSize(130, 36)
            self.btn_submit.clicked.connect(self._on_submit)
            
            btn_layout.addWidget(self.btn_file)
            btn_layout.addStretch()
            btn_layout.addWidget(self.btn_submit)
            btn_layout.addWidget(self.btn_cancel)
            layout.addLayout(btn_layout)

        def apply_theme(self):
            bg = "rgba(15, 15, 15, 0.85)" if self.is_dark else "rgba(240, 240, 240, 0.85)"
            text_color = "white" if self.is_dark else "black"
            border_color = "rgba(255, 255, 255, 0.2)" if self.is_dark else "rgba(0, 0, 0, 0.2)"
            
            qss = f"""
                QWidget#CentralWidget {{
                    background-color: {bg};
                    border: 1px solid rgba(255, 255, 255, 0.25);
                    border-radius: 20px;
                }}
                QLabel {{
                    font-family: 'Inter', sans-serif;
                    color: {text_color};
                }}
                QLineEdit {{
                    background-color: rgba(0, 0, 0, 0.5) if {self.is_dark} else rgba(255, 255, 255, 0.6);
                    color: {text_color};
                    border: 1px solid rgba(255, 255, 255, 0.4) if {self.is_dark} else rgba(0, 0, 0, 0.3);
                    border-radius: 8px;
                    padding: 8px;
                }}
                QPushButton {{
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00d4ff, stop:1 #0056ff);
                    color: white;
                    border-radius: 12px;
                    font-weight: bold;
                    font-family: 'Inter', sans-serif;
                    border: none;
                }}
                QPushButton:hover {{
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00e5ff, stop:1 #0066ff);
                }}
                QPushButton:pressed {{
                    background: #0056ff;
                }}
            """
            self.setStyleSheet(qss)
            
            self.btn_file.setStyleSheet(f"""
                QPushButton {{
                    background: {"rgba(255, 200, 0, 0.2)" if self.is_dark else "rgba(230, 162, 60, 0.2)"};
                    color: {"#ffaa00" if self.is_dark else "#e6a23c"};
                    border: 1px solid {"#ffaa00" if self.is_dark else "#e6a23c"};
                    border-radius: 12px;
                }}
                QPushButton:hover {{
                    background: {"rgba(255, 200, 0, 0.4)" if self.is_dark else "rgba(230, 162, 60, 0.4)"};
                }}
            """)
            
            self.btn_cancel.setStyleSheet(f"""
                QPushButton {{
                    background: {"rgba(255,255,255,0.1)" if self.is_dark else "rgba(0,0,0,0.1)"};
                    color: {text_color};
                    border: 1px solid {border_color};
                    border-radius: 12px;
                }}
                QPushButton:hover {{
                    background: {"rgba(255,255,255,0.2)" if self.is_dark else "rgba(0,0,0,0.15)"};
                }}
            """)
            
            self.btn_copy_hwid.setStyleSheet(f"""
                QPushButton {{
                    background: {"rgba(0, 212, 255, 0.15)" if self.is_dark else "rgba(0, 150, 200, 0.12)"};
                    color: {"#00d4ff" if self.is_dark else "#0088cc"};
                    border: 1px solid {"rgba(0, 212, 255, 0.3)" if self.is_dark else "rgba(0, 150, 200, 0.3)"};
                    border-radius: 8px;
                    font-size: 11px;
                }}
                QPushButton:hover {{
                    background: {"rgba(0, 212, 255, 0.35)" if self.is_dark else "rgba(0, 150, 200, 0.25)"};
                }}
            """)

            self.btn_paste_key.setStyleSheet(f"""
                QPushButton {{
                    background: {"rgba(0, 212, 255, 0.15)" if self.is_dark else "rgba(0, 150, 200, 0.12)"};
                    color: {"#00d4ff" if self.is_dark else "#0088cc"};
                    border: 1px solid {"rgba(0, 212, 255, 0.3)" if self.is_dark else "rgba(0, 150, 200, 0.3)"};
                    border-radius: 8px;
                    font-size: 11px;
                }}
                QPushButton:hover {{
                    background: {"rgba(0, 212, 255, 0.35)" if self.is_dark else "rgba(0, 150, 200, 0.25)"};
                }}
            """)

        def _on_choose_file(self):
            from PySide6.QtWidgets import QFileDialog
            file_path, _ = QFileDialog.getOpenFileName(
                self, "Chọn file License Key", "", "License Key Files (*.key);;All Files (*.*)"
            )
            if file_path:
                self.file_path = file_path
                self.accept()
                
        def _on_submit(self):
            val = self.entry_key.text().strip()
            if not val:
                PySideMessageBox("Cảnh Báo", "Vui lòng nhập chuỗi key bản quyền hoặc bấm chọn file key!", icon_type="warning", parent=self).exec()
                return
            self.key_string = val
            self.accept()

        def _on_copy_hwid(self):
            from PySide6.QtGui import QClipboard
            from PySide6.QtWidgets import QApplication
            clipboard = QApplication.clipboard()
            clipboard.setText(get_hwid())
            PySideMessageBox("Thông báo", "Đã copy mã máy vào bộ nhớ tạm (clipboard)!", icon_type="success", parent=self).exec()

        def _on_paste_key(self):
            from PySide6.QtWidgets import QApplication
            clipboard = QApplication.clipboard()
            pasted = (clipboard.text() or "").strip()
            if not pasted:
                PySideMessageBox("Cảnh Báo", "Clipboard hiện đang trống.", icon_type="warning", parent=self).exec()
                return
            self.entry_key.setText(pasted)


def _select_key_file_gui(prompt_msg: str | None = None) -> tuple[str | None, str | None]:
    """Mở hộp thoại chọn key thủ công bằng chuỗi key dán vào hoặc chọn file."""
    msg = prompt_msg or "Không tìm thấy dữ liệu bản quyền kích hoạt cho phần mềm này."
    
    # Thử dùng PySide6 nếu sẵn có
    if HAS_PYSIDE6:
        try:
            from PySide6.QtWidgets import QApplication
            app = QApplication.instance()
            if not app:
                app = QApplication([])
                
            dialog = PySideKeyInputDialog(msg)
            result = dialog.exec()
            
            if result == QDialog.DialogCode.Accepted:
                return dialog.key_string, dialog.file_path
            else:
                return None, None
        except Exception as e:
            logger.warning(f"Lỗi khi hiển thị giao diện PySide6 bản quyền: {e}. Thử dùng Tkinter fallback...")
            
    # Fallback sang giao diện Tkinter
    try:
        dialog = KeyInputDialog(msg)
        return dialog.key_string, dialog.file_path
    except Exception as e:
        logger.warning(f"Không thể hiển thị hộp thoại bản quyền: {e}")
        return None, None


# ── License check (public API) ─────────────────────────────────────────────────

def check_license(
    app_id: str,
    config_path: str | None = None,
    server_path: str | None = None,
) -> tuple[bool, str]:
    """
    Kiểm tra bản quyền phần mềm.

    Args:
        app_id      : ID phần mềm (PHẢI khớp với ID khi tạo key trong JA Key Creator)
        config_path : Đường dẫn tới config.ini chứa [SECURITY] secret và [SERVER] key_path
        server_path : Đường dẫn server key (ghi đè config nếu truyền vào)

    Returns:
        (True,  "...")  — Bản quyền hợp lệ
        (False, "...")  — Lỗi kèm mô tả chi tiết
    """
    # Đọc config
    _server = server_path or _DEFAULT_SERVER_PATH
    _secret = _DEFAULT_SECRET

    if config_path and os.path.isfile(config_path):
        cfg = configparser.ConfigParser()
        cfg.read(config_path, encoding="utf-8")
        _server = cfg.get("SERVER",   "key_path", fallback=_server)
        _secret = cfg.get("SECURITY", "secret",   fallback=_secret)

    local_folder, local_path, sync_file = _get_key_paths(app_id)
    today        = datetime.now().strftime("%Y%m%d")


    os.makedirs(local_folder, exist_ok=True)

    # --- Đồng bộ từ Server (1 lần/ngày) ---
    last_sync = ""
    if os.path.isfile(sync_file):
        try:
            with open(sync_file, "r", encoding="utf-8") as f:
                last_sync = f.read().strip()
        except Exception:
            pass

    if last_sync != today and os.path.isfile(_server):
        try:
            shutil.copy2(_server, local_path)
            with open(sync_file, "w", encoding="utf-8") as f:
                f.write(today)
            logger.info(f"[JA License] Synced from server: {_server}")
        except Exception as e:
            logger.warning(f"[JA License] Không sync được từ server: {e}")

    # --- Đọc file local ---
    if not os.path.isfile(local_path):
        key_str, chosen_path = _select_key_file_gui()
        if key_str:
            try:
                with open(local_path, "w", encoding="utf-8") as f:
                    f.write(key_str)
                logger.info("[JA License] Đã lưu chuỗi key nhập thủ công.")
            except Exception as e:
                return False, f"Không thể lưu chuỗi key: {e}"
        elif chosen_path and os.path.isfile(chosen_path):
            try:
                shutil.copy2(chosen_path, local_path)
                logger.info(f"[JA License] Đã sao chép key thủ công từ: {chosen_path}")
            except Exception as e:
                return False, f"Không thể copy file key đã chọn: {e}"
        else:
            return False, "Không tìm thấy dữ liệu cấp phép. Vui lòng liên hệ Admin để nhận key."

    try:
        with open(local_path, "r", encoding="utf-8") as f:
            encoded = f.read().strip()
    except Exception as e:
        return False, f"Lỗi đọc file bản quyền: {e}"

    if not encoded:
        return False, "File bản quyền trống hoặc bị hỏng. Vui lòng liên hệ Admin."

    # --- Giải mã và xác thực ---
    result = _decrypt_key(encoded, _secret, expected_app_id=app_id)

    if not result["valid"] or result["expired"]:
        msg = result["error"] or "Key không hợp lệ."
        if result["valid"] and result["expired"]:
            exp = result["expiry_date"]
            msg = (
                f"Phần mềm đã hết hạn sử dụng "
                f"(Ngày hết hạn: {exp[:4]}-{exp[4:6]}-{exp[6:]}).\n"
                f"Vui lòng liên hệ Admin để gia hạn."
            )
        logger.error(f"[JA License] INVALID: {msg}")

        # Cho phép người dùng chọn/nhập file key khác nếu key hiện tại lỗi/hết hạn
        logger.info("Key hiện tại lỗi/hết hạn, gợi ý chọn/nhập key mới...")
        key_str, chosen_path = _select_key_file_gui(
            prompt_msg=f"Lỗi: {msg}"
        )
        if key_str:
            try:
                with open(local_path, "w", encoding="utf-8") as f:
                    f.write(key_str)
                with open(local_path, "r", encoding="utf-8") as f:
                    new_encoded = f.read().strip()
                new_result = _decrypt_key(new_encoded, _secret, expected_app_id=app_id)
                if new_result["valid"] and not new_result["expired"]:
                    exp = new_result["expiry_date"]
                    logger.info(f"[JA License] OK sau khi nạp key mới — app={app_id} expires {exp[:4]}-{exp[4:6]}-{exp[6:]}")
                    return True, f"Kích hoạt thành công! Bản quyền hợp lệ (App: {app_id} | Hết hạn: {exp[:4]}-{exp[4:6]}-{exp[6:]})"
                else:
                    new_msg = new_result["error"] or "Key mới vẫn không hợp lệ."
                    if new_result["valid"] and new_result["expired"]:
                        n_exp = new_result["expiry_date"]
                        new_msg = f"Key mới chọn cũng đã hết hạn ({n_exp[:4]}-{n_exp[4:6]}-{n_exp[6:]})."
                    return False, new_msg
            except Exception as e:
                return False, f"Không thể lưu chuỗi key mới: {e}"
        elif chosen_path and os.path.isfile(chosen_path):
            try:
                shutil.copy2(chosen_path, local_path)
                with open(local_path, "r", encoding="utf-8") as f:
                    new_encoded = f.read().strip()
                new_result = _decrypt_key(new_encoded, _secret, expected_app_id=app_id)
                if new_result["valid"] and not new_result["expired"]:
                    exp = new_result["expiry_date"]
                    logger.info(f"[JA License] OK sau khi chọn lại key — app={app_id} expires {exp[:4]}-{exp[4:6]}-{exp[6:]}")
                    return True, f"Kích hoạt thành công! Bản quyền hợp lệ (App: {app_id} | Hết hạn: {exp[:4]}-{exp[4:6]}-{exp[6:]})"
                else:
                    new_msg = new_result["error"] or "Key mới vẫn không hợp lệ."
                    if new_result["valid"] and new_result["expired"]:
                        n_exp = new_result["expiry_date"]
                        new_msg = f"Key mới chọn cũng đã hết hạn ({n_exp[:4]}-{n_exp[4:6]}-{n_exp[6:]})."
                    return False, new_msg
            except Exception as e:
                return False, f"Không thể copy file key mới: {e}"

        return False, msg

    exp = result["expiry_date"]
    logger.info(f"[JA License] OK — app={app_id} expires {exp[:4]}-{exp[4:6]}-{exp[6:]}")
    return True, f"Bản quyền hợp lệ (App: {app_id} | Hết hạn: {exp[:4]}-{exp[4:6]}-{exp[6:]})"


def get_license_info(app_id: str, config_path: str | None = None) -> dict:
    """
    Đọc và giải mã key bản quyền hiện tại, trả về dict thông tin chi tiết (thời hạn, số ngày còn lại...).
    """
    info = {
        "status": "Chưa kích hoạt",
        "app_id": app_id,
        "expiry_date": None,
        "days_remaining": 0,
        "valid": False,
        "expired": True,
        "error": None
    }
    
    _secret = _DEFAULT_SECRET
    if config_path and os.path.isfile(config_path):
        cfg = configparser.ConfigParser()
        cfg.read(config_path, encoding="utf-8")
        _secret = cfg.get("SECURITY", "secret", fallback=_secret)
        
    local_folder, local_path, _ = _get_key_paths(app_id)

    if not os.path.isfile(local_path):
        info["error"] = "Không tìm thấy file bản quyền local."
        return info
        
    try:
        with open(local_path, "r", encoding="utf-8") as f:
            encoded = f.read().strip()
    except Exception as e:
        info["error"] = f"Lỗi đọc file: {e}"
        return info
        
    if not encoded:
        info["error"] = "File bản quyền trống."
        return info
        
    res = _decrypt_key(encoded, _secret, expected_app_id=app_id)
    info["valid"] = res["valid"]
    info["expired"] = res["expired"]
    info["expiry_date"] = res["expiry_date"]
    info["error"] = res["error"]
    
    if res["valid"]:
        info["app_id"] = res["app_id"]
        try:
            exp_dt = datetime.strptime(res["expiry_date"], "%Y%m%d")
            today_dt = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            delta = exp_dt - today_dt
            info["days_remaining"] = delta.days
            
            if delta.days < 0:
                info["status"] = "Đã hết hạn"
            else:
                info["status"] = "Đang hoạt động"
                info["expired"] = False
        except Exception:
            pass
    else:
        info["status"] = "Key không hợp lệ"
        
    return info


# ── Public helpers cho host app tự vẽ UI ──────────────────────────────────────

def verify_key(encoded: str, app_id: str, config_path: str | None = None) -> dict:
    """
    Xác thực chuỗi key mã hóa (không mở bất kỳ UI nào).

    Dành cho host app muốn tự xây UI và chỉ cần kết quả xác thực.

    Args:
        encoded    : Chuỗi key Base64 cần xác thực.
        app_id     : App ID phải khớp với key.
        config_path: Đường dẫn config.ini chứa [SECURITY] secret (tuỳ chọn).

    Returns:
        dict với các field:
            valid        (bool)
            expired      (bool)
            expiry_date  (str YYYYMMDD | None)
            app_id       (str | None)
            hwid         (str)
            error        (str | None)
    """
    _secret = _DEFAULT_SECRET
    if config_path and os.path.isfile(config_path):
        cfg = configparser.ConfigParser()
        cfg.read(config_path, encoding="utf-8")
        _secret = cfg.get("SECURITY", "secret", fallback=_secret)

    return _decrypt_key(encoded.strip(), _secret, expected_app_id=app_id)


def check_license_silent(
    app_id: str,
    config_path: str | None = None,
    server_path: str | None = None,
) -> tuple[bool, str]:
    """
    Kiểm tra bản quyền HOÀN TOÀN KHÔNG MỞ UI — chỉ trả kết quả.

    Dành cho host app muốn tự xử lý UI khi key chưa có hoặc không hợp lệ.

    Returns:
        (True,  "...")  — Bản quyền hợp lệ
        (False, "...")  — Lỗi kèm mô tả (host app tự xử lý)

    Các trường hợp trả False:
        - File key chưa tồn tại  → "NO_KEY_FILE"  (prefix để host phân biệt)
        - Key hết hạn            → "EXPIRED: ..."
        - Key sai app/hwid/hmac  → "INVALID: ..."
        - Lỗi đọc file           → "READ_ERROR: ..."
    """
    _server = server_path or _DEFAULT_SERVER_PATH
    _secret = _DEFAULT_SECRET

    if config_path and os.path.isfile(config_path):
        cfg = configparser.ConfigParser()
        cfg.read(config_path, encoding="utf-8")
        _server = cfg.get("SERVER",   "key_path", fallback=_server)
        _secret = cfg.get("SECURITY", "secret",   fallback=_secret)

    local_folder, local_path, sync_file = _get_key_paths(app_id)
    today        = datetime.now().strftime("%Y%m%d")


    os.makedirs(local_folder, exist_ok=True)

    # Đồng bộ từ server 1 lần/ngày (không mở UI)
    last_sync = ""
    if os.path.isfile(sync_file):
        try:
            with open(sync_file, "r", encoding="utf-8") as f:
                last_sync = f.read().strip()
        except Exception:
            pass

    if last_sync != today and _server and os.path.isfile(_server):
        try:
            import shutil
            shutil.copy2(_server, local_path)
            with open(sync_file, "w", encoding="utf-8") as f:
                f.write(today)
            logger.info(f"[JA License Silent] Synced from server: {_server}")
        except Exception as e:
            logger.warning(f"[JA License Silent] Không sync được: {e}")

    # Kiểm tra file key
    if not os.path.isfile(local_path):
        return False, "NO_KEY_FILE:Chưa có file bản quyền. Vui lòng kích hoạt."

    try:
        with open(local_path, "r", encoding="utf-8") as f:
            encoded = f.read().strip()
    except Exception as e:
        return False, f"READ_ERROR:{e}"

    if not encoded:
        return False, "READ_ERROR:File bản quyền trống."

    result = _decrypt_key(encoded, _secret, expected_app_id=app_id)

    if not result["valid"]:
        return False, f"INVALID:{result['error'] or 'Key không hợp lệ.'}"

    if result["expired"]:
        exp = result["expiry_date"]
        exp_fmt = f"{exp[:4]}-{exp[4:6]}-{exp[6:]}"
        return False, f"EXPIRED:Bản quyền đã hết hạn ({exp_fmt}). Liên hệ Admin để gia hạn."

    exp = result["expiry_date"]
    logger.info(f"[JA License Silent] OK — app={app_id} expires {exp[:4]}-{exp[4:6]}-{exp[6:]}")
    return True, f"Bản quyền hợp lệ (App: {app_id} | Hết hạn: {exp[:4]}-{exp[4:6]}-{exp[6:]})"
