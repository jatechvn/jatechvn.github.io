"""
logger_config.py — Cấu hình logging tập trung cho JA Key Creator
"""
import logging
import os
from datetime import datetime
from modules.constants import LOGS_DIR


def setup_logger(name: str = "JA_KEY_CREATOR") -> logging.Logger:
    """Thiết lập logger ghi log ra file theo ngày và ra console."""
    os.makedirs(LOGS_DIR, exist_ok=True)

    log_filename = os.path.join(LOGS_DIR, f"{datetime.now().strftime('%Y-%m-%d')}.log")

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    if logger.hasHandlers():
        return logger

    # File handler — ghi toàn bộ DEBUG trở lên
    fh = logging.FileHandler(log_filename, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh_fmt = logging.Formatter(
        "[%(asctime)s] [%(levelname)-8s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    fh.setFormatter(fh_fmt)

    # Console handler — chỉ INFO trở lên
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch_fmt = logging.Formatter("[%(levelname)s] %(message)s")
    ch.setFormatter(ch_fmt)

    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger
