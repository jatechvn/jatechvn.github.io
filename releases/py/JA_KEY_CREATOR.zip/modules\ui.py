"""
ui.py — Giao diện chính JA Key Creator
Thiết kế: Glassmorphism + BlurWindow, FramelessWindow, Dark/Light toggle
Tham chiếu: LVI_LX_RETEST_CHART_EVRT/modules/ui.py
"""
import os
import json
import logging
import configparser
from datetime import datetime, timedelta

import darkdetect
from PySide6.QtCore import Qt, QDate, Signal, Slot, QTimer
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QDateEdit, QLineEdit, QTextEdit, QFrame, QGraphicsDropShadowEffect,
    QFileDialog, QComboBox
)
from PySide6.QtGui import (
    QFont, QColor, QGuiApplication, QIcon,
    QLinearGradient, QPainter, QPainterPath, QPen, QBrush
)
from BlurWindow.blurWindow import GlobalBlur

import modules.logic as logic
from modules.constants import (
    APP_NAME, APP_VERSION, COLOR_GRAD_START, COLOR_GRAD_END,
    COLOR_ACCENT, COLOR_WARN, COLOR_DANGER, FONT_MAIN, FONT_MONO,
    CONFIG_PATH, ICON_PATH, KEYS_DIR, APPS_JSON_PATH
)
from modules.utils import copy_to_clipboard, validate_date_str

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────
#  Animated Gradient Button
# ─────────────────────────────────────────────────────────────
class GradientButton(QPushButton):
    """Button với gradient và hover animation nhẹ."""
    def __init__(self, text: str, parent=None, danger: bool = False, secondary: bool = False):
        super().__init__(text, parent)
        self._danger    = danger
        self._secondary = secondary
        self._hovered   = False
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(36)
        self.setFont(QFont(FONT_MAIN, 10, QFont.Bold))

    def enterEvent(self, e):
        self._hovered = True; self.update(); super().enterEvent(e)

    def leaveEvent(self, e):
        self._hovered = False; self.update(); super().leaveEvent(e)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = self.rect()

        path = QPainterPath()
        path.addRoundedRect(rect.x(), rect.y(), rect.width(), rect.height(), 14, 14)
        painter.setClipPath(path)

        if not self.isEnabled():
            painter.fillPath(path, QColor("#555555"))
        elif self._danger:
            c1 = QColor("#ff4444") if not self._hovered else QColor("#ff6666")
            c2 = QColor("#cc2222") if not self._hovered else QColor("#ee4444")
            grad = QLinearGradient(0, 0, rect.width(), 0)
            grad.setColorAt(0, c1); grad.setColorAt(1, c2)
            painter.fillPath(path, QBrush(grad))
        elif self._secondary:
            c = QColor(255, 255, 255, 30 if not self._hovered else 55)
            painter.fillPath(path, QBrush(c))
            painter.setPen(QPen(QColor(255, 255, 255, 80), 1))
            painter.drawPath(path)
        else:
            c1 = QColor(COLOR_GRAD_START) if not self._hovered else QColor("#22eeff")
            c2 = QColor(COLOR_GRAD_END)   if not self._hovered else QColor("#9933ff")
            grad = QLinearGradient(0, 0, rect.width(), 0)
            grad.setColorAt(0, c1); grad.setColorAt(1, c2)
            painter.fillPath(path, QBrush(grad))

        # Text
        painter.setPen(QColor("white") if (self.isEnabled() or self._secondary) else QColor("#aaaaaa"))
        painter.setFont(self.font())
        painter.drawText(rect, Qt.AlignCenter, self.text())
        painter.end()


# ─────────────────────────────────────────────────────────────
#  Status Badge
# ─────────────────────────────────────────────────────────────
class StatusBadge(QLabel):
    """Nhãn trạng thái bo tròn đẹp."""
    def set_status(self, text: str, level: str = "info"):
        colors = {
            "info":    ("#00d4ff", "#0a2040"),
            "success": (COLOR_ACCENT, "#0a2a1a"),
            "warn":    (COLOR_WARN,   "#2a1a00"),
            "error":   (COLOR_DANGER, "#2a0a0a"),
        }
        fg, bg = colors.get(level, colors["info"])
        self.setText(text)
        self.setStyleSheet(
            f"color: {fg}; background: {bg}; border: 1px solid {fg};"
            f"border-radius: 10px; padding: 4px 14px; font-family: '{FONT_MONO}'; font-size: 12px;"
        )


# ─────────────────────────────────────────────────────────────
#  Main App Window
# ─────────────────────────────────────────────────────────────
class KeyCreatorApp(QWidget):
    log_signal = Signal(str, str)   # (message, level)

    def __init__(self):
        super().__init__()
        self._old_pos = None

        # Load config
        self.config = configparser.ConfigParser()
        self.config.read(CONFIG_PATH, encoding="utf-8")
        self.secret   = self.config.get("SECURITY", "secret", fallback="JohnAlaaSecretKey_2026!@#")
        self.keys_dir = self.config.get("LOCAL", "keys_dir", fallback=KEYS_DIR)
        os.makedirs(self.keys_dir, exist_ok=True)

        self.keygen = logic.KeyGenerator(self.secret)

        self.is_dark = darkdetect.isDark()
        self._setup_window()
        self._setup_ui()
        self._apply_theme()

        self.log_signal.connect(self._append_log)

        # Listen to OS theme changes
        app = QGuiApplication.instance()
        if app:
            app.styleHints().colorSchemeChanged.connect(self._on_os_theme_changed)

    # ── Window setup ──────────────────────────────────────────
    def _setup_window(self):
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.resize(640, 1080)
        self.setMinimumSize(560, 960)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowMinimizeButtonHint | Qt.WindowSystemMenuHint)
        if os.path.exists(ICON_PATH):
            self.setWindowIcon(QIcon(ICON_PATH))
        GlobalBlur(self.winId(), Dark=self.is_dark, QWidget=self)

    # ── Draggable titlebar ─────────────────────────────────────
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._old_pos = e.globalPosition().toPoint()

    def mouseMoveEvent(self, e):
        if self._old_pos:
            delta = e.globalPosition().toPoint() - self._old_pos
            self.move(self.pos() + delta)
            self._old_pos = e.globalPosition().toPoint()

    def mouseReleaseEvent(self, e):
        self._old_pos = None

    # ── OS theme change ────────────────────────────────────────
    def _on_os_theme_changed(self, scheme):
        is_os_dark = (scheme == Qt.ColorScheme.Dark)
        if self.is_dark != is_os_dark:
            self.is_dark = is_os_dark
            self._apply_theme()
            GlobalBlur(self.winId(), Dark=self.is_dark, QWidget=self)

    def _toggle_theme(self):
        self.is_dark = not self.is_dark
        self._apply_theme()
        GlobalBlur(self.winId(), Dark=self.is_dark, QWidget=self)

    def _toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    # ── Drop shadow helper ─────────────────────────────────────
    def _add_shadow(self, widget, blur=16, alpha=120):
        eff = QGraphicsDropShadowEffect()
        eff.setBlurRadius(blur)
        eff.setColor(QColor(0, 212, 255, alpha))
        eff.setOffset(0, 0)
        widget.setGraphicsEffect(eff)

    # ── Build UI ──────────────────────────────────────────────
    def _setup_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 8, 8, 8)

        self.central = QWidget()
        self.central.setObjectName("CentralWidget")
        outer.addWidget(self.central)

        root = QVBoxLayout(self.central)
        root.setContentsMargins(24, 12, 24, 16)
        root.setSpacing(8)

        # ── Titlebar ──────────────────────────────────────────
        tb = QHBoxLayout()
        tb.setSpacing(6)
        for name, obj_name, slot in [
            ("", "CloseBtn", self.close),
            ("", "MinBtn",   self.showMinimized),
            ("", "MaxBtn",   self._toggle_maximize),
        ]:
            btn = QPushButton(name)
            btn.setObjectName(obj_name)
            btn.setFixedSize(14, 14)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(slot)
            tb.addWidget(btn)

        tb.addSpacing(12)
        title_lbl = QLabel(f"🔑  {APP_NAME}")
        title_lbl.setFont(QFont(FONT_MAIN, 18, QFont.Bold))
        self._add_shadow(title_lbl)
        tb.addWidget(title_lbl)
        tb.addStretch()

        self.theme_btn = QPushButton("💡" if self.is_dark else "🌙")
        self.theme_btn.setObjectName("ThemeBtn")
        self.theme_btn.setFixedSize(36, 28)
        self.theme_btn.setCursor(Qt.PointingHandCursor)
        self.theme_btn.clicked.connect(self._toggle_theme)
        tb.addWidget(self.theme_btn)
        root.addLayout(tb)

        # ── Divider ───────────────────────────────────────────
        div = QFrame(); div.setFrameShape(QFrame.HLine)
        div.setObjectName("Divider"); root.addWidget(div)

        # ── App selector ───────────────────────────────────────────
        root.addWidget(self._section_label("📦  Phần mềm áp dụng (App)"))

        app_row = QHBoxLayout()
        self.app_combo = QComboBox()
        self.app_combo.setMinimumHeight(36)
        self.app_combo.setFont(QFont(FONT_MONO, 10, QFont.Bold))
        self.app_combo.setCursor(Qt.PointingHandCursor)
        self._load_apps()   # Điền dữ liệu vào combo

        reload_btn = QPushButton("🔄")
        reload_btn.setObjectName("BrowseBtn")
        reload_btn.setFixedSize(42, 36)
        reload_btn.setCursor(Qt.PointingHandCursor)
        reload_btn.setToolTip("Tải lại danh sách phần mềm từ apps.json")
        reload_btn.clicked.connect(self._load_apps)
        app_row.addWidget(self.app_combo, 1)
        app_row.addWidget(reload_btn)
        root.addLayout(app_row)

        # ── Date picker section ───────────────────────────────
        root.addWidget(self._section_label("📅  Ngày hết hạn (Expiry Date)"))

        date_row = QHBoxLayout()
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat("dd / MM / yyyy")
        # Mặc định: 1 tháng tính từ hôm nay
        self.date_edit.setDate(QDate.currentDate().addMonths(1))
        self.date_edit.setMinimumDate(QDate(2020, 1, 1))
        self.date_edit.setMinimumHeight(36)
        self.date_edit.setFont(QFont(FONT_MONO, 12, QFont.Bold))
        date_row.addWidget(self.date_edit)

        # Quick preset buttons
        for label, months in [("+ 1T", 1), ("+ 3T", 3), ("+ 6T", 6), ("+ 1N", 12)]:
            btn = QPushButton(label)
            btn.setObjectName("PresetBtn")
            btn.setFixedHeight(36)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda *_, m=months: self.date_edit.setDate(QDate.currentDate().addMonths(m)))
            date_row.addWidget(btn)
        root.addLayout(date_row)

        # ── Filename field ────────────────────────────────────
        root.addWidget(self._section_label("📄  Tên file key (để trống = tự động theo tên phần mềm)"))

        fname_row = QHBoxLayout()
        self.filename_edit = QLineEdit()
        self.filename_edit.setPlaceholderText(
            "Để trống = tự động đặt theo tên phần mềm (App ID)"
        )
        self.filename_edit.setMinimumHeight(34)
        self.filename_edit.setFont(QFont(FONT_MONO, 9))
        self.filename_edit.setToolTip("Không cần gõ đuôi .key, phần mềm tự thêm")
        fname_row.addWidget(self.filename_edit, 1)

        # Label suffix
        suffix_lbl = QLabel(".key")
        suffix_lbl.setObjectName("SuffixLabel")
        suffix_lbl.setFont(QFont(FONT_MONO, 10, QFont.Bold))
        fname_row.addWidget(suffix_lbl)
        root.addLayout(fname_row)

        # ── Note field ────────────────────────────────────────
        root.addWidget(self._section_label("📝  Ghi chú / Tên máy (tuỳ chọn)"))
        note_row = QHBoxLayout()
        self.note_edit = QLineEdit()
        self.note_edit.setPlaceholderText("VD: PC-LineA, John PC, ...")
        self.note_edit.setMinimumHeight(34)
        self.note_edit.setFont(QFont(FONT_MAIN, 11))
        
        note_paste_btn = QPushButton("📋")
        note_paste_btn.setObjectName("BrowseBtn")
        note_paste_btn.setFixedSize(42, 34)
        note_paste_btn.setCursor(Qt.PointingHandCursor)
        note_paste_btn.setToolTip("Dán từ bộ nhớ tạm (Paste)")
        note_paste_btn.clicked.connect(lambda: self.note_edit.setText(QGuiApplication.clipboard().text()))
        
        note_row.addWidget(self.note_edit, 1)
        note_row.addWidget(note_paste_btn)
        root.addLayout(note_row)

        # ── HWID field ────────────────────────────────────────
        root.addWidget(self._section_label("💻  Mã máy của khách hàng (HWID - Khóa theo máy, bỏ trống nếu dùng chung)"))
        hwid_row = QHBoxLayout()
        self.hwid_edit = QLineEdit()
        self.hwid_edit.setPlaceholderText("VD: BFD9-E342-9901 hoặc dán mã máy khách gửi tại đây...")
        self.hwid_edit.setMinimumHeight(34)
        self.hwid_edit.setFont(QFont(FONT_MONO, 10))
        
        hwid_paste_btn = QPushButton("📋")
        hwid_paste_btn.setObjectName("BrowseBtn")
        hwid_paste_btn.setFixedSize(42, 34)
        hwid_paste_btn.setCursor(Qt.PointingHandCursor)
        hwid_paste_btn.setToolTip("Dán từ bộ nhớ tạm (Paste)")
        hwid_paste_btn.clicked.connect(lambda: self.hwid_edit.setText(QGuiApplication.clipboard().text()))
        
        hwid_row.addWidget(self.hwid_edit, 1)
        hwid_row.addWidget(hwid_paste_btn)
        root.addLayout(hwid_row)


        # ── Output folder row ─────────────────────────────────
        root.addWidget(self._section_label("📁  Thư mục lưu key"))
        folder_row = QHBoxLayout()

        self.folder_display = QLineEdit(self.keys_dir)
        self.folder_display.setReadOnly(True)
        self.folder_display.setMinimumHeight(36)
        self.folder_display.setFont(QFont(FONT_MONO, 8))
        self.folder_display.setObjectName("FolderDisplay")
        folder_row.addWidget(self.folder_display, 1)

        browse_btn = QPushButton("📂")
        browse_btn.setObjectName("BrowseBtn")
        browse_btn.setFixedSize(42, 36)
        browse_btn.setCursor(Qt.PointingHandCursor)
        browse_btn.setToolTip("Đổi thư mục lưu key")
        browse_btn.clicked.connect(self._browse_folder)
        folder_row.addWidget(browse_btn)

        open_btn = QPushButton("🗂")
        open_btn.setObjectName("BrowseBtn")
        open_btn.setFixedSize(42, 36)
        open_btn.setCursor(Qt.PointingHandCursor)
        open_btn.setToolTip("Mở thư mục trong Explorer")
        open_btn.clicked.connect(self._open_folder_explorer)
        folder_row.addWidget(open_btn)
        root.addLayout(folder_row)

        # ── Main action button ────────────────────────────────
        root.addSpacing(4)
        self.btn_save_key = GradientButton("💾  Tạo Key & Lưu vào thư mục")
        self.btn_save_key.clicked.connect(self._action_save_key)
        root.addWidget(self.btn_save_key)

        self.btn_save_custom = GradientButton("📂  Tạo Key & Lưu tuỳ chọn vị trí...", secondary=True)
        self.btn_save_custom.clicked.connect(self._action_save_custom)
        root.addWidget(self.btn_save_custom)

        # ── Key output display ────────────────────────────────
        key_header_row = QHBoxLayout()
        key_header_lbl = self._section_label("🔐  Chuỗi Key đã mã hóa")
        
        self.btn_copy = QPushButton("📋  Copy Key")
        self.btn_copy.setObjectName("CopyBtn")
        self.btn_copy.setFixedHeight(30)
        self.btn_copy.setCursor(Qt.PointingHandCursor)
        self.btn_copy.clicked.connect(self._copy_key)
        
        key_header_row.addWidget(key_header_lbl)
        key_header_row.addStretch()
        key_header_row.addWidget(self.btn_copy)
        root.addLayout(key_header_row)

        key_frame = QFrame()
        key_frame.setObjectName("KeyFrame")
        key_layout = QVBoxLayout(key_frame)
        key_layout.setContentsMargins(12, 10, 12, 10)
        key_layout.setSpacing(6)

        self.key_display = QTextEdit()
        self.key_display.setReadOnly(True)
        self.key_display.setFont(QFont(FONT_MONO, 8))
        self.key_display.setMinimumHeight(90)
        self.key_display.setPlaceholderText("Chuỗi key sẽ hiện tại đây sau khi tạo...")
        key_layout.addWidget(self.key_display)
        root.addWidget(key_frame)

        # ── Verify section ────────────────────────────────────
        root.addWidget(self._section_label("🔍  Kiểm tra / Giải mã Key"))
        verify_row = QHBoxLayout()
        self.verify_edit = QLineEdit()
        self.verify_edit.setPlaceholderText("Paste chuỗi key vào đây để kiểm tra...")
        self.verify_edit.setMinimumHeight(34)
        self.verify_edit.setFont(QFont(FONT_MONO, 9))
        
        verify_paste_btn = QPushButton("📋")
        verify_paste_btn.setObjectName("PasteKeyBtn")
        verify_paste_btn.setFixedHeight(34)
        verify_paste_btn.setCursor(Qt.PointingHandCursor)
        verify_paste_btn.setToolTip("Dán từ bộ nhớ tạm (Paste)")
        verify_paste_btn.clicked.connect(lambda: self.verify_edit.setText(QGuiApplication.clipboard().text()))
        
        verify_row.addWidget(self.verify_edit, 1)
        verify_row.addWidget(verify_paste_btn)

        self.btn_verify = GradientButton("Kiểm tra", secondary=True)
        self.btn_verify.setFixedWidth(100)
        self.btn_verify.clicked.connect(self._action_verify)
        verify_row.addWidget(self.btn_verify)
        root.addLayout(verify_row)

        # ── Status badge ──────────────────────────────────────
        self.status_badge = StatusBadge("Sẵn sàng")
        self.status_badge.set_status("Sẵn sàng tạo key", "info")
        self.status_badge.setAlignment(Qt.AlignCenter)
        root.addWidget(self.status_badge)

        # ── Log output ────────────────────────────────────────
        root.addWidget(self._section_label("📋  Nhật ký"))
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setFont(QFont(FONT_MONO, 8))
        self.log_view.setMaximumHeight(110)
        self.log_view.setObjectName("LogView")
        root.addWidget(self.log_view)

        # ── Footer ────────────────────────────────────────────
        footer = QLabel(f"© 2026 JohnAlaa  •  {APP_NAME} v{APP_VERSION}")
        footer.setAlignment(Qt.AlignCenter)
        footer.setObjectName("Footer")
        root.addWidget(footer)

    def _section_label(self, text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setFont(QFont(FONT_MAIN, 10, QFont.Bold))
        lbl.setObjectName("SectionLabel")
        return lbl

    # ── Theme ─────────────────────────────────────────────────
    def _apply_theme(self):
        dark = self.is_dark
        bg        = "rgba(10, 12, 28, 0.55)"  if dark else "rgba(240, 245, 255, 0.55)"
        text      = "#e8eaf6"                  if dark else "#1a1a2e"
        border    = "rgba(255,255,255,0.12)"   if dark else "rgba(0,0,0,0.12)"
        input_bg  = "rgba(255,255,255,0.07)"   if dark else "rgba(0,0,0,0.06)"
        log_bg    = "rgba(0,0,0,0.35)"         if dark else "rgba(0,0,0,0.06)"

        self.theme_btn.setText("💡" if dark else "🌙")

        qss = f"""
        QWidget#CentralWidget {{
            background: {bg};
            border: 1px solid {border};
            border-radius: 28px;
        }}
        QLabel {{
            color: {text};
            font-family: '{FONT_MAIN}', sans-serif;
            font-size: 13px;
        }}
        QLabel#SectionLabel {{
            color: {COLOR_GRAD_START};
            font-size: 11px;
            font-weight: bold;
            letter-spacing: 0.5px;
        }}
        QLabel#SuffixLabel {{
            color: {'rgba(0,212,255,0.7)' if dark else 'rgba(0,100,200,0.8)'};
            font-size: 13px;
            padding: 0 4px;
        }}
        QLabel#Footer {{
            color: rgba(180,180,210,0.55);
            font-size: 10px;
            font-family: '{FONT_MONO}', monospace;
        }}
        QFrame#Divider {{
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 transparent,
                stop:0.3 {COLOR_GRAD_START},
                stop:0.7 {COLOR_GRAD_END},
                stop:1 transparent);
            max-height: 1px; border: none;
        }}
        QFrame#KeyFrame {{
            background: {log_bg};
            border: 1px solid {border};
            border-radius: 12px;
        }}
        QLineEdit, QDateEdit, QTextEdit {{
            background: {input_bg};
            color: {text};
            border: 1px solid {border};
            border-radius: 10px;
            padding: 6px 10px;
            font-family: '{FONT_MONO}', monospace;
            selection-background-color: {COLOR_GRAD_START};
        }}
        QLineEdit:focus, QDateEdit:focus, QTextEdit:focus {{
            border: 1px solid {COLOR_GRAD_START};
        }}
        QLineEdit#FolderDisplay {{
            color: {'rgba(180,210,255,0.75)' if dark else 'rgba(0,60,150,0.75)'};
            font-size: 9px;
        }}
        QDateEdit::drop-down {{
            subcontrol-origin: padding; subcontrol-position: right center;
            width: 28px; border: none;
        }}
        QTextEdit#LogView {{
            background: {log_bg};
            border: 1px solid {border};
            border-radius: 10px;
            color: {'#aef0d0' if dark else '#1a3a2a'};
        }}
        QPushButton#CloseBtn {{
            background: #ff5f56; border: 1px solid #e0443e; border-radius: 7px;
        }}
        QPushButton#CloseBtn:hover {{ background: #ff7a72; }}
        QPushButton#MinBtn {{
            background: #ffbd2e; border: 1px solid #dea123; border-radius: 7px;
        }}
        QPushButton#MinBtn:hover {{ background: #ffd050; }}
        QPushButton#MaxBtn {{
            background: #27c93f; border: 1px solid #1aab2e; border-radius: 7px;
        }}
        QPushButton#MaxBtn:hover {{ background: #3dda55; }}
        QPushButton#ThemeBtn {{
            background: {input_bg};
            border: 1px solid {border};
            border-radius: 8px;
            color: {text};
            font-size: 14px;
        }}
        QPushButton#ThemeBtn:hover {{ background: rgba(0,212,255,0.15); }}
        QPushButton#PresetBtn {{
            background: {'rgba(0,212,255,0.12)' if dark else 'rgba(0,100,200,0.1)'};
            color: {COLOR_GRAD_START};
            border: 1px solid {'rgba(0,212,255,0.3)' if dark else 'rgba(0,100,200,0.3)'};
            border-radius: 8px;
            font-family: '{FONT_MAIN}';
            font-size: 10px;
            padding: 0 6px;
        }}
        QPushButton#PresetBtn:hover {{
            background: rgba(0,212,255,0.25);
        }}
        QPushButton#BrowseBtn {{
            background: {input_bg};
            border: 1px solid {border};
            border-radius: 8px;
            color: {text};
            font-size: 15px;
        }}
        QPushButton#BrowseBtn:hover {{ background: rgba(0,212,255,0.15); }}
        QPushButton#PasteKeyBtn {{
            background: {'rgba(0,212,255,0.15)' if dark else 'rgba(0,120,200,0.12)'};
            color: {COLOR_GRAD_START};
            border: 1px solid {'rgba(0,212,255,0.3)' if dark else 'rgba(0,120,200,0.3)'};
            border-radius: 8px;
            padding: 2px 14px;
            font-family: '{FONT_MAIN}';
            font-size: 11px;
        }}
        QPushButton#PasteKeyBtn:hover {{ background: {'rgba(0,212,255,0.3)' if dark else 'rgba(0,120,200,0.25)'}; }}
        QPushButton#CopyBtn {{
            background: {'rgba(0,255,157,0.15)' if dark else 'rgba(0,150,80,0.12)'};
            color: {COLOR_ACCENT};
            border: 1px solid {'rgba(0,255,157,0.3)' if dark else 'rgba(0,150,80,0.3)'};
            border-radius: 8px;
            padding: 2px 14px;
            font-family: '{FONT_MAIN}';
            font-size: 10px;
        }}
        QPushButton#CopyBtn:hover {{ background: rgba(0,255,157,0.3); }}
        QComboBox {{
            background: {input_bg};
            color: {text};
            border: 1px solid {border};
            border-radius: 10px;
            padding: 6px 12px;
            font-family: '{FONT_MONO}', monospace;
            font-size: 10px;
        }}
        QComboBox:focus {{
            border: 1px solid {COLOR_GRAD_START};
        }}
        QComboBox::drop-down {{
            subcontrol-origin: padding; subcontrol-position: right center;
            width: 28px; border: none;
        }}
        QComboBox QAbstractItemView {{
            background: {'rgba(10,12,40,0.97)' if dark else 'rgba(230,240,255,0.97)'};
            color: {text};
            border: 1px solid {border};
            border-radius: 8px;
            selection-background-color: {COLOR_GRAD_START};
            selection-color: white;
            padding: 4px;
        }}
        QScrollBar:vertical {{
            background: transparent; width: 6px; margin: 0;
        }}
        QScrollBar::handle:vertical {{
            background: rgba(0,212,255,0.4); border-radius: 3px;
        }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
        """
        self.setStyleSheet(qss)

    # ── Helpers ─────────────────────────────────────────────────────
    def _load_apps(self):
        """Nạp danh sách app từ apps.json vào ComboBox."""
        current_id = self._get_selected_app_id()  # Lưu lại lựa chọn hiện tại
        self.app_combo.clear()
        try:
            with open(APPS_JSON_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            apps = data.get("apps", [])
            if not apps:
                self.app_combo.addItem("⚠️  apps.json trống — thêm app vào file", "")
                return
            for app in apps:
                label = f"{app['name']}  [{app['id']}]"
                self.app_combo.addItem(label, app["id"])  # userData = app_id
                # Khôi phục lựa chọn cũ nếu có
                if app["id"] == current_id:
                    self.app_combo.setCurrentIndex(self.app_combo.count() - 1)
            self._log(f"[OK] Đã nạp {len(apps)} phần mềm từ apps.json", "info")
        except FileNotFoundError:
            self.app_combo.addItem("⚠️  Không tìm thấy apps.json", "")
            self._log("[WARN] apps.json không tồn tại", "warn")
        except Exception as e:
            self.app_combo.addItem(f"❌  Lỗi đọc apps.json: {e}", "")
            self._log(f"[ERR] Đọc apps.json: {e}", "error")

    def _get_selected_app_id(self) -> str | None:
        """Trả về app_id đang chọn trong ComboBox (userData), hoặc None."""
        if not hasattr(self, "app_combo"):
            return None
        return self.app_combo.currentData() or None

    def _get_expiry_str(self) -> str:
        d = self.date_edit.date()
        return f"{d.year()}{d.month():02d}{d.day():02d}"

    def _resolve_filename(self) -> str:
        """Trả về tên file đầy đủ (có đuôi .key). Nếu không nhập thì dùng app_id."""
        name = self.filename_edit.text().strip()
        if name:
            # Bỏ đuôi .key nếu user tự gõ vào
            base = os.path.splitext(name)[0]
        else:
            app_id = self._get_selected_app_id()
            base = app_id if app_id else f"key_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        return base + ".key"

    def _generate_key(self) -> str | None:
        """Mã hóa ngày hết hạn + app_id + hwid, hiển thị key lên UI, trả về chuỗi key."""
        app_id = self._get_selected_app_id()
        if not app_id:
            self.status_badge.set_status("⚠️ Chưa chọn phần mềm! Hãy chọn app trong danh sách.", "warn")
            return None
        expiry = self._get_expiry_str()
        if not validate_date_str(expiry):
            self.status_badge.set_status("❌ Ngày hết hạn không hợp lệ!", "error")
            return None
        try:
            hwid = self.hwid_edit.text().strip()
            key = self.keygen.encrypt_key(expiry, app_id, hwid)
            self.key_display.setPlainText(key)
            note = self.note_edit.text().strip()
            exp_display = f"{expiry[:4]}-{expiry[4:6]}-{expiry[6:]}"
            msg = f"✅ Key tạo xong — [{app_id}] Hết hạn: {exp_display}"
            if hwid:
                msg += f" | Khóa máy: {hwid[:12]}..."
            if note:
                msg += f"  ({note})"
            self.status_badge.set_status(msg, "success")
            self._log(f"[OK] Key generated | app={app_id} | expiry={expiry} | hwid={hwid or '-'} | note={note or '-'}", "success")
            return key
        except Exception as e:
            self.status_badge.set_status(f"❌ Lỗi mã hóa: {e}", "error")
            self._log(f"[ERR] {e}", "error")
            return None

    # ── Actions ───────────────────────────────────────────────
    def _action_save_key(self):
        """Tạo key và lưu vào thư mục mặc định (keys_dir)."""
        key = self._generate_key()
        if not key:
            return
        filename = self._resolve_filename()
        save_path = os.path.join(self.keys_dir, filename)
        try:
            self.keygen.write_key_to_path(key, save_path)
            self.status_badge.set_status(f"✅ Đã lưu: {filename}", "success")
            self._log(f"[OK] Key saved → {save_path}", "success")
            # Cập nhật placeholder với tên file tiếp theo
            self.filename_edit.setPlaceholderText(
                "Để trống = tự động đặt theo tên phần mềm (App ID)"
            )
        except Exception as e:
            self.status_badge.set_status(f"❌ Lỗi ghi file: {e}", "error")
            self._log(f"[ERR] {e}", "error")

    def _action_save_custom(self):
        """Tạo key và cho phép chọn vị trí lưu tuỳ ý."""
        key = self._generate_key()
        if not key:
            return
        default_name = self._resolve_filename()
        save_path, _ = QFileDialog.getSaveFileName(
            self, "Lưu file key", os.path.join(self.keys_dir, default_name),
            "Key Files (*.key);;All Files (*.*)"
        )
        if not save_path:
            return
        try:
            self.keygen.write_key_to_path(key, save_path)
            self.status_badge.set_status(f"✅ Đã lưu: {os.path.basename(save_path)}", "success")
            self._log(f"[OK] Key saved → {save_path}", "success")
        except Exception as e:
            self.status_badge.set_status(f"❌ Lỗi ghi file: {e}", "error")
            self._log(f"[ERR] {e}", "error")

    def _action_verify(self):
        encoded = self.verify_edit.text().strip() or self.key_display.toPlainText().strip()
        if not encoded:
            self.status_badge.set_status("⚠️ Chưa có key để kiểm tra.", "warn")
            return
        result = self.keygen.decrypt_key(encoded)  # Không truyền app_id → chỉ kiểm tra chữ ký
        if not result["valid"]:
            self.status_badge.set_status(f"❌ Key không hợp lệ: {result['error']}", "error")
            self._log(f"[VERIFY FAIL] {result['error']}", "error")
            return
        exp = result["expiry_date"]
        app_in_key = result.get("app_id", "?") or "?"
        hwid_in_key = result.get("hwid", "")
        exp_display = f"{exp[:4]}-{exp[4:6]}-{exp[6:]}"
        
        status_msg = f"✅ Key hợp lệ — App: {app_in_key} | Hết hạn: {exp_display}"
        if hwid_in_key:
            status_msg += f" | Khóa máy: {hwid_in_key}"
        else:
            status_msg += " | Key dùng chung"
            
        if result["expired"]:
            self.status_badge.set_status(f"⏰ Key ĐÃ HẾT HẠN từ {exp_display}  (App: {app_in_key})", "warn")
            self._log(f"[VERIFY] Expired — expiry={exp_display} app={app_in_key} hwid={hwid_in_key or '-'}", "warn")
        else:
            self.status_badge.set_status(status_msg, "success")
            self._log(f"[VERIFY OK] app={app_in_key} expiry={exp_display} hwid={hwid_in_key or '-'}", "success")

    def _copy_key(self):
        key = self.key_display.toPlainText().strip()
        if not key:
            self.status_badge.set_status("⚠️ Chưa có key để copy.", "warn")
            return
        if copy_to_clipboard(key):
            self.status_badge.set_status("📋 Đã copy key vào clipboard!", "success")
            self._log("[OK] Key copied to clipboard", "success")

    def _browse_folder(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Chọn thư mục lưu key", self.keys_dir
        )
        if folder:
            self.keys_dir = folder
            self.folder_display.setText(folder)
            os.makedirs(folder, exist_ok=True)
            self._log(f"[OK] Output folder changed → {folder}", "info")

    def _open_folder_explorer(self):
        """Mở thư mục lưu key trong Windows Explorer."""
        try:
            os.makedirs(self.keys_dir, exist_ok=True)
            os.startfile(self.keys_dir)
        except Exception as e:
            self._log(f"[ERR] Không mở được Explorer: {e}", "error")

    # ── Log ───────────────────────────────────────────────────
    def _log(self, message: str, level: str = "info"):
        self.log_signal.emit(message, level)
        log_fn = getattr(logger, level if level in ("debug","info","warning","error") else "info", logger.info)
        log_fn(message)

    @Slot(str, str)
    def _append_log(self, message: str, level: str):
        colors = {
            "success": COLOR_ACCENT,
            "warn":    COLOR_WARN,
            "error":   COLOR_DANGER,
            "info":    "#00d4ff",
        }
        color = colors.get(level, "#aaaaaa")
        ts = datetime.now().strftime("%H:%M:%S")
        html = f'<span style="color:{color};font-family:{FONT_MONO};">[{ts}] {message}</span>'
        self.log_view.append(html)
        self.log_view.verticalScrollBar().setValue(self.log_view.verticalScrollBar().maximum())
