@echo off
chcp 65001 > nul
cd /d "%~dp0"

rem Activate virtualenv if present
if exist ".venv\Scripts\activate.bat" (
    call .venv\Scripts\activate.bat
) else (
    echo [WARN] Khong tim thay .venv, chay bang Python he thong.
)

echo [JA Key Creator] Dang khoi dong...
python main.py
::pause
