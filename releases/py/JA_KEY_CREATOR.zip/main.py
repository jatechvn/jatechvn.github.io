import sys
import os
import ctypes
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QIcon
from modules.logger_config import setup_logger
from modules.ui import KeyCreatorApp
from modules.utils import ensure_project_dirs
from modules.constants import APP_ID, ICON_PATH

# Buộc Windows nhận diện là app riêng biệt (không gom vào python.exe trên taskbar)
if sys.platform == "win32":
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:
        pass

# Suppress harmless internal DPI font warnings from Qt
from PySide6.QtCore import qInstallMessageHandler
def qt_message_handler(mode, context, message):
    if "setPointSize: Point size <= 0" in message:
        return
    sys.stderr.write(f"{message}\n")
    sys.stderr.flush()

qInstallMessageHandler(qt_message_handler)


def main():
    logger = setup_logger()
    logger.info("=" * 50)
    logger.info("Khởi động JA Key Creator...")

    ensure_project_dirs()

    app = QApplication(sys.argv)

    app_icon = QIcon(ICON_PATH) if os.path.exists(ICON_PATH) else QIcon()
    app.setWindowIcon(app_icon)

    window = KeyCreatorApp()
    window.setWindowIcon(app_icon)
    window.show()

    logger.info("JA Key Creator sẵn sàng.")
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
