"""
constants.py — Hằng số toàn cục cho JA Key Creator
"""
import os

APP_NAME        = "JA Key Creator"
APP_VERSION     = "1.0.0"
APP_AUTHOR      = "JohnAlaa"
APP_ID          = "JohnAlaa.JAKeyCreator.1.0"   # Windows AppUserModelID

# Màu sắc gradient chủ đạo
COLOR_GRAD_START = "#00d4ff"
COLOR_GRAD_END   = "#7b2fff"
COLOR_ACCENT     = "#00ff9d"
COLOR_WARN       = "#ffaa00"
COLOR_DANGER     = "#ff4444"

# Font
FONT_MAIN  = "Inter"
FONT_MONO  = "JetBrains Mono"

# Đường dẫn thư mục dự án (tính từ root package)
BASE_DIR        = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS_DIR      = os.path.join(BASE_DIR, "assets")
IMAGES_DIR      = os.path.join(ASSETS_DIR, "images")
LOGS_DIR        = os.path.join(BASE_DIR, "logs")
TEMP_DIR        = os.path.join(ASSETS_DIR, "temp")
KEYS_DIR        = os.path.join(BASE_DIR, "keys")        # Thư mục lưu file key xuất ra
CONFIG_PATH     = os.path.join(BASE_DIR, "config.ini")
ICON_PATH       = os.path.join(IMAGES_DIR, "icon.ico")
APPS_JSON_PATH  = os.path.join(BASE_DIR, "apps.json")   # Danh sách phần mềm được cấp key
