# 🤖 JA Auto Git — Liquid Glass Edition

<p align="center">
  <img src="../assets/images/icon.ico" alt="JA Auto Git Logo" width="120" height="120">
  <br>
  <i>Автоматизированное управление Git и умный создатель репозиториев GitHub для разработчиков.</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=for-the-badge&logo=python&logoColor=white" alt="Python Version">
  <img src="https://img.shields.io/badge/GUI-PySide6-green.svg?style=for-the-badge&logo=qt&logoColor=white" alt="UI Framework">
  <img src="https://img.shields.io/badge/Integrations-GitHub_CLI-purple.svg?style=for-the-badge&logo=github&logoColor=white" alt="Integrations">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge" alt="License">
  <img src="https://img.shields.io/badge/Platform-Windows_%7C_macOS_%7C_Linux-0078D6.svg?style=for-the-badge&logo=windows&logoColor=white" alt="Platform">
  <img src="https://img.shields.io/badge/Version-1.5.0-orange.svg?style=for-the-badge" alt="Version">
</p>

<p align="center"><a href="#quick-start">🚀 Быстрый старт</a> • <a href="#features">💡 Возможности</a> • <a href="#setup">📖 Настройка</a> • <a href="https://jatechvn.github.io/">🌐 Сайт</a></p>

<p align="center"><a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="README.zh-CN.md">🇨🇳 中文</a> • <a href="README.ja-JP.md">🇯🇵 日本語</a> • <a href="README.es.md">🇪🇸 Español</a> • <a href="README.fr.md">🇫🇷 Français</a> • <a href="README.de.md">🇩🇪 Deutsch</a> • 🇷🇺 Русский • <a href="README.pt.md">🇵🇹 Português</a> • <a href="README.ko.md">🇰🇷 한국어</a></p>

---

<a id="introduction"></a>
## 🌟 Введение

**JA Auto Git** — это профессиональный GUI-инструмент, упрощающий настройку контроля версий и удалённое хранение на GitHub для нескольких подпроектов одновременно. Разработан для разработчиков, управляющих множеством мини-проектов (Python-скрипты, пакеты Node.js, скрипты AutoHotkey, приложения .NET). Инструмент автоматизирует стандартизацию каталогов и развёртывание приватных репозиториев на GitHub буквально несколькими кликами.

Благодаря стилю дизайна **Liquid Glass** и элементам управления окном в стиле macOS интерфейс обеспечивает современный и интуитивно понятный опыт, повышая продуктивность разработчика на Windows, macOS и Linux.

## 📸 Скриншоты

<p align="center">
  <img src="../assets/images/screenshot_dark.png" alt="JA Auto Git Тёмная тема" width="48%">
  <img src="../assets/images/screenshot_light.png" alt="JA Auto Git Светлая тема" width="48%">
</p>

---

<a id="workflow"></a>
## 📊 Рабочий процесс

```mermaid
graph TD
    A[Launch JA Auto Git] --> B[Scan working directory up to max depth]
    B --> C[Analyze & detect project types + versions]
    C --> D{Check project status}
    D -->|Missing .git / gitignore / README / LICENSE| E[Show warning in UI tree]
    D -->|Standard files present| F[Show Standard OK status]
    E --> G[User selects projects → CREATE / EDIT GIT FORM]
    G --> H[Init Git · create .gitignore · write LICENSE · generate 10-lang READMEs]
    H --> I[User types Commit Message or leaves blank for auto-message]
    I --> J[Auto-generate subject + structured Change Log from staged diff]
    J --> K[Auto-create Private Repo on GitHub if missing · Push via GitHub CLI]
    K --> L[Update status · Auto-sync Cloud tab]
    L --> M{GitHub Cloud tab}
    M --> N[View per-repo Commit History · Download any commit ZIP]
    M --> O[View GitHub Releases · Download release assets to ~/Downloads]
    K --> P[Push GitHub Release with tag + assets via Release Manager]
```

---

<a id="features"></a>
## ✨ Ключевые возможности

### 1. 🔍 Динамический сканер проектов
- **Автоматическое определение технологического стека**: Анализирует сигнатуры файлов для определения типа проекта (Python, Node.js, AHK, .NET, Batch/PowerShell).
- **Рекурсивное сканирование**: Сканирует каталоги до настраиваемой глубины, автоматически игнорируя крупные системные/зависимые директории, такие как `node_modules`, `.venv`, `__pycache__`, `dist`.
- **Многоядерная параллельная обработка**: Операции сканирования используют многопоточность, задействуя все доступные ядра процессора одновременно, сохраняя интерфейс полностью отзывчивым.
- **Автоматическое определение версии**: Автоматически определяет версию каждого проекта из `package.json`, `pyproject.toml`, `setup.cfg`, `setup.py`, `*.csproj`, `constants.py`/`version.py`, `ABOUT.txt` или последнего Git-тега — отображается в столбце **Version**.

### 2. 🛡️ Стандартизированная структура проекта (Git Form)
- **Абсолютная безопасность**: Автоматически настраивает файлы `.gitignore` для конкретных языков, по умолчанию игнорируя учётные данные и ключи лицензий (например, `license.key`).
- **Генератор многоязычной документации**: Автоматически создаёт корневой `README.md` (на английском) и **9 версий на популярных языках** в `i18n/` с перекрёстными навигационными панелями.
- **Генератор лицензии MIT**: Динамически создаёт стандартный файл `LICENSE`, используя текущий год и настроенное имя автора (настраивается через UI / `config.ini`).
- **Утилита Push**: Включает скрипт `git_push.bat` / `git_push.sh` в каждый подпроект для быстрой ручной отправки изменений.

### 3. 📝 Умный движок авто-changelog коммитов
- **Автоматическая генерация темы**: Оставьте поле сообщения коммита пустым (или с подсказкой) — приложение автоматически сгенерирует описательную тему, например `"Update main.py, utils.py and 3 other files"`, анализируя staged diff.
- **Структурированное тело журнала изменений**: Каждый коммит автоматически добавляет раздел `Change Log:`, перечисляющий все изменённые, добавленные и удалённые файлы с их статусом (`M`, `A`, `D`, `R`).
- **Миграция устаревших настроек**: Существующие настройки, использующие старое сообщение по умолчанию `"Update project"`, автоматически мигрируют в новый режим пустого/авто-коммита.

Пример автоматически сгенерированного сообщения коммита:
```
Update main.py, config.ini and 2 other files

Change Log:
  M  modules/git_actions.py
  M  modules/ui/main_window.py
  A  modules/ui/dialogs.py
  D  temp_debug.txt
```

### 4. 🚀 Менеджер релизов — Публикация GitHub Releases *(Новое в v1.5.0)*
- **Релиз в один клик**: Каждая строка проекта с настроенным Git + удалённым репозиторием отображает кнопку **🚀 Release** во вкладке Local Workspace.
- **Автоматическая генерация тега**: Менеджер релизов автоматически подставляет имя тега из обнаруженной версии проекта (например, `v1.5.0`).
- **Прикрепление ресурсов**: Прикрепляйте любые файлы сборки (`.exe`, `.zip`, `.whl` и т.д.) к релизу с помощью файлового выборщика.
- **Фоновая публикация**: Создание релиза выполняется в фоновом потоке через `gh release create`, сохраняя отзывчивость интерфейса.
- **Статус в реальном времени**: Состояние кнопки обновляется в реальном времени: `⏳ Pushing...` → `✅ Released` при успехе, с всплывающей подсказкой об ошибке при неудаче.

### 5. ☁️ Вкладка GitHub Cloud — Коммиты и Релизы *(Обновлено в v1.5.0)*

#### 🕐 История коммитов и загрузка
- **История коммитов по репозиторию**: Каждая строка проекта отображает кнопку **🕐 Commits**, открывающую полный диалог истории коммитов.
- **Диалог истории коммитов**: Безрамочный диалог в стиле macOS, отображающий SHA · Бейдж тега/версии · Автор · Дата · Тема (наведите мышь для полного сообщения).
- **Загрузка ZIP по коммиту**: Каждая строка коммита имеет кнопку **⬇ sha**, которая:
  1. Загружает снимок ZIP напрямую в `~/Downloads/{repo}_{sha7}.zip` через GitHub CLI.
  2. После загрузки открывает **Проводник с выделенным файлом** (`explorer /select,file`).
  3. Пропускает повторную загрузку, если файл уже существует локально.
  4. Статус кнопки в реальном времени: `⏳ Downloading...` → `✅ sha7` при успехе.

#### 📦 Браузер релизов и загрузка *(Новое в v1.5.0)*
- **Список релизов по репозиторию**: Каждая строка проекта отображает кнопку **📦 Releases**, открывающую специальный диалог браузера релизов.
- **Диалог браузера релизов**: Безрамочный диалог в стиле macOS, перечисляющий все GitHub Releases с:
  - Тег / Название · Дата · Тип (Стабильный / Предварительный / Черновик) · Количество ресурсов
- **Загрузка ресурсов**: Каждая строка релиза отображает кнопки загрузки для каждого прикреплённого ресурса (до 3 видимых):
  - Загружает напрямую в `~/Downloads/` через `urllib`.
  - При отсутствии ресурсов переключается на загрузку **исходного ZIP**.
  - После загрузки открывает Проводник с выделенным файлом.
  - Статус кнопки в реальном времени: `⏳` → `✅ Done` при успехе, `⬇ Retry` при неудаче.
- **Потокобезопасные обновления UI**: Все операции загрузки используют эмиссию Qt `Signal` из рабочих потоков.

### 6. 🎨 Интерфейс Liquid Glass — Макет и элементы управления
- **Оптимизированные соотношения панелей**: Дерево статуса Git проектов занимает **4/6** высоты правой панели; консоль Live Git — **2/6**, обеспечивая дереву значительно больше пространства для отображения.
- **Единый заголовок консоли**: Метка «LIVE GIT CONSOLE» и кнопка «Clear Console» теперь расположены в одной строке панели инструментов.
- **Элементы управления окном в стиле macOS**: Все диалоги имеют красные/зелёные кнопки-светофоры (🔴 Закрыть, 🟢 Развернуть/Восстановить), безрамочный макет со скруглёнными углами и поддержку перетаскивания.
- **Фильтрация по статусу**: Кнопки фильтрации (`Has .git`, `No .git`, `Missing Form`, `Not Cloned`, `Behind Cloud`) для быстрого выбора.
- **Скрытие проектов (переключатель глаза)**: Скрывайте ненужные проекты из дерева и боковой панели с сохранением в `config.ini`.
- **Живая консоль**: Отображает вывод всех фоновых Git-операций в реальном времени.
- **Столбцы кнопок фиксированной ширины**: Столбцы Commits и Releases используют режим `QHeaderView.Fixed` — они никогда не растягиваются при изменении размера или разворачивании окна.

### 7. ⚙️ Кроссплатформенный гибридный движок
- **Динамическая маршрутизация по ОС**: Определяет хост-ОС во время выполнения (Windows, macOS, Linux) и направляет системные операции к нативным оптимизированным компонентам через `native_bridge.py`.
  - **Windows**: Win32 API / PowerShell / опциональная C++ DLL (`modules/native/win_core.py`)
  - **macOS**: Objective-C / AppleScript / опциональная `.dylib` (`modules/native/mac_core.py`)
  - **Linux**: Bash / опциональная разделяемая библиотека `.so` (`modules/native/linux_core.py`)
- **Безопасный откат выполнения**: Автоматически переключается на чистый Python при отсутствии нативных компонентов — никаких сбоев, максимальная совместимость.
- **Кроссплатформенные стартовые скрипты**: Предоставляются `run.bat` / `run.sh` и `setup_venv.sh` для Windows и Unix-подобных систем.

```
modules/
├── ui/                        # PySide6 GUI layer
├── native/                    # Hybrid Engine Core
│   ├── win_core.py            # Windows: Win32 API, DLL, PowerShell
│   ├── mac_core.py            # macOS: Objective-C, dylib, AppleScript
│   └── linux_core.py          # Linux: Bash, .so shared library
├── native_bridge.py           # Dynamic OS router (singleton)
├── git_actions.py             # Git operations + auto-changelog
├── github_ops.py              # GitHub CLI + commit/release API
├── project_scan.py            # Project scanner + version detector
├── project_model.py           # ProjectInfo dataclass
├── git_runner.py              # Background thread runner
├── constants.py               # App-wide constants (APP_VERSION)
└── utils.py / i18n_ui.py      # Settings + 10-language translations
```

### 8. 🔄 Автоматическая синхронизация с облаком и сохранение выбора
- **Автоматическое облачное получение при запуске**: Получает статусы облачных репозиториев GitHub в фоновом режиме после локального сканирования.
- **Сохранение выбора**: Запоминает состояния чекбоксов между запусками через `config.ini`.
- **Просмотр нескольких коммитов на репозиторий**: Полная история коммитов (до 30 коммитов с аннотациями тегов) по запросу.

### 9. 👤 Автоматическая настройка идентификации Git
- **Коммит без настройки**: Обнаруживает отсутствующие `user.name` / `user.email` Git и автоматически настраивает их из профиля GitHub через `gh`.

---

<a id="setup"></a>
## 🚀 Установка и настройка

### Системные требования

| Компонент | Минимальная версия | Примечания |
|---|---|---|
| Python | 3.13 | Убедитесь, что отмечен пункт «Add Python to PATH» |
| GitHub CLI (`gh`) | 2.92.0 | Аутентификация через `gh auth login` |
| Git Credential Manager | 2.8.0 | Безопасная аутентификация при push |

> ⚠️ **Важно**: Если системная переменная окружения `GITHUB_TOKEN` содержит истёкшее или недействительное значение, приложение автоматически удаляет её перед вызовом `gh api`, чтобы предотвратить ошибки аутентификации.

<a id="quick-start"></a>
### Пошаговая установка

#### Шаг 1: Установите необходимые компоненты

1. **Python 3.13+** — [Скачать (официально)](https://www.python.org/downloads/)
2. **GitHub CLI 2.92.0** — избегайте уязвимостей инъекций терминала в старых версиях:
   - [Скачать gh_2.92.0_windows_amd64.msi](https://github.com/cli/cli/releases/download/v2.92.0/gh_2.92.0_windows_amd64.msi)
3. **Git Credential Manager 2.8.0**:
   - [Скачать gcm-win-x64-2.8.0.exe](https://github.com/git-ecosystem/git-credential-manager/releases/download/v2.8.0/gcm-win-x64-2.8.0.exe)

#### Шаг 2: Клонируйте репозиторий
```cmd
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY
```

#### Шаг 3: Установите зависимости Python
```cmd
pip install -r requirements.txt
```

#### Шаг 4: Аутентификация GitHub CLI
```cmd
gh auth login
```
*(Выберите браузерную или SSH-аутентификацию в соответствии с вашими предпочтениями.)*

#### Шаг 5: Запустите приложение

**Windows:**
```cmd
run.bat
```
**macOS / Linux:**
```bash
chmod +x run.sh && ./run.sh
```

---

<a id="config"></a>
## ⚙️ Конфигурация

### `config.ini` — Основные настройки
```ini
[settings]
root_dir       = D:\Workspaces\MyProjects   ; Корневая директория для сканирования
remote_base    = github.com/username         ; Ваше имя пользователя GitHub
branch         = main                        ; Ветка по умолчанию
commit_message =                             ; Пусто = авто-генерация темы и changelog
max_depth      = 3                           ; Максимальная глубина сканирования
auto_create_repo = yes                       ; Авто-создание репозитория GitHub при отсутствии
```

> 💡 **Совет**: Оставьте `commit_message` пустым, чтобы активировать режим **Auto-Changelog**. Приложение автоматически сгенерирует описательную тему и полное тело `Change Log:` из staged diff.

### `config.json` — Расширенные настройки синхронизации
```json
{
  "git": {
    "default_branch": "main",
    "default_commit_message": "",
    "auto_create_github_repo": true
  }
}
```

---

## 🗂️ Структура проекта

```
JA_AUTO_GIT/
├── main.py                    # Точка входа
├── run.bat / run.sh           # Скрипты быстрого запуска (Windows / Unix)
├── setup_venv.sh              # Настройка виртуального окружения (Unix)
├── requirements.txt
├── config.ini                 # Пользовательские настройки
├── config.json                # Расширенные настройки
├── assets/                    # Иконки и изображения
├── i18n/                      # Локализованные README (9 языков)
├── logs/                      # Логи времени выполнения
└── modules/
    ├── ui/
    │   ├── main_window.py     # Главное окно приложения
    │   ├── dialogs.py         # Все диалоги (Commit, Release, Cloud Release)
    │   └── styles.py          # Стилевая таблица Liquid Glass
    ├── native/                # Кроссплатформенный гибридный движок
    │   ├── win_core.py
    │   ├── mac_core.py
    │   └── linux_core.py
    ├── native_bridge.py       # Маршрутизатор ОС (singleton)
    ├── git_actions.py         # Операции Git + авто-changelog
    ├── github_ops.py          # GitHub CLI + API коммитов/релизов
    ├── project_scan.py        # Сканер проектов + детектор версий
    ├── project_model.py       # Датакласс ProjectInfo
    ├── git_runner.py          # Запуск фоновых потоков
    ├── constants.py           # Глобальные константы (APP_VERSION = "1.5.0")
    └── utils.py               # Загрузка/сохранение настроек + миграции
```

---

## 📋 История изменений

### v1.5.0 *(Последняя)*
- ✨ **Менеджер релизов**: Публикация GitHub Releases с тегом + ресурсами из вкладки Local Workspace
- ✨ **Браузер релизов**: Просмотр и загрузка GitHub Releases (с ресурсами) из вкладки Cloud
- ✨ **Столбец версии**: Автоматически определяет версию проекта из файлов пакета или тегов git
- 🔧 **Столбцы кнопок фиксированной ширины**: Столбцы Commits и Releases больше не растягиваются при изменении размера окна
- 🔧 **QHeaderView.Fixed**: Применено ко всем столбцам кнопок в обеих вкладках рабочего пространства

### v1.4.0
- ✨ **Диалог истории коммитов**: История коммитов по репозиторию с загрузкой ZIP по коммиту
- ✨ **Движок авто-changelog**: Автоматически генерирует тему коммита + тело журнала изменений
- 🔧 **Потокобезопасные загрузки**: Кроссопоточные обновления UI через Qt Signal/Slot

### v1.3.0
- ✨ **Кроссплатформенный гибридный движок**: Нативный мост для Windows/macOS/Linux
- ✨ **Скрытие проектов**: Переключатель глаза с сохранением в конфигурации
- 🔧 **Элементы управления окном в стиле macOS**: Унификация для всех диалогов

---

<a id="license"></a>
## 📜 Лицензия и авторские права

Этот проект распространяется под лицензией **MIT**. Подробности смотрите в файле [LICENSE](LICENSE).

Copyright John Alaa @ 2026.
