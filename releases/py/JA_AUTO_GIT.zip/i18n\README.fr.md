# 🤖 JA Auto Git — Liquid Glass Edition

<p align="center">
  <img src="../assets/images/icon.ico" alt="JA Auto Git Logo" width="120" height="120">
  <br>
  <i>Gestion automatisée de Git & créateur intelligent de dépôts GitHub pour les développeurs.</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=for-the-badge&logo=python&logoColor=white" alt="Python Version">
  <img src="https://img.shields.io/badge/GUI-PySide6-green.svg?style=for-the-badge&logo=qt&logoColor=white" alt="UI Framework">
  <img src="https://img.shields.io/badge/Integrations-GitHub_CLI-purple.svg?style=for-the-badge&logo=github&logoColor=white" alt="Integrations">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge" alt="License">
  <img src="https://img.shields.io/badge/Platform-Windows_%7C_macOS_%7C_Linux-0078D6.svg?style=for-the-badge&logo=windows&logoColor=white" alt="Platform">
  <img src="https://img.shields.io/badge/Version-1.5.0-orange.svg?style=for-the-badge" alt="Version">
</p>

<p align="center"><a href="#demarrage-rapide">🚀 Démarrage Rapide</a> • <a href="#fonctionnalites">💡 Fonctionnalités</a> • <a href="#installation">📖 Installation</a> • <a href="https://jatechvn.github.io/">🌐 Site Web</a></p>

<p align="center"><a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="README.zh-CN.md">🇨🇳 中文</a> • <a href="README.ja-JP.md">🇯🇵 日本語</a> • <a href="README.es.md">🇪🇸 Español</a> • 🇫🇷 Français • <a href="README.de.md">🇩🇪 Deutsch</a> • <a href="README.ru.md">🇷🇺 Русский</a> • <a href="README.pt.md">🇵🇹 Português</a> • <a href="README.ko.md">🇰🇷 한국어</a></p>

---

<a id="introduction"></a>
## 🌟 Introduction

**JA Auto Git** est un outil GUI professionnel qui simplifie la configuration du contrôle de version et le stockage distant GitHub pour plusieurs sous-projets simultanément. Conçu pour les développeurs gérant plusieurs mini-projets (scripts Python, packages Node.js, scripts AutoHotkey, applications .NET), il automatise la standardisation des répertoires et le déploiement de dépôts privés sur GitHub en quelques clics.

Avec son style de design **Liquid Glass** et ses contrôles de fenêtre inspirés de macOS, l'interface offre une expérience moderne et intuitive qui maximise la productivité des développeurs sur Windows, macOS et Linux.

## 📸 Captures d'écran

<p align="center">
  <img src="../assets/images/screenshot_dark.png" alt="JA Auto Git Thème Sombre" width="48%">
  <img src="../assets/images/screenshot_light.png" alt="JA Auto Git Thème Clair" width="48%">
</p>

---

<a id="workflow"></a>
## 📊 Flux de travail

```mermaid
graph TD
    A[Launch JA Auto Git] --> B[Scan working directory up to max depth]
    B --> C[Analyze & detect project types + versions]
    C --> D{Check project status}
    D -->|Missing .git / gitignore / README / LICENSE| E[Show warning in UI tree]
    D -->|Standard files present| F[Show Standard OK status]
    E --> G[User selects projects → CREATE / EDIT GIT FORM]
    G --> H[Init Git · create .gitignore · write LICENSE · generate 10-lang READMEs]
    H --> I[User types Commit Message or leaves blank for auto-message]
    I --> J[Auto-generate subject + structured Change Log from staged diff]
    J --> K[Auto-create Private Repo on GitHub if missing · Push via GitHub CLI]
    K --> L[Update status · Auto-sync Cloud tab]
    L --> M{GitHub Cloud tab}
    M --> N[View per-repo Commit History · Download any commit ZIP]
    M --> O[View GitHub Releases · Download release assets to ~/Downloads]
    K --> P[Push GitHub Release with tag + assets via Release Manager]
```

---

<a id="fonctionnalites"></a>
## ✨ Fonctionnalités Clés

### 1. 🔍 Scanner Dynamique de Projets
- **Détection Automatique de la Pile Technologique** : Analyse les signatures de fichiers pour identifier le type de projet (Python, Node.js, AHK, .NET, Batch/PowerShell).
- **Analyse Récursive** : Parcourt les répertoires jusqu'à une profondeur configurée, en ignorant automatiquement les grands répertoires système/dépendances tels que `node_modules`, `.venv`, `__pycache__`, `dist`.
- **Traitement Parallèle Multi-cœur** : Les opérations d'analyse exploitent le multi-threading pour utiliser simultanément tous les cœurs CPU disponibles, maintenant l'interface entièrement réactive.
- **Détection Automatique de Version** : Détecte automatiquement la version de chaque projet depuis `package.json`, `pyproject.toml`, `setup.cfg`, `setup.py`, `*.csproj`, `constants.py`/`version.py`, `ABOUT.txt`, ou le dernier tag Git — affichée dans la colonne **Version**.

### 2. 🛡️ Structure de Projet Standardisée (Formulaire Git)
- **Sécurité Absolue** : Configure automatiquement des fichiers `.gitignore` spécifiques au langage, ignorant par défaut les identifiants et clés de licence (ex. `license.key`).
- **Générateur de Documents Multi-langues** : Crée automatiquement un `README.md` racine (en anglais) et **9 versions en langues populaires** dans `i18n/` avec des barres de navigation croisées.
- **Générateur de Licence MIT** : Génère un fichier `LICENSE` standard dynamiquement en utilisant l'année courante et le nom d'auteur configuré (personnalisable via l'interface / `config.ini`).
- **Utilitaire de Push** : Inclut un script `git_push.bat` / `git_push.sh` dans chaque sous-projet pour un push manuel rapide.

### 3. 📝 Moteur de Commit Auto-Changelog Intelligent
- **Génération Automatique du Sujet** : Laissez le message de commit vide (ou comme espace réservé) et l'application génère automatiquement une ligne de sujet descriptive telle que `"Update main.py, utils.py and 3 other files"` en analysant le diff stagé.
- **Corps du Journal des Modifications Structuré** : Chaque commit ajoute automatiquement une section `Change Log:` listant tous les fichiers modifiés, ajoutés et supprimés avec leur statut (`M`, `A`, `D`, `R`).
- **Migration Legacy** : Les paramètres existants utilisant l'ancien message par défaut `"Update project"` sont silencieusement migrés vers le nouveau workflow de commit vide/automatique.

Exemple de message de commit auto-généré :
```
Update main.py, config.ini and 2 other files

Change Log:
  M  modules/git_actions.py
  M  modules/ui/main_window.py
  A  modules/ui/dialogs.py
  D  temp_debug.txt
```

### 4. 🚀 Gestionnaire de Releases — Publier des Releases GitHub *(Nouveau dans v1.5.0)*
- **Release en Un Clic** : Chaque ligne de projet avec Git + remote configurés affiche un bouton **🚀 Release** dans l'onglet Espace de Travail Local.
- **Génération Automatique de Tag** : Le Gestionnaire de Releases remplit automatiquement le nom du tag depuis la version détectée du projet (ex. `v1.5.0`).
- **Attachement d'Assets** : Joignez n'importe quels fichiers de build (`.exe`, `.zip`, `.whl`, etc.) à la release avec un sélecteur de fichiers.
- **Push en Arrière-plan** : La création de release s'exécute dans un thread d'arrière-plan via `gh release create`, maintenant l'interface réactive.
- **Statut en Temps Réel** : Les états des boutons se mettent à jour en direct : `⏳ Pushing...` → `✅ Released` en cas de succès, avec une info-bulle d'erreur en cas d'échec.

### 5. ☁️ Onglet GitHub Cloud — Commits & Releases *(Mis à jour dans v1.5.0)*

#### 🕐 Historique des Commits & Téléchargement
- **Historique des Commits par Dépôt** : Chaque ligne de projet affiche un bouton **🕐 Commits** qui ouvre une boîte de dialogue complète de l'historique des commits.
- **Boîte de Dialogue de l'Historique** : Boîte de dialogue sans cadre de style macOS affichant SHA · Badge Tag/Version · Auteur · Date · Sujet (survol pour le message complet).
- **Téléchargement ZIP par Commit** : Chaque ligne de commit possède un bouton **⬇ sha** qui :
  1. Télécharge le snapshot ZIP directement dans `~/Downloads/{repo}_{sha7}.zip` via GitHub CLI.
  2. Après le téléchargement, ouvre **l'Explorateur avec le fichier sélectionné** (`explorer /select,file`).
  3. Ignore le re-téléchargement si le fichier existe déjà localement.
  4. États du bouton en temps réel : `⏳ Downloading...` → `✅ sha7` en cas de succès.

#### 📦 Navigateur de Releases & Téléchargement *(Nouveau dans v1.5.0)*
- **Liste des Releases par Dépôt** : Chaque ligne de projet affiche un bouton **📦 Releases** ouvrant une boîte de dialogue dédiée au Navigateur de Releases.
- **Boîte de Dialogue du Navigateur de Releases** : Boîte de dialogue sans cadre de style macOS listant toutes les Releases GitHub avec :
  - Tag / Nom · Date · Type (Stable / Pré-release / Brouillon) · Nombre d'assets
- **Téléchargement par Asset** : Chaque ligne de release affiche des boutons de téléchargement pour chaque asset attaché (jusqu'à 3 visibles) :
  - Téléchargement direct dans `~/Downloads/` via `urllib`.
  - Repli sur le téléchargement du **ZIP source** si aucun asset n'est attaché.
  - Ouvre l'Explorateur avec le fichier sélectionné après le téléchargement.
  - États du bouton en temps réel : `⏳` → `✅ Done` en cas de succès, `⬇ Retry` en cas d'échec.
- **Mises à jour UI Thread-safe** : Toutes les opérations de téléchargement utilisent l'émission de `Signal` Qt depuis les threads workers.

### 6. 🎨 Interface Liquid Glass — Mise en Page & Contrôles
- **Ratios de Panneaux Optimisés** : L'arborescence de statut Git du projet occupe **4/6** de la hauteur du panneau droit ; la Console Git en direct occupe **2/6** — donnant à l'arborescence beaucoup plus d'espace d'affichage.
- **En-tête de Console Unifié** : L'étiquette "LIVE GIT CONSOLE" et le bouton "Clear Console" partagent désormais une seule barre d'outils.
- **Contrôles de Fenêtre de Style macOS** : Toutes les boîtes de dialogue comportent des boutons feux tricolores rouge/vert (🔴 Fermer, 🟢 Maximiser/Restaurer), une mise en page sans cadre avec coins arrondis et la prise en charge du glisser-déplacer.
- **Filtrage de Statut** : Boutons de filtrage (`Has .git`, `No .git`, `Missing Form`, `Not Cloned`, `Behind Cloud`) pour une sélection rapide.
- **Masquage de Projets (Bascule Œil)** : Masquez les projets indésirables de l'arborescence et de la barre latérale avec persistance dans `config.ini`.
- **Console en Direct** : Affiche la sortie en temps réel de toutes les opérations Git en arrière-plan.
- **Colonnes de Boutons à Largeur Fixe** : Les colonnes Commits et Releases utilisent le mode `QHeaderView.Fixed` — elles ne s'étirent jamais lors du redimensionnement ou de la maximisation de la fenêtre.

### 7. ⚙️ Moteur Hybride Multiplateforme
- **Routage OS Dynamique** : Détecte le système d'exploitation hôte à l'exécution (Windows, macOS, Linux) et route les opérations système vers des composants optimisés natifs à la plateforme via `native_bridge.py`.
  - **Windows** : Win32 API / PowerShell / DLL C++ optionnelle (`modules/native/win_core.py`)
  - **macOS** : Objective-C / AppleScript / `.dylib` optionnel (`modules/native/mac_core.py`)
  - **Linux** : Bash / bibliothèque partagée `.so` optionnelle (`modules/native/linux_core.py`)
- **Repli d'Exécution Sécurisé** : Revient automatiquement au Python pur si les composants natifs sont absents — zéro crash, compatibilité maximale.
- **Scripts de Démarrage Multiplateformes** : `run.bat` / `run.sh` et `setup_venv.sh` fournis pour Windows et les systèmes de la famille Unix.

```
modules/
├── ui/                        # PySide6 GUI layer
├── native/                    # Hybrid Engine Core
│   ├── win_core.py            # Windows: Win32 API, DLL, PowerShell
│   ├── mac_core.py            # macOS: Objective-C, dylib, AppleScript
│   └── linux_core.py          # Linux: Bash, .so shared library
├── native_bridge.py           # Dynamic OS router (singleton)
├── git_actions.py             # Git operations + auto-changelog
├── github_ops.py              # GitHub CLI + commit/release API
├── project_scan.py            # Project scanner + version detector
├── project_model.py           # ProjectInfo dataclass
├── git_runner.py              # Background thread runner
├── constants.py               # App-wide constants (APP_VERSION)
└── utils.py / i18n_ui.py      # Settings + 10-language translations
```

### 8. 🔄 Synchronisation Cloud Automatique & Persistance de Sélection
- **Récupération Cloud Automatique au Démarrage** : Récupère les statuts des dépôts cloud GitHub en arrière-plan après l'analyse locale.
- **Persistance de Sélection** : Mémorise les états des cases à cocher entre les exécutions via `config.ini`.
- **Vue Multi-commit par Dépôt** : Historique complet des commits (jusqu'à 30 commits, avec annotations de tags) à la demande.

### 9. 👤 Configuration Automatique de l'Identité Git
- **Commit Zéro Configuration** : Détecte l'absence de `user.name` / `user.email` Git et les configure automatiquement depuis le profil GitHub via `gh`.

---

<a id="installation"></a>
## 🚀 Installation & Configuration

### Configuration Requise

| Composant | Version Minimale | Notes |
|---|---|---|
| Python | 3.13 | Assurez-vous que "Add Python to PATH" est coché |
| GitHub CLI (`gh`) | 2.92.0 | Authentifiez-vous via `gh auth login` |
| Git Credential Manager | 2.8.0 | Authentification push sécurisée |

> ⚠️ **Important** : Si une variable d'environnement système `GITHUB_TOKEN` est définie avec une valeur expirée ou invalide, l'application la supprime automatiquement avant d'appeler `gh api` pour éviter les échecs d'authentification.

<a id="demarrage-rapide"></a>
### Installation Étape par Étape

#### Étape 1 : Installer les prérequis

1. **Python 3.13+** — [Télécharger (officiel)](https://www.python.org/downloads/)
2. **GitHub CLI 2.92.0** — évitez les vulnérabilités d'injection terminal dans les anciennes versions :
   - [Télécharger gh_2.92.0_windows_amd64.msi](https://github.com/cli/cli/releases/download/v2.92.0/gh_2.92.0_windows_amd64.msi)
3. **Git Credential Manager 2.8.0** :
   - [Télécharger gcm-win-x64-2.8.0.exe](https://github.com/git-ecosystem/git-credential-manager/releases/download/v2.8.0/gcm-win-x64-2.8.0.exe)

#### Étape 2 : Cloner le dépôt
```cmd
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY
```

#### Étape 3 : Installer les dépendances Python
```cmd
pip install -r requirements.txt
```

#### Étape 4 : Authentifier GitHub CLI
```cmd
gh auth login
```
*(Sélectionnez l'authentification par navigateur ou SSH selon vos préférences.)*

#### Étape 5 : Lancer l'application

**Windows :**
```cmd
run.bat
```
**macOS / Linux :**
```bash
chmod +x run.sh && ./run.sh
```

---

<a id="config"></a>
## ⚙️ Configuration

### `config.ini` — Paramètres Principaux
```ini
[settings]
root_dir       = D:\Workspaces\MyProjects   ; Répertoire racine à analyser
remote_base    = github.com/username         ; Votre nom d'utilisateur GitHub
branch         = main                        ; Branche par défaut
commit_message =                             ; Vide = générer automatiquement le sujet & changelog
max_depth      = 3                           ; Profondeur d'analyse maximale
auto_create_repo = yes                       ; Créer automatiquement un dépôt GitHub si absent
```

> 💡 **Astuce** : Laissez `commit_message` vide pour activer le mode **Auto-Changelog**. L'application génèrera automatiquement un sujet descriptif et un corps `Change Log:` complet depuis le diff stagé.

### `config.json` — Paramètres de Synchronisation Avancés
```json
{
  "git": {
    "default_branch": "main",
    "default_commit_message": "",
    "auto_create_github_repo": true
  }
}
```

---

## 🗂️ Structure du Projet

```
JA_AUTO_GIT/
├── main.py                    # Point d'entrée
├── run.bat / run.sh           # Scripts de lancement rapide (Windows / Unix)
├── setup_venv.sh              # Configuration de l'environnement virtuel (Unix)
├── requirements.txt
├── config.ini                 # Paramètres utilisateur
├── config.json                # Paramètres avancés
├── assets/                    # Icônes & images
├── i18n/                      # READMEs localisés (9 langues)
├── logs/                      # Journaux d'exécution
└── modules/
    ├── ui/
    │   ├── main_window.py     # Fenêtre principale de l'application
    │   ├── dialogs.py         # Toutes les boîtes de dialogue (Commit, Release, Cloud Release)
    │   └── styles.py          # Feuille de style Liquid Glass
    ├── native/                # Moteur Hybride Multiplateforme
    │   ├── win_core.py
    │   ├── mac_core.py
    │   └── linux_core.py
    ├── native_bridge.py       # Routeur OS (singleton)
    ├── git_actions.py         # Opérations Git + auto-changelog
    ├── github_ops.py          # GitHub CLI + API commit/release
    ├── project_scan.py        # Scanner de projets + détecteur de version
    ├── project_model.py       # Dataclass ProjectInfo
    ├── git_runner.py          # Exécuteur de threads d'arrière-plan
    ├── constants.py           # Constantes globales de l'app (APP_VERSION = "1.5.0")
    └── utils.py               # Chargement/sauvegarde des paramètres + migrations
```

---

## 📋 Journal des Modifications

### v1.5.0 *(Dernière version)*
- ✨ **Gestionnaire de Releases** : Publier des Releases GitHub avec tag + assets depuis l'onglet Espace de Travail Local
- ✨ **Navigateur de Releases** : Voir et télécharger les Releases GitHub (avec assets) depuis l'onglet Cloud
- ✨ **Colonne Version** : Détecte automatiquement la version du projet depuis les fichiers de package ou les tags git
- 🔧 **Colonnes de boutons à largeur fixe** : Les colonnes Commits & Releases ne s'étirent plus lors du redimensionnement de la fenêtre
- 🔧 **QHeaderView.Fixed** : Appliqué à toutes les colonnes de boutons dans les deux onglets de l'espace de travail

### v1.4.0
- ✨ **Boîte de Dialogue de l'Historique des Commits** : Historique des commits par dépôt avec téléchargement ZIP par commit
- ✨ **Moteur Auto-Changelog** : Génère automatiquement le sujet du commit + le corps du Journal des Modifications
- 🔧 **Téléchargements thread-safe** : Mises à jour UI cross-thread via Qt Signal/Slot

### v1.3.0
- ✨ **Moteur Hybride Multiplateforme** : Pont natif pour Windows/macOS/Linux
- ✨ **Masquage de Projets** : Bascule œil avec persistance de configuration
- 🔧 **Contrôles de fenêtre de style macOS** : Toutes les boîtes de dialogue unifiées

---

<a id="license"></a>
## 📜 Licence & Droits d'Auteur

Ce projet est distribué sous la **Licence MIT**. Consultez le fichier [LICENSE](LICENSE) pour plus de détails.

Copyright John Alaa @ 2026.
