# 🤖 JA Auto Git — Liquid Glass Edition

<p align="center">
  <img src="../assets/images/icon.ico" alt="JA Auto Git Logo" width="120" height="120">
  <br>
  <i>Công cụ quản lý Git tự động & tạo GitHub Repository thông minh dành cho lập trình viên.</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=for-the-badge&logo=python&logoColor=white" alt="Python Version">
  <img src="https://img.shields.io/badge/GUI-PySide6-green.svg?style=for-the-badge&logo=qt&logoColor=white" alt="UI Framework">
  <img src="https://img.shields.io/badge/Integrations-GitHub_CLI-purple.svg?style=for-the-badge&logo=github&logoColor=white" alt="Integrations">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge" alt="License">
  <img src="https://img.shields.io/badge/Platform-Windows_%7C_macOS_%7C_Linux-0078D6.svg?style=for-the-badge&logo=windows&logoColor=white" alt="Platform">
  <img src="https://img.shields.io/badge/Version-1.5.0-orange.svg?style=for-the-badge" alt="Version">
</p>

<p align="center"><a href="#quick-start">🚀 Bắt đầu nhanh</a> • <a href="#features">💡 Tính năng</a> • <a href="#setup">📖 Cài đặt</a> • <a href="https://jatechvn.github.io/">🌐 Website</a></p>

<p align="center"><a href="../README.md">🇺🇸 English</a> • 🇻🇳 Tiếng Việt • <a href="README.zh-CN.md">🇨🇳 中文</a> • <a href="README.ja-JP.md">🇯🇵 日本語</a> • <a href="README.es.md">🇪🇸 Español</a> • <a href="README.fr.md">🇫🇷 Français</a> • <a href="README.de.md">🇩🇪 Deutsch</a> • <a href="README.ru.md">🇷🇺 Русский</a> • <a href="README.pt.md">🇵🇹 Português</a> • <a href="README.ko.md">🇰🇷 한국어</a></p>

---

## 🌟 Giới thiệu

**JA Auto Git** là công cụ GUI chuyên nghiệp giúp đơn giản hóa việc thiết lập kiểm soát phiên bản và lưu trữ từ xa trên GitHub cho nhiều dự án con cùng lúc. Được thiết kế dành cho các lập trình viên quản lý nhiều dự án nhỏ (script Python, gói Node.js, script AutoHotkey, ứng dụng .NET), công cụ này tự động hóa việc chuẩn hóa thư mục và triển khai kho lưu trữ riêng tư lên GitHub chỉ với vài cú nhấp chuột.

Với phong cách thiết kế **Liquid Glass** và điều khiển cửa sổ lấy cảm hứng từ macOS, giao diện mang lại trải nghiệm hiện đại, trực quan, giúp tối đa hóa năng suất của lập trình viên trên Windows, macOS và Linux.

## 📸 Ảnh chụp màn hình

<p align="center">
  <img src="../assets/images/screenshot_dark.png" alt="JA Auto Git Dark Theme" width="48%">
  <img src="../assets/images/screenshot_light.png" alt="JA Auto Git Light Theme" width="48%">
</p>

---

## 📊 Quy trình hoạt động

```mermaid
graph TD
    A[Launch JA Auto Git] --> B[Scan working directory up to max depth]
    B --> C[Analyze & detect project types + versions]
    C --> D{Check project status}
    D -->|Missing .git / gitignore / README / LICENSE| E[Show warning in UI tree]
    D -->|Standard files present| F[Show Standard OK status]
    E --> G[User selects projects → CREATE / EDIT GIT FORM]
    G --> H[Init Git · create .gitignore · write LICENSE · generate 10-lang READMEs]
    H --> I[User types Commit Message or leaves blank for auto-message]
    I --> J[Auto-generate subject + structured Change Log from staged diff]
    J --> K[Auto-create Private Repo on GitHub if missing · Push via GitHub CLI]
    K --> L[Update status · Auto-sync Cloud tab]
    L --> M{GitHub Cloud tab}
    M --> N[View per-repo Commit History · Download any commit ZIP]
    M --> O[View GitHub Releases · Download release assets to ~/Downloads]
    K --> P[Push GitHub Release with tag + assets via Release Manager]
```

---

## ✨ Tính năng nổi bật

### 1. 🔍 Trình quét dự án động
- **Tự động nhận diện công nghệ**: Phân tích chữ ký file để xác định loại dự án (Python, Node.js, AHK, .NET, Batch/PowerShell).
- **Quét đệ quy**: Quét thư mục đến độ sâu được cấu hình, tự động bỏ qua các thư mục hệ thống/phụ thuộc lớn như `node_modules`, `.venv`, `__pycache__`, `dist`.
- **Xử lý song song đa nhân**: Các thao tác quét tận dụng đa luồng để sử dụng đồng thời tất cả các nhân CPU, giữ cho giao diện luôn phản hồi mượt mà.
- **Tự động phát hiện phiên bản**: Tự động phát hiện phiên bản của từng dự án từ `package.json`, `pyproject.toml`, `setup.cfg`, `setup.py`, `*.csproj`, `constants.py`/`version.py`, `ABOUT.txt` hoặc thẻ Git mới nhất — hiển thị trong cột **Version**.

### 2. 🛡️ Chuẩn hóa cấu trúc dự án (Git Form)
- **Bảo mật tuyệt đối**: Tự động cấu hình file `.gitignore` theo từng ngôn ngữ, mặc định bỏ qua thông tin xác thực và khóa bản quyền (ví dụ: `license.key`).
- **Trình tạo tài liệu đa ngôn ngữ**: Tự động tạo `README.md` gốc (tiếng Anh) và **9 phiên bản ngôn ngữ phổ biến** trong thư mục `i18n/` với thanh điều hướng liên kết chéo.
- **Trình tạo giấy phép MIT**: Tạo file `LICENSE` chuẩn một cách động, sử dụng năm hiện tại và tên tác giả đã cấu hình (có thể tùy chỉnh qua giao diện / `config.ini`).
- **Tiện ích Push**: Bao gồm script `git_push.bat` / `git_push.sh` trong mỗi dự án con để push thủ công nhanh chóng.

### 3. 📝 Công cụ commit tự động thông minh với Changelog
- **Tự động tạo tiêu đề**: Để trống thông điệp commit (hoặc giữ nguyên placeholder), ứng dụng sẽ tự động tạo dòng tiêu đề mô tả như `"Update main.py, utils.py and 3 other files"` bằng cách phân tích diff đã staged.
- **Nội dung Change Log có cấu trúc**: Mỗi commit tự động thêm phần `Change Log:` liệt kê tất cả các file đã sửa đổi, thêm mới và xóa cùng trạng thái của chúng (`M`, `A`, `D`, `R`).
- **Di chuyển dữ liệu cũ**: Các cài đặt hiện có sử dụng thông điệp mặc định cũ `"Update project"` sẽ được tự động chuyển sang quy trình commit trống/tự động mới.

Ví dụ thông điệp commit được tạo tự động:
```
Update main.py, config.ini and 2 other files

Change Log:
  M  modules/git_actions.py
  M  modules/ui/main_window.py
  A  modules/ui/dialogs.py
  D  temp_debug.txt
```

### 4. 🚀 Release Manager — Đẩy GitHub Releases *(Mới trong v1.5.0)*
- **Phát hành một chạm**: Mỗi hàng dự án đã có Git + remote được cấu hình sẽ hiển thị nút **🚀 Release** trong tab Local Workspace.
- **Tự động tạo thẻ tag**: Release Manager tự động điền tên tag từ phiên bản dự án được phát hiện (ví dụ: `v1.5.0`).
- **Đính kèm tài nguyên**: Đính kèm bất kỳ file build nào (`.exe`, `.zip`, `.whl`, v.v.) vào bản phát hành bằng trình chọn file.
- **Đẩy nền**: Quá trình tạo bản phát hành chạy trong luồng nền qua `gh release create`, giữ cho giao diện luôn phản hồi.
- **Trạng thái thời gian thực**: Trạng thái nút cập nhật trực tiếp: `⏳ Pushing...` → `✅ Released` khi thành công, hiển thị tooltip lỗi khi thất bại.

### 5. ☁️ Tab GitHub Cloud — Commits & Releases *(Cập nhật trong v1.5.0)*

#### 🕐 Lịch sử Commit & Tải xuống
- **Lịch sử commit theo từng Repo**: Mỗi hàng dự án hiển thị nút **🕐 Commits** để mở hộp thoại lịch sử commit đầy đủ.
- **Hộp thoại lịch sử Commit**: Hộp thoại không viền theo phong cách macOS hiển thị SHA · Huy hiệu Tag/Version · Tác giả · Ngày · Tiêu đề (di chuột để xem thông điệp đầy đủ).
- **Tải ZIP theo từng Commit**: Mỗi hàng commit có nút **⬇ sha** thực hiện:
  1. Tải trực tiếp ảnh chụp ZIP vào `~/Downloads/{repo}_{sha7}.zip` qua GitHub CLI.
  2. Sau khi tải xong, mở **Explorer với file được tô sáng** (`explorer /select,file`).
  3. Bỏ qua việc tải lại nếu file đã tồn tại cục bộ.
  4. Trạng thái nút thời gian thực: `⏳ Downloading...` → `✅ sha7` khi thành công.

#### 📦 Trình duyệt Release & Tải xuống *(Mới trong v1.5.0)*
- **Danh sách Release theo từng Repo**: Mỗi hàng dự án hiển thị nút **📦 Releases** mở hộp thoại Release Browser chuyên dụng.
- **Hộp thoại Release Browser**: Hộp thoại không viền theo phong cách macOS liệt kê tất cả GitHub Releases với:
  - Tag / Tên · Ngày · Loại (Stable / Pre-release / Draft) · Số lượng tài nguyên
- **Tải xuống từng tài nguyên**: Mỗi hàng release hiển thị nút tải xuống cho từng tài nguyên đính kèm (tối đa 3 hiển thị):
  - Tải trực tiếp vào `~/Downloads/` qua `urllib`.
  - Dự phòng tải **ZIP nguồn** nếu không có tài nguyên đính kèm.
  - Mở Explorer với file được tô sáng sau khi tải xuống.
  - Trạng thái nút thời gian thực: `⏳` → `✅ Done` khi thành công, `⬇ Retry` khi thất bại.
- **Cập nhật UI an toàn đa luồng**: Tất cả thao tác tải xuống sử dụng phát tín hiệu Qt `Signal` từ các luồng worker.

### 6. 🎨 Liquid Glass UI — Bố cục & Điều khiển
- **Tỷ lệ panel được tối ưu**: Cây trạng thái Git dự án chiếm **4/6** chiều cao panel phải; Live Git Console chiếm **2/6**.
- **Header Console thống nhất**: Nhãn "LIVE GIT CONSOLE" và nút "Clear Console" dùng chung một hàng thanh công cụ.
- **Điều khiển cửa sổ phong cách macOS**: Tất cả hộp thoại có nút đèn giao thông đỏ/xanh, bố cục góc bo tròn không viền và hỗ trợ kéo để di chuyển.
- **Lọc theo trạng thái**: Các nút lọc (`Has .git`, `No .git`, `Missing Form`, `Not Cloned`, `Behind Cloud`) để chọn nhanh.
- **Ẩn dự án (Chuyển đổi mắt)**: Ẩn các dự án không cần thiết khỏi cây và thanh bên với tính năng lưu trữ trong `config.ini`.
- **Console trực tiếp**: Hiển thị đầu ra thời gian thực của tất cả các thao tác Git nền.
- **Cột nút có độ rộng cố định**: Cột Commits và Releases sử dụng chế độ `QHeaderView.Fixed` — không bao giờ bị kéo dãn khi thay đổi kích thước hoặc phóng to cửa sổ.

### 7. ⚙️ Lõi Engine Hybrid đa nền tảng
- **Định tuyến OS động**: Phát hiện hệ điều hành máy chủ lúc chạy và định tuyến các thao tác hệ thống đến các thành phần gốc của nền tảng qua `native_bridge.py`.
  - **Windows**: Win32 API / PowerShell / DLL C++ tùy chọn
  - **macOS**: Objective-C / AppleScript / `.dylib` tùy chọn
  - **Linux**: Bash / thư viện chia sẻ `.so` tùy chọn
- **Dự phòng thực thi an toàn**: Tự động quay về Python thuần túy nếu thiếu các thành phần gốc.
- **Script khởi động đa nền tảng**: Cung cấp `run.bat` / `run.sh` và `setup_venv.sh`.

### 8. 🔄 Đồng bộ Cloud tự động & Lưu trạng thái chọn
- **Tự động lấy Cloud khi khởi động**: Truy xuất trạng thái kho lưu trữ cloud GitHub trong nền sau khi quét cục bộ.
- **Lưu trạng thái chọn**: Ghi nhớ trạng thái checkbox qua các lần chạy via `config.ini`.
- **Xem nhiều commit theo từng Repo**: Lịch sử commit đầy đủ (tối đa 30 commit, có chú thích tag) theo yêu cầu.

### 9. 👤 Thiết lập danh tính Git tự động
- **Commit không cần cấu hình**: Phát hiện `user.name` / `user.email` Git bị thiếu và tự động cấu hình từ hồ sơ GitHub qua `gh`.

---

## 🚀 Cài đặt & Thiết lập

### Yêu cầu hệ thống

| Thành phần | Phiên bản tối thiểu | Ghi chú |
|---|---|---|
| Python | 3.13 | Đảm bảo chọn "Add Python to PATH" |
| GitHub CLI (`gh`) | 2.92.0 | Xác thực qua `gh auth login` |
| Git Credential Manager | 2.8.0 | Xác thực push bảo mật |

> ⚠️ **Quan trọng**: Nếu biến môi trường hệ thống `GITHUB_TOKEN` được đặt với giá trị hết hạn hoặc không hợp lệ, ứng dụng sẽ tự động loại bỏ nó trước khi gọi `gh api` để tránh lỗi xác thực.

### Hướng dẫn cài đặt từng bước

#### Bước 1: Cài đặt các điều kiện tiên quyết
1. **Python 3.13+** — [Tải xuống (chính thức)](https://www.python.org/downloads/)
2. **GitHub CLI 2.92.0** — [Tải gh_2.92.0_windows_amd64.msi](https://github.com/cli/cli/releases/download/v2.92.0/gh_2.92.0_windows_amd64.msi)
3. **Git Credential Manager 2.8.0** — [Tải gcm-win-x64-2.8.0.exe](https://github.com/git-ecosystem/git-credential-manager/releases/download/v2.8.0/gcm-win-x64-2.8.0.exe)

#### Bước 2: Clone kho lưu trữ
```cmd
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY
```

#### Bước 3: Cài đặt các phụ thuộc Python
```cmd
pip install -r requirements.txt
```

#### Bước 4: Xác thực GitHub CLI
```cmd
gh auth login
```

#### Bước 5: Khởi chạy ứng dụng
**Windows:** `run.bat`
**macOS / Linux:** `chmod +x run.sh && ./run.sh`

---

## ⚙️ Cấu hình

### `config.ini` — Cài đặt chính
```ini
[settings]
root_dir       = D:\Workspaces\MyProjects
remote_base    = github.com/username
branch         = main
commit_message =
max_depth      = 3
auto_create_repo = yes
```

> 💡 **Mẹo**: Để trống `commit_message` để kích hoạt chế độ **Auto-Changelog**.

---

## 📋 Nhật ký thay đổi

### v1.5.0 *(Mới nhất)*
- ✨ **Release Manager**: Đẩy GitHub Releases với tag + tài nguyên từ tab Local Workspace
- ✨ **Release Browser**: Xem và tải xuống GitHub Releases (kèm tài nguyên) từ tab Cloud
- ✨ **Cột Version**: Tự động phát hiện phiên bản dự án từ file package hoặc git tag
- 🔧 **Cột nút có độ rộng cố định**: Cột Commits & Releases không còn bị kéo dãn khi thay đổi kích thước cửa sổ
- 🔧 **QHeaderView.Fixed**: Áp dụng cho tất cả cột nút trong cả hai tab workspace

### v1.4.0
- ✨ **Hộp thoại lịch sử Commit**: Lịch sử commit theo từng repo với tính năng tải ZIP theo từng commit
- ✨ **Auto-Changelog Engine**: Tự động tạo tiêu đề commit + nội dung Change Log
- 🔧 **Tải xuống an toàn đa luồng**: Cập nhật UI qua Qt Signal/Slot giữa các luồng

### v1.3.0
- ✨ **Cross-platform Hybrid Engine**: Cầu nối gốc cho Windows/macOS/Linux
- ✨ **Ẩn dự án**: Chuyển đổi mắt với lưu trữ cấu hình
- 🔧 **Điều khiển cửa sổ phong cách macOS**: Thống nhất tất cả hộp thoại

---

## 📜 Giấy phép & Bản quyền

Dự án này được phân phối theo **Giấy phép MIT**. Xem file [LICENSE](LICENSE) để biết thêm chi tiết.

Bản quyền John Alaa @ 2026.
