<div align="center">

<img src="../assets/images/ja_auto_git_icon.png" alt="JA Auto Git Logo" width="140"/>

# 🚀 JA Auto Git

### Automação Git Profissional com Interface Liquid Glass

<a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="README.zh-CN.md">🇨🇳 中文</a> • <a href="README.ja-JP.md">🇯🇵 日本語</a> • <a href="README.es.md">🇪🇸 Español</a> • <a href="README.fr.md">🇫🇷 Français</a> • <a href="README.de.md">🇩🇪 Deutsch</a> • <a href="README.ru.md">🇷🇺 Русский</a> • 🇵🇹 Português • <a href="README.ko.md">🇰🇷 한국어</a>

![Version](https://img.shields.io/badge/version-1.5.0-blue?style=for-the-badge)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey?style=for-the-badge)
![Python](https://img.shields.io/badge/python-3.8%2B-yellow?style=for-the-badge)
![License](https://img.shields.io/badge/license-MIT-green?style=for-the-badge)

</div>

---

## ✨ Visão Geral

**JA Auto Git** é uma ferramenta de automação Git de nível profissional com uma interface **Liquid Glass** deslumbrante. Ela detecta automaticamente todos os seus projetos, identifica versões de forma inteligente, gera changelogs significativos e sincroniza com o GitHub — tudo com um único clique.

> 💡 **Desenvolvido para desenvolvedores que valorizam a eficiência e a elegância.**

---

## 🖼️ Capturas de Tela

<div align="center">

### Painel Principal
<img src="../assets/images/screenshot_main.png" alt="Painel Principal" width="780"/>

### Aba GitHub Cloud — Commits e Releases
<img src="../assets/images/screenshot_cloud.png" alt="GitHub Cloud" width="780"/>

</div>

---

## 🎯 Funcionalidades Principais

### 1. 🔍 Scanner Dinâmico de Projetos
- **Detecção automática de versão** a partir de `pyproject.toml`, `package.json`, `Cargo.toml`, `*.csproj`, `pom.xml`, `CMakeLists.txt` e muito mais
- Suporte a dezenas de tipos de projetos: Python, Node.js, Rust, C#, Java, C/C++, Go, Ruby, PHP, Swift, Kotlin e outros
- Exibe a **coluna de versão** diretamente na tabela de projetos para acesso rápido
- Atualiza dinamicamente sem necessidade de reiniciar o aplicativo

### 2. 📁 Estrutura de Projeto Padronizada
- Organiza seus repositórios em uma estrutura clara e rastreável
- Cada projeto é exibido com nome, caminho, branch atual e versão detectada
- Seleção múltipla de projetos para operações em lote

### 3. 🤖 Motor de Auto-Changelog Inteligente
- Analisa os commits recentes e gera mensagens de changelog estruturadas automaticamente
- Respeita o formato [Conventional Commits](https://www.conventionalcommits.org/)
- Categoriza mudanças em: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`
- Permite edição manual antes de confirmar

### 4. 🚀 Gerenciador de Releases *(Novo v1.5.0)*
- **Botão 🚀 Release** dedicado na interface principal
- Criação automática de **tag Git** com base na versão detectada do projeto
- **Anexar assets** personalizados (`.zip`, `.exe`, `.dmg`, etc.) ao release
- **Push em segundo plano** — a interface permanece responsiva enquanto o release é publicado
- Integração direta com a API do GitHub Releases

### 5. ☁️ Aba GitHub Cloud — Commits e Releases *(Atualizado v1.5.0)*
- **Histórico de commits**: visualize todos os commits remotos com hash, autor, data e mensagem
- **Download ZIP** do código-fonte de qualquer commit diretamente da interface
- **Navegador de Releases**: lista todos os releases publicados no GitHub com tags e notas
- **Download de assets** de qualquer release com um único clique
- Atualização automática após cada push ou criação de release

### 6. 🪟 Interface Liquid Glass
- Estética **Liquid Glass** com transparência, desfoque e reflexos suaves
- **Controles de janela no estilo macOS** (fechar, minimizar, maximizar) em todas as plataformas
- **Colunas de largura fixa** na tabela de projetos para uma exibição consistente e organizada
- Animações suaves e feedback visual em todas as interações

### 7. ⚙️ Motor Híbrido Multiplataforma
- Funciona perfeitamente em **Windows**, **macOS** e **Linux**
- Detecta automaticamente o ambiente e ajusta o comportamento da interface e dos comandos Git
- Sem dependências externas além do Python e Git instalados

### 8. 🔄 Sincronização Cloud Automática
- **Commit e push** em um único clique para qualquer branch
- Suporte a múltiplos repositórios remotos
- Exibe o status de sincronização em tempo real com barra de progresso
- Tratamento inteligente de conflitos e erros de autenticação

### 9. 🪪 Configuração Automática de Identidade Git
- Detecta e configura automaticamente `user.name` e `user.email` para cada repositório
- Evita erros de identidade ao realizar commits em múltiplos projetos com configurações diferentes
- Suporte a perfis de identidade por projeto

---

## 📦 Instalação

### Pré-requisitos
- Python 3.8 ou superior
- Git instalado e acessível no `PATH`
- Conta GitHub com token de acesso pessoal (para funcionalidades de cloud)

### Instalação Rápida

```bash
# Clone o repositório
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY

# Instale as dependências
pip install -r requirements.txt

# Execute o aplicativo
python main.py
```

### Configuração do Token GitHub

```bash
# Defina seu token de acesso pessoal do GitHub
# No aplicativo: Configurações → GitHub Token → Cole seu token
```

> ⚠️ **Nunca compartilhe seu token GitHub.** Use variáveis de ambiente ou o gerenciador de credenciais integrado.

---

## 🗂️ Estrutura do Projeto

```
JA_AUTO_GIT_PY/
├── main.py                  # Ponto de entrada principal
├── requirements.txt         # Dependências Python
├── assets/
│   └── images/              # Ícones e capturas de tela
├── core/
│   ├── scanner.py           # Scanner dinâmico de projetos
│   ├── git_engine.py        # Motor Git multiplataforma
│   ├── changelog.py         # Gerador de changelog automático
│   ├── release_manager.py   # Gerenciador de releases (v1.5.0)
│   └── cloud_sync.py        # Sincronização com GitHub
├── ui/
│   ├── main_window.py       # Janela principal Liquid Glass
│   ├── cloud_tab.py         # Aba GitHub Cloud (v1.5.0)
│   └── components/          # Componentes de interface reutilizáveis
└── i18n/                    # Traduções internacionais
```

---

## 🚀 Como Usar

### Fluxo Básico — Commit e Push

1. **Abra o JA Auto Git** — os projetos são detectados automaticamente
2. **Selecione um ou mais projetos** na tabela principal
3. **Edite a mensagem de changelog** gerada automaticamente (opcional)
4. Clique em **Commit & Push** 🚀
5. Acompanhe o progresso na barra de status

### Criar um Release

1. Selecione o projeto desejado
2. Clique no botão **🚀 Release**
3. Confirme a tag (detectada automaticamente a partir da versão do projeto)
4. Adicione assets opcionais (arquivos binários, ZIPs, etc.)
5. Clique em **Publicar Release** — o processo ocorre em segundo plano

### Explorar o GitHub Cloud

1. Acesse a aba **☁️ GitHub Cloud**
2. Selecione o repositório desejado
3. Navegue pelos **Commits** ou **Releases**
4. Clique em **⬇️ Download** para baixar ZIPs ou assets de release

---

## 📋 Changelog

### v1.5.0 *(Atual)*
- ✅ **Gerenciador de Releases**: criação de tags, anexo de assets e publicação em segundo plano
- ✅ **Navegador de Releases** na aba GitHub Cloud com download de assets
- ✅ **Coluna de Versão** na tabela de projetos com detecção automática
- ✅ **Colunas de largura fixa** para exibição consistente e organizada

### v1.4.0
- ✅ Aba GitHub Cloud com histórico de commits e download ZIP
- ✅ Suporte expandido a tipos de projeto (Rust, Swift, Kotlin, PHP)
- ✅ Melhorias de desempenho no scanner de projetos

### v1.3.0
- ✅ Interface Liquid Glass com controles de janela no estilo macOS
- ✅ Motor de Auto-Changelog com suporte a Conventional Commits
- ✅ Configuração automática de identidade Git por projeto

### v1.2.0
- ✅ Scanner Dinâmico de Projetos com detecção automática de versão
- ✅ Suporte multiplataforma (Windows, macOS, Linux)

### v1.0.0
- 🎉 Lançamento inicial

---

## 🤝 Contribuindo

Contribuições são bem-vindas! Sinta-se à vontade para abrir uma _issue_ ou enviar um _pull request_.

```bash
# Fork o repositório e clone localmente
git clone https://github.com/SEU_USUARIO/JA_AUTO_GIT_PY.git

# Crie uma branch para sua funcionalidade
git checkout -b feature/minha-nova-funcionalidade

# Faça suas alterações e commit
git commit -m "feat: adiciona minha nova funcionalidade"

# Envie sua branch
git push origin feature/minha-nova-funcionalidade
```

---

## 📄 Licença

Este projeto está licenciado sob a [Licença MIT](../LICENSE).

---

<div align="center">

Desenvolvido com ❤️ por **John Alaa**

© 2026 John Alaa @ JA Tech VN. Todos os direitos reservados.

</div>
