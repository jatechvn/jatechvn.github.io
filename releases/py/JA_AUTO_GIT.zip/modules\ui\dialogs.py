import os
import sys
import subprocess
import threading
from pathlib import Path

from PySide6.QtCore import Qt, Signal, QObject, QThread
from PySide6.QtGui import QFont, QColor
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFrame, QLabel, QHBoxLayout,
    QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QSizePolicy, QProgressBar, QWidget,
    QLineEdit, QTextEdit, QCheckBox, QFileDialog, QApplication,
)

from ..constants import FONT_PRIMARY
from ..i18n_ui import UI_TRANSLATIONS


class ConflictResolutionDialog(QDialog):
    def __init__(self, parent, repo_name, current_lang, is_dark):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.choice = "skip"

        t = UI_TRANSLATIONS[current_lang]

        # Layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)

        # Dialog frame
        frame = QFrame()
        frame.setObjectName("DialogFrame")

        # Border color and styling based on dark mode
        border = "rgba(255, 255, 255, 0.15)" if is_dark else "rgba(0, 0, 0, 0.15)"
        bg = "rgba(18, 18, 18, 0.95)" if is_dark else "rgba(240, 240, 240, 0.95)"
        text_color = "#ffffff" if is_dark else "#121212"
        accent_cyan = "#00f0ff"

        frame.setStyleSheet(f"""
            #DialogFrame {{
                background-color: {bg};
                border: 1px solid {border};
                border-radius: 12px;
            }}
            QLabel {{
                color: {text_color};
                font-family: '{FONT_PRIMARY}';
                font-size: 12px;
            }}
            QPushButton {{
                background-color: rgba({('255,255,255' if is_dark else '0,0,0')}, 0.05);
                color: {text_color};
                border: 1px solid {border};
                border-radius: 8px;
                padding: 8px 16px;
                font-family: '{FONT_PRIMARY}';
                font-weight: bold;
                font-size: 11px;
            }}
            QPushButton:hover {{
                border-color: {accent_cyan};
                background-color: rgba({('255,255,255' if is_dark else '0,0,0')}, 0.15);
            }}
        """)

        frame_layout = QVBoxLayout(frame)
        frame_layout.setSpacing(12)

        # Title
        lbl_title = QLabel(t["conflict_title"])
        lbl_title.setFont(QFont(FONT_PRIMARY, 12, QFont.Bold))
        lbl_title.setStyleSheet(f"color: {accent_cyan};")
        frame_layout.addWidget(lbl_title)

        # Message
        msg_text = t["conflict_message"].format(name=repo_name)
        lbl_msg = QLabel(msg_text)
        lbl_msg.setWordWrap(True)
        frame_layout.addWidget(lbl_msg)

        # Buttons
        h_buttons = QHBoxLayout()

        btn_overwrite = QPushButton(t["conflict_overwrite"])
        btn_overwrite.clicked.connect(self.select_overwrite)

        btn_stash = QPushButton(t["conflict_stash"])
        btn_stash.clicked.connect(self.select_stash)

        btn_skip = QPushButton(t["conflict_skip"])
        btn_skip.clicked.connect(self.select_skip)

        h_buttons.addWidget(btn_overwrite)
        h_buttons.addWidget(btn_stash)
        h_buttons.addWidget(btn_skip)

        frame_layout.addLayout(h_buttons)
        layout.addWidget(frame)

    def select_overwrite(self):
        self.choice = "overwrite"
        self.accept()

    def select_stash(self):
        self.choice = "stash"
        self.accept()

    def select_skip(self):
        self.choice = "skip"
        self.reject()


# ─────────────────────────────────────────────────────────────────────────────
# Commit History Dialog
# ─────────────────────────────────────────────────────────────────────────────

class _FetchWorker(QObject):
    """Background worker: fetches commits and emits result."""
    finished = Signal(list)   # list[dict]
    error    = Signal(str)

    def __init__(self, owner, repo_name):
        super().__init__()
        self.owner = owner
        self.repo_name = repo_name

    def run(self):
        try:
            from ..github_ops import get_github_commits
            commits = get_github_commits(self.owner, self.repo_name)
            self.finished.emit(commits)
        except Exception as exc:
            self.error.emit(str(exc))


class CommitHistoryDialog(QDialog):
    """
    Modal dialog displaying the commit history of a GitHub repository.
    Columns: #  |  SHA  |  Tag  |  Author  |  Date  |  Subject  |  Download
    """

    # Thread-safe signal: (btn, sha, dest_str or error_str, is_success)
    _dl_result = Signal(object, str, str, bool)

    def __init__(self, parent, owner: str, repo_name: str,
                 repo_url: str, current_lang: str, is_dark: bool,
                 btn_ref=None):
        """btn_ref: optional QPushButton in the cloud tree to update with commit count."""
        super().__init__(parent)
        self.owner = owner
        self.repo_name = repo_name
        self.repo_url = repo_url
        self.current_lang = current_lang
        self.is_dark = is_dark
        self.btn_ref = btn_ref
        self._thread = None
        self._worker = None
        self._dl_threads = []
        self._drag_pos = None

        # Connect download result signal (runs on main thread)
        self._dl_result.connect(self._apply_dl_result)

        self.setWindowTitle(f"Commits – {repo_name}")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.resize(920, 580)

        self._build_ui()
        self._start_fetch()

    # ── UI construction ──────────────────────────────────────────────────────

    def _build_ui(self):
        is_dark  = self.is_dark
        bg       = "rgba(15,15,20,0.97)"   if is_dark else "rgba(245,245,250,0.98)"
        surface  = "rgba(30,32,40,0.88)"   if is_dark else "rgba(255,255,255,0.92)"
        border   = "rgba(255,255,255,0.10)" if is_dark else "rgba(0,0,0,0.10)"
        fg       = "#e8eaf0"               if is_dark else "#1a1a2e"
        accent   = "#00f0ff"
        accent2  = "#7c3aed"
        sub_col  = "#8890a8"               if is_dark else "#666"

        self.setStyleSheet(f"""
            QDialog {{
                background: transparent;
            }}
            QFrame#DlgFrame {{
                background: {bg};
                border: 1px solid {border};
                border-radius: 12px;
            }}
            QFrame#DlgTitleBar {{
                background: transparent;
            }}
            QLabel#dlgTitle {{
                color: {accent};
                font-size: 14px;
                font-weight: 700;
                font-family: '{FONT_PRIMARY}';
            }}
            QLabel#dlgSub {{
                color: {sub_col};
                font-size: 11px;
                font-family: '{FONT_PRIMARY}';
            }}
            QTableWidget {{
                background: {surface};
                color: {fg};
                border: 1px solid {border};
                border-radius: 8px;
                gridline-color: {border};
                font-family: '{FONT_PRIMARY}';
                font-size: 11px;
                selection-background-color: rgba(0,240,255,0.12);
            }}
            QTableWidget::item {{
                padding: 4px 6px;
                color: {fg};
            }}
            QTableWidget::item:selected {{
                background: rgba(0,240,255,0.15);
            }}
            QHeaderView::section {{
                background: {"rgba(255,255,255,0.05)" if is_dark else "rgba(0,0,0,0.04)"};
                color: {accent};
                border: none;
                border-bottom: 1px solid {border};
                padding: 6px 8px;
                font-weight: 600;
                font-size: 11px;
                font-family: '{FONT_PRIMARY}';
            }}
            QScrollBar:vertical {{
                background: transparent;
                width: 6px;
            }}
            QScrollBar::handle:vertical {{
                background: {border};
                border-radius: 3px;
            }}
            QPushButton#btnDownload {{
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 {accent2}, stop:1 #9f5dfe);
                color: #fff;
                border: none;
                border-radius: 5px;
                padding: 3px 10px;
                font-size: 10px;
                font-weight: 600;
            }}
            QPushButton#btnDownload:hover {{
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 #9f5dfe, stop:1 {accent2});
            }}
            QPushButton#btnDownload:disabled {{
                background: rgba(120,120,120,0.3);
                color: rgba(255,255,255,0.5);
            }}
            QPushButton#btnCloseDialog {{
                background-color: #ff5f56;
                border: 1px solid #e0443e;
                border-radius: 8px;
                min-width: 16px;
                max-width: 16px;
                min-height: 16px;
                max-height: 16px;
            }}
            QPushButton#btnCloseDialog:hover {{ background-color: #ff7b72; }}
            QPushButton#btnMaxDialog {{
                background-color: #27c93f;
                border: 1px solid #1aab29;
                border-radius: 8px;
                min-width: 16px;
                max-width: 16px;
                min-height: 16px;
                max-height: 16px;
            }}
            QPushButton#btnMaxDialog:hover {{ background-color: #38e04f; }}
            QPushButton#btnFootClose {{
                background: rgba(255,255,255,0.06);
                color: {fg};
                border: 1px solid {border};
                border-radius: 6px;
                padding: 5px 18px;
                font-size: 11px;
                font-family: '{FONT_PRIMARY}';
            }}
            QPushButton#btnFootClose:hover {{ border-color: {accent}; }}
            QProgressBar {{
                background: {"rgba(255,255,255,0.06)" if is_dark else "rgba(0,0,0,0.06)"};
                border: none;
                border-radius: 3px;
            }}
            QProgressBar::chunk {{
                background: {accent};
                border-radius: 3px;
            }}
        """)

        # Outer transparent layout
        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)

        # Main frame (rounded card)
        self._frame = QFrame()
        self._frame.setObjectName("DlgFrame")
        outer.addWidget(self._frame)

        root = QVBoxLayout(self._frame)
        root.setContentsMargins(0, 0, 0, 14)
        root.setSpacing(0)

        # ── Title bar with macOS dots ─────────────────────────────────────────
        title_bar = QFrame()
        title_bar.setObjectName("DlgTitleBar")
        title_bar.setFixedHeight(38)
        h_title = QHBoxLayout(title_bar)
        h_title.setContentsMargins(12, 0, 12, 0)
        h_title.setSpacing(6)

        btn_close = QPushButton()
        btn_close.setFixedSize(16, 16)
        btn_close.setToolTip("Close")
        btn_close.setStyleSheet(
            "QPushButton{background:#ff5f56;border:1px solid #e0443e;border-radius:8px;}"
            "QPushButton:hover{background:#ff7b72;}"
        )
        btn_close.clicked.connect(self.reject)
        h_title.addWidget(btn_close)

        h_title.addSpacing(2)

        btn_max = QPushButton()
        btn_max.setFixedSize(16, 16)
        btn_max.setToolTip("Maximize / Restore")
        btn_max.setStyleSheet(
            "QPushButton{background:#27c93f;border:1px solid #1aab29;border-radius:8px;}"
            "QPushButton:hover{background:#38e04f;}"
        )
        btn_max.clicked.connect(self._toggle_max)
        h_title.addWidget(btn_max)

        h_title.addSpacing(14)

        lbl_title = QLabel(f"🕐  Commit History — {self.repo_name}")
        lbl_title.setObjectName("dlgTitle")
        h_title.addWidget(lbl_title)
        h_title.addStretch()
        lbl_url = QLabel(self.repo_url)
        lbl_url.setObjectName("dlgSub")
        h_title.addWidget(lbl_url)

        root.addWidget(title_bar)

        # Thin separator
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"background:{border}; max-height:1px; border:none;")
        root.addWidget(sep)

        # Content area
        content = QWidget()
        content_l = QVBoxLayout(content)
        content_l.setContentsMargins(14, 10, 14, 0)
        content_l.setSpacing(8)
        root.addWidget(content)

        # Loading bar
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setFixedHeight(3)
        self.progress.setTextVisible(False)
        content_l.addWidget(self.progress)

        # Status label
        self.lbl_status = QLabel("Loading commits…")
        self.lbl_status.setObjectName("dlgSub")
        content_l.addWidget(self.lbl_status)

        # Table
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["SHA", "Tag / Version", "Author", "Date", "Subject", "Download"]
        )
        self.table.horizontalHeader().setStretchLastSection(False)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(True)
        content_l.addWidget(self.table)

        # Footer
        h_foot = QHBoxLayout()
        self.lbl_count = QLabel("")
        self.lbl_count.setObjectName("dlgSub")
        h_foot.addWidget(self.lbl_count)
        h_foot.addStretch()
        btn_foot_close = QPushButton("✕  Close")
        btn_foot_close.setObjectName("btnFootClose")
        btn_foot_close.clicked.connect(self.reject)
        h_foot.addWidget(btn_foot_close)
        content_l.addLayout(h_foot)

    # ── Window drag + maximize support ────────────────────────────────────

    def _toggle_max(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def mousePressEvent(self, event):
        from PySide6.QtCore import QPoint, Qt
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        from PySide6.QtCore import QPoint, Qt
        if self._drag_pos is not None and event.buttons() == Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._drag_pos = None
        super().mouseReleaseEvent(event)

    # ── Background fetch ───────────────────────────────────────────────

    def _start_fetch(self):
        self._thread = QThread(self)
        self._worker = _FetchWorker(self.owner, self.repo_name)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.finished.connect(self._on_commits_ready)
        self._worker.error.connect(self._on_fetch_error)
        self._worker.finished.connect(self._thread.quit)
        self._worker.error.connect(self._thread.quit)
        self._thread.start()

    def _on_fetch_error(self, msg: str):
        self.progress.setVisible(False)
        self.lbl_status.setText(f"⚠  Error: {msg}")

    def _on_commits_ready(self, commits: list):
        self.progress.setVisible(False)
        self.lbl_status.setVisible(False)
        self._populate_table(commits)
        n = len(commits)
        self.lbl_count.setText(f"{n} commits loaded")
        # Update tree-row button with count
        if self.btn_ref is not None:
            try:
                self.btn_ref.setText(f"🕐 {n} Commits")
            except RuntimeError:
                pass  # widget already destroyed

    # ── Table population ─────────────────────────────────────────────────────

    def _populate_table(self, commits: list):
        accent   = "#00f0ff"
        tag_bg   = "rgba(124,58,237,0.25)"
        tag_fg   = "#c084fc"

        self.table.setRowCount(len(commits))
        for row, c in enumerate(commits):
            self.table.setRowHeight(row, 30)

            # SHA (short, monospace tooltip = full)
            sha_item = QTableWidgetItem(c["short_sha"])
            sha_item.setToolTip(c["sha"])
            sha_item.setForeground(QColor(accent))
            sha_item.setFont(QFont("Consolas", 10))
            self.table.setItem(row, 0, sha_item)

            # Tag / Version badge
            tag_text = c["tag"] if c["tag"] else "—"
            tag_item = QTableWidgetItem(tag_text)
            if c["tag"]:
                tag_item.setForeground(QColor(tag_fg))
                tag_item.setFont(QFont(FONT_PRIMARY, 10, QFont.Bold))
            self.table.setItem(row, 1, tag_item)

            # Author
            self.table.setItem(row, 2, QTableWidgetItem(c["author"]))

            # Date
            self.table.setItem(row, 3, QTableWidgetItem(c["date"]))

            # Subject (tooltip = full message)
            subj_item = QTableWidgetItem(c["subject"])
            subj_item.setToolTip(c["message"])
            self.table.setItem(row, 4, subj_item)

            # Download button
            sha_full = c["sha"]
            btn = QPushButton(f"\u2b07  {c['short_sha']}")
            btn.setObjectName("btnDownload")
            btn.setToolTip(f"Download ZIP of commit {sha_full[:7]} to ~/Downloads")

            def _make_downloader(sha_cap, btn_cap, dialog_ref):
                def _do_download():
                    from ..github_ops import find_gh
                    downloads = Path.home() / "Downloads"
                    downloads.mkdir(parents=True, exist_ok=True)
                    dest = downloads / f"{dialog_ref.repo_name}_{sha_cap[:7]}.zip"

                    # File already exists → signal success immediately
                    if dest.exists():
                        dialog_ref._dl_result.emit(btn_cap, sha_cap[:7], str(dest), True)
                        return

                    try:
                        gh = find_gh()
                        if not gh:
                            raise RuntimeError("GitHub CLI (gh) not found")

                        env = {k: v for k, v in os.environ.items() if k != "GITHUB_TOKEN"}
                        proc = subprocess.run(
                            [gh, "api",
                             f"repos/{dialog_ref.owner}/{dialog_ref.repo_name}/zipball/{sha_cap}"],
                            capture_output=True,
                            env=env,
                            timeout=120,
                        )
                        if proc.returncode != 0:
                            err = proc.stderr.decode(errors="replace").strip()
                            raise RuntimeError(err or f"gh api returned code {proc.returncode}")

                        with open(dest, "wb") as fh:
                            fh.write(proc.stdout)

                        dialog_ref._dl_result.emit(btn_cap, sha_cap[:7], str(dest), True)

                    except Exception as exc:
                        dialog_ref._dl_result.emit(btn_cap, sha_cap[:7], str(exc), False)

                return _do_download

            _downloader = _make_downloader(sha_full, btn, self)

            def _on_btn_click(checked=False, b=btn, fn=_downloader):
                b.setEnabled(False)
                b.setText("\u23f3 Downloading...")
                threading.Thread(target=fn, daemon=True).start()

            btn.clicked.connect(_on_btn_click)
            cell = QWidget()
            lay  = QHBoxLayout(cell)
            lay.setContentsMargins(4, 2, 4, 2)
            lay.addWidget(btn)
            self.table.setCellWidget(row, 5, cell)


    # ── Download result (runs on main thread via Signal) ──────────────────────

    def _apply_dl_result(self, btn, short_sha: str, info: str, success: bool):
        """Runs on main thread via Signal. Updates button and opens folder on success."""
        downloads = Path.home() / "Downloads"
        try:
            if success:
                btn.setText(f"\u2705 {short_sha}")
                btn.setToolTip(f"Saved: {info}")
                _open_folder(downloads, Path(info))
            else:
                btn.setText(f"\u2b07  {short_sha}")
                btn.setEnabled(True)
                btn.setToolTip(f"Error: {info}")
        except RuntimeError:
            pass  # widget destroyed


def _open_folder(folder: Path, file: Path):
    """Open the Downloads folder (and highlight the file on Windows)."""
    try:
        if sys.platform == "win32":
            subprocess.Popen(["explorer", f"/select,{file}"])
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", str(file)])
        else:
            subprocess.Popen(["xdg-open", str(folder)])
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# Release Dialog
# ─────────────────────────────────────────────────────────────────────────────

class ReleaseDialog(QDialog):
    """
    Dialog to create and push a GitHub Release for a local project.
    Features:
      - Auto-suggest next tag from latest git tag (patch bump)
      - Browse to attach optional build files (.exe, .zip, .msi, ...)
      - Background thread via Signal for thread-safe UI feedback
    """

    _release_result = Signal(bool, str)   # (success, message)

    def __init__(self, parent, project: dict, is_dark: bool):
        super().__init__(parent)
        self.project   = project           # dict with 'path', 'name', 'branch', etc.
        self.is_dark   = is_dark
        self._drag_pos = None
        self._attach_path = ""             # optional file to attach

        self.setWindowTitle(f"Release \u2013 {project['name']}")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.resize(560, 480)

        self._release_result.connect(self._on_release_done)
        self._build_ui()
        self._auto_suggest_tag()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        is_dark = self.is_dark
        bg      = "rgba(15,15,20,0.97)"   if is_dark else "rgba(245,245,250,0.98)"
        border  = "rgba(255,255,255,0.10)" if is_dark else "rgba(0,0,0,0.10)"
        fg      = "#e8eaf0"               if is_dark else "#1a1a2e"
        accent  = "#00f0ff"
        accent2 = "#7c3aed"
        sub     = "#8890a8"               if is_dark else "#555"
        inp_bg  = "rgba(255,255,255,0.06)" if is_dark else "rgba(0,0,0,0.04)"

        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)

        frame = QFrame()
        frame.setObjectName("RlsFrame")
        frame.setStyleSheet(f"""
            QFrame#RlsFrame {{
                background: {bg};
                border: 1px solid {border};
                border-radius: 12px;
            }}
            QLabel {{ color:{fg}; font-family:'{FONT_PRIMARY}'; font-size:12px; }}
            QLabel#rlsTitle {{ color:{accent}; font-size:14px; font-weight:700; }}
            QLabel#rlsSub   {{ color:{sub};   font-size:11px; }}
            QLineEdit, QTextEdit {{
                background:{inp_bg};
                color:{fg};
                border:1px solid {border};
                border-radius:6px;
                padding:5px 8px;
                font-family:'{FONT_PRIMARY}';
                font-size:12px;
            }}
            QLineEdit:focus, QTextEdit:focus {{ border-color:{accent}; }}
            QCheckBox {{ color:{fg}; font-family:'{FONT_PRIMARY}'; font-size:12px; }}
            QCheckBox::indicator {{ width:14px; height:14px; }}
            QPushButton#btnRlsClose {{
                background:#ff5f56; border:1px solid #e0443e; border-radius:8px;
            }}
            QPushButton#btnRlsClose:hover {{ background:#ff7b72; }}
            QPushButton#btnRlsMax {{
                background:#27c93f; border:1px solid #1aab29; border-radius:8px;
            }}
            QPushButton#btnRlsMax:hover {{ background:#38e04f; }}
            QPushButton#btnBrowse {{
                background:rgba(255,255,255,0.06);
                color:{fg}; border:1px solid {border};
                border-radius:6px; padding:4px 12px;
                font-size:11px; font-family:'{FONT_PRIMARY}';
            }}
            QPushButton#btnBrowse:hover {{ border-color:{accent}; }}
            QPushButton#btnPushRelease {{
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 {accent2}, stop:1 #9f5dfe);
                color:#fff; border:none; border-radius:8px;
                padding:8px 24px; font-size:13px; font-weight:700;
                font-family:'{FONT_PRIMARY}';
            }}
            QPushButton#btnPushRelease:hover {{
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                    stop:0 #9f5dfe, stop:1 {accent2});
            }}
            QPushButton#btnPushRelease:disabled {{
                background:rgba(120,120,120,0.3);
                color:rgba(255,255,255,0.4);
            }}
            QPushButton#btnRlsCancel {{
                background:rgba(255,255,255,0.06);
                color:{fg}; border:1px solid {border};
                border-radius:8px; padding:8px 20px;
                font-size:12px; font-family:'{FONT_PRIMARY}';
            }}
            QPushButton#btnRlsCancel:hover {{ border-color:{accent}; }}
            QProgressBar {{
                background:rgba(255,255,255,0.06); border:none; border-radius:3px;
            }}
            QProgressBar::chunk {{ background:{accent}; border-radius:3px; }}
        """)
        outer.addWidget(frame)

        root = QVBoxLayout(frame)
        root.setContentsMargins(0, 0, 0, 14)
        root.setSpacing(0)

        # ── Title bar ────────────────────────────────────────────────────────
        title_bar = QFrame()
        title_bar.setFixedHeight(38)
        h_tb = QHBoxLayout(title_bar)
        h_tb.setContentsMargins(12, 0, 12, 0)
        h_tb.setSpacing(6)

        btn_close = QPushButton()
        btn_close.setObjectName("btnRlsClose")
        btn_close.setFixedSize(16, 16)
        btn_close.setToolTip("Close")
        btn_close.setStyleSheet(
            "QPushButton{background:#ff5f56;border:1px solid #e0443e;border-radius:8px;}"
            "QPushButton:hover{background:#ff7b72;}"
        )
        btn_close.clicked.connect(self.reject)
        h_tb.addWidget(btn_close)
        h_tb.addSpacing(2)

        btn_max = QPushButton()
        btn_max.setObjectName("btnRlsMax")
        btn_max.setFixedSize(16, 16)
        btn_max.setToolTip("Maximize / Restore")
        btn_max.setStyleSheet(
            "QPushButton{background:#27c93f;border:1px solid #1aab29;border-radius:8px;}"
            "QPushButton:hover{background:#38e04f;}"
        )
        btn_max.clicked.connect(self._toggle_max)
        h_tb.addWidget(btn_max)
        h_tb.addSpacing(14)

        lbl_title = QLabel(f"\U0001f680  Create GitHub Release \u2014 {self.project['name']}")
        lbl_title.setObjectName("rlsTitle")
        h_tb.addWidget(lbl_title)
        h_tb.addStretch()
        root.addWidget(title_bar)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"background:{border}; max-height:1px; border:none;")
        root.addWidget(sep)

        # ── Form ─────────────────────────────────────────────────────────────
        content = QWidget()
        cl = QVBoxLayout(content)
        cl.setContentsMargins(18, 14, 18, 0)
        cl.setSpacing(10)
        root.addWidget(content)

        # Progress bar (hidden until push starts)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setFixedHeight(3)
        self.progress.setTextVisible(False)
        self.progress.setVisible(False)
        cl.addWidget(self.progress)

        # Status label
        self.lbl_status = QLabel("")
        self.lbl_status.setObjectName("rlsSub")
        self.lbl_status.setVisible(False)
        cl.addWidget(self.lbl_status)

        # Tag
        cl.addWidget(QLabel("\U0001f3f7\ufe0f  Tag (version):"))
        self.inp_tag = QLineEdit()
        self.inp_tag.setPlaceholderText("e.g. v1.5.0")
        self.inp_tag.textChanged.connect(self._sync_title)
        cl.addWidget(self.inp_tag)

        # Title
        cl.addWidget(QLabel("\U0001f4dd  Release title:"))
        self.inp_title = QLineEdit()
        self.inp_title.setPlaceholderText("e.g. Release v1.5.0")
        cl.addWidget(self.inp_title)

        # Description
        cl.addWidget(QLabel("\U0001f4c4  Description / Release notes:"))
        self.inp_body = QTextEdit()
        self.inp_body.setPlaceholderText(
            "Describe what's new in this release...\n\n"
            "Changes:\n- Feature A\n- Bug fix B"
        )
        self.inp_body.setFixedHeight(100)
        cl.addWidget(self.inp_body)

        # Pre-release checkbox
        self.chk_pre = QCheckBox("  Mark as Pre-release")
        cl.addWidget(self.chk_pre)

        # Attach file row
        cl.addWidget(QLabel("\U0001f4e6  Attach build file (optional):"))
        h_attach = QHBoxLayout()
        h_attach.setSpacing(8)
        self.lbl_attach = QLabel("No file selected")
        self.lbl_attach.setObjectName("rlsSub")
        self.lbl_attach.setWordWrap(True)
        h_attach.addWidget(self.lbl_attach, 1)
        btn_browse = QPushButton("Browse...")
        btn_browse.setObjectName("btnBrowse")
        btn_browse.clicked.connect(self._browse_file)
        h_attach.addWidget(btn_browse)
        btn_clear_file = QPushButton("\u2715")
        btn_clear_file.setObjectName("btnBrowse")
        btn_clear_file.setFixedWidth(28)
        btn_clear_file.clicked.connect(self._clear_file)
        h_attach.addWidget(btn_clear_file)
        cl.addLayout(h_attach)

        cl.addStretch()

        # Footer buttons
        h_foot = QHBoxLayout()
        h_foot.setSpacing(10)
        h_foot.addStretch()
        btn_cancel = QPushButton("Cancel")
        btn_cancel.setObjectName("btnRlsCancel")
        btn_cancel.clicked.connect(self.reject)
        h_foot.addWidget(btn_cancel)
        self.btn_push = QPushButton("\U0001f680  Push Release")
        self.btn_push.setObjectName("btnPushRelease")
        self.btn_push.clicked.connect(self._do_push_release)
        h_foot.addWidget(self.btn_push)
        cl.addLayout(h_foot)

    # ── Drag support ──────────────────────────────────────────────────────────

    def _toggle_max(self):
        self.showNormal() if self.isMaximized() else self.showMaximized()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_pos is not None and event.buttons() == Qt.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._drag_pos = None
        super().mouseReleaseEvent(event)

    # ── Auto-suggest tag ──────────────────────────────────────────────────────

    def _auto_suggest_tag(self):
        """Read the latest git tag and suggest a patch bump."""
        try:
            result = subprocess.run(
                ["git", "tag", "--sort=-v:refname"],
                cwd=self.project["path"],
                capture_output=True, text=True, timeout=5
            )
            tags = [t.strip() for t in result.stdout.splitlines() if t.strip()]
            if tags:
                latest = tags[0]
                suggested = self._bump_patch(latest)
            else:
                suggested = "v1.0.0"
        except Exception:
            suggested = "v1.0.0"

        self.inp_tag.setText(suggested)
        self.inp_title.setText(f"Release {suggested}")

    def _bump_patch(self, tag: str) -> str:
        """v1.2.3 -> v1.2.4, falls back to original if unparseable."""
        clean = tag.lstrip("v").lstrip("V")
        parts = clean.split(".")
        if len(parts) >= 3:
            try:
                parts[-1] = str(int(parts[-1]) + 1)
                prefix = "v" if tag[0].lower() == "v" else ""
                return prefix + ".".join(parts)
            except ValueError:
                pass
        return tag + "-next"

    def _sync_title(self, tag_text: str):
        """Keep title in sync with tag unless user has manually edited it."""
        current = self.inp_title.text()
        if not current or current.startswith("Release "):
            self.inp_title.setText(f"Release {tag_text}" if tag_text else "")

    # ── File attach ───────────────────────────────────────────────────────────

    def _browse_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select build file to attach", "",
            "Build files (*.exe *.zip *.msi *.AppImage *.dmg *.deb *.rpm *.tar.gz *.7z *.whl);;"
            "All files (*.*)"
        )
        if path:
            self._attach_path = path
            self.lbl_attach.setText(Path(path).name)

    def _clear_file(self):
        self._attach_path = ""
        self.lbl_attach.setText("No file selected")

    # ── Push Release ──────────────────────────────────────────────────────────

    def _do_push_release(self):
        tag   = self.inp_tag.text().strip()
        title = self.inp_title.text().strip()
        body  = self.inp_body.toPlainText().strip()

        if not tag:
            self.lbl_status.setText("\u26a0\ufe0f  Please enter a tag / version.")
            self.lbl_status.setVisible(True)
            return

        self.btn_push.setEnabled(False)
        self.btn_push.setText("\u23f3  Pushing...")
        self.progress.setVisible(True)
        self.lbl_status.setVisible(False)

        pre    = self.chk_pre.isChecked()
        attach = self._attach_path
        project_path = self.project["path"]

        def _worker():
            try:
                from ..github_ops import find_gh
                gh = find_gh()
                if not gh:
                    raise RuntimeError("GitHub CLI (gh) not found")

                env = {k: v for k, v in os.environ.items() if k != "GITHUB_TOKEN"}

                cmd = [gh, "release", "create", tag,
                       "--title", title or tag,
                       "--notes", body or f"Release {tag}"]
                if pre:
                    cmd.append("--prerelease")
                if attach and Path(attach).exists():
                    cmd.append(attach)

                proc = subprocess.run(
                    cmd,
                    cwd=project_path,
                    capture_output=True, text=True,
                    env=env, timeout=120
                )
                if proc.returncode != 0:
                    err = proc.stderr.strip() or proc.stdout.strip()
                    raise RuntimeError(err or f"gh release create failed (code {proc.returncode})")

                release_url = proc.stdout.strip()
                self._release_result.emit(True, release_url)

            except Exception as exc:
                self._release_result.emit(False, str(exc))

        threading.Thread(target=_worker, daemon=True).start()

    def _on_release_done(self, success: bool, info: str):
        """Runs on main thread via Signal."""
        self.progress.setVisible(False)
        self.btn_push.setEnabled(True)
        if success:
            self.btn_push.setText("\u2705  Released!")
            url = info
            self.lbl_status.setText(
                f"\u2705  Release created! "
                f"<a href='{url}' style='color:#00f0ff;'>{url}</a>"
            )
            self.lbl_status.setOpenExternalLinks(True)
            self.lbl_status.setVisible(True)
            # Open in browser
            if url.startswith("http"):
                try:
                    import webbrowser
                    webbrowser.open(url)
                except Exception:
                    pass
        else:
            self.btn_push.setText("\U0001f680  Push Release")
            self.lbl_status.setText(f"\u274c  Error: {info}")
            self.lbl_status.setVisible(True)


# ─────────────────────────────────────────────────────────────────────────────
# Cloud Release Dialog  (view and download GitHub Releases)
# ─────────────────────────────────────────────────────────────────────────────

class CloudReleaseDialog(QDialog):
    """Shows GitHub Releases list for a cloud repo with per-asset download."""

    _dl_result = Signal(bool, str, object)   # (success, info, btn_or_None)

    def __init__(self, parent, owner: str, repo_name: str, is_dark: bool):
        super().__init__(parent)
        self.owner      = owner
        self.repo_name  = repo_name
        self.is_dark    = is_dark
        self._drag_pos  = None
        self._releases  = []
        self.setWindowTitle(f"Releases \u2014 {repo_name}")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.resize(700, 500)
        self._dl_result.connect(self._on_dl_result)
        self._build_ui()
        self._start_fetch()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        dk  = self.is_dark
        bg  = "rgba(15,15,20,0.97)"    if dk else "rgba(245,245,250,0.98)"
        brd = "rgba(255,255,255,0.10)" if dk else "rgba(0,0,0,0.10)"
        fg  = "#e8eaf0"               if dk else "#1a1a2e"
        sub = "#8890a8"               if dk else "#555"
        acc = "#00f0ff"
        pur = "#7c3aed"

        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)

        frame = QFrame()
        frame.setObjectName("RlsCldFrm")
        ss = (
            f"QFrame#RlsCldFrm{{background:{bg};border:1px solid {brd};border-radius:12px;}}"
            f"QLabel{{color:{fg};font-family:'{FONT_PRIMARY}';font-size:12px;}}"
            f"QLabel#rclTitle{{color:{acc};font-size:14px;font-weight:700;}}"
            f"QLabel#rclSub{{color:{sub};font-size:11px;}}"
            f"QTableWidget{{background:transparent;border:none;gridline-color:{brd};"
            f"color:{fg};font-family:'{FONT_PRIMARY}';font-size:11px;}}"
            f"QTableWidget::item{{padding:4px 6px;}}"
            f"QTableWidget::item:selected{{background:rgba(0,240,255,0.12);}}"
            f"QHeaderView::section{{background:rgba(255,255,255,0.06);color:{sub};"
            f"border:none;border-bottom:1px solid {brd};padding:5px 6px;"
            f"font-family:'{FONT_PRIMARY}';font-size:11px;font-weight:700;}}"
            f"QPushButton#btnRclClose{{background:#ff5f56;border:1px solid #e0443e;border-radius:8px;}}"
            f"QPushButton#btnRclClose:hover{{background:#ff7b72;}}"
            f"QPushButton#btnRclMax{{background:#27c93f;border:1px solid #1aab29;border-radius:8px;}}"
            f"QPushButton#btnRclMax:hover{{background:#38e04f;}}"
            f"QPushButton#btnDlAsset{{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            f"stop:0 {pur},stop:1 #9f5dfe);color:#fff;border:none;border-radius:5px;"
            f"font-size:10px;font-weight:600;padding:2px 8px;}}"
            f"QPushButton#btnDlAsset:hover{{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            f"stop:0 #9f5dfe,stop:1 {pur});}}"
            f"QPushButton#btnDlAsset:disabled{{background:rgba(120,120,120,0.3);color:rgba(255,255,255,0.3);}}"
            f"QProgressBar{{background:transparent;border:none;border-radius:2px;}}"
            f"QProgressBar::chunk{{background:{acc};border-radius:2px;}}"
        )
        frame.setStyleSheet(ss)
        outer.addWidget(frame)

        root = QVBoxLayout(frame)
        root.setContentsMargins(0, 0, 0, 12)
        root.setSpacing(0)

        # Title bar
        tb = QFrame()
        tb.setFixedHeight(38)
        h_tb = QHBoxLayout(tb)
        h_tb.setContentsMargins(12, 0, 12, 0)
        h_tb.setSpacing(6)
        for obj, c, bc, hov, slot in [
            ("btnRclClose", "#ff5f56", "#e0443e", "#ff7b72", self.reject),
            ("btnRclMax",   "#27c93f", "#1aab29", "#38e04f", self._toggle_max),
        ]:
            b = QPushButton()
            b.setObjectName(obj)
            b.setFixedSize(16, 16)
            b.setStyleSheet(
                f"QPushButton{{background:{c};border:1px solid {bc};border-radius:8px;}}"
                f"QPushButton:hover{{background:{hov};}}"
            )
            b.clicked.connect(slot)
            h_tb.addWidget(b)
            h_tb.addSpacing(2)
        h_tb.addSpacing(10)
        lbl = QLabel(f"\U0001f4e6  GitHub Releases \u2014 {self.repo_name}")
        lbl.setObjectName("rclTitle")
        h_tb.addWidget(lbl)
        h_tb.addStretch()
        root.addWidget(tb)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"background:{brd};max-height:1px;border:none;")
        root.addWidget(sep)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setFixedHeight(3)
        self.progress.setTextVisible(False)
        root.addWidget(self.progress)

        self.lbl_status = QLabel("Fetching releases\u2026")
        self.lbl_status.setObjectName("rclSub")
        self.lbl_status.setContentsMargins(16, 4, 0, 4)
        root.addWidget(self.lbl_status)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Tag / Name", "Date", "Type", "Assets", "Download"]
        )
        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.Stretch)
        for ci in range(1, 5):
            hdr.setSectionResizeMode(ci, QHeaderView.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        root.addWidget(self.table)

    # ── Drag ──────────────────────────────────────────────────────────────────

    def _toggle_max(self):
        self.showNormal() if self.isMaximized() else self.showMaximized()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag_pos = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._drag_pos and e.buttons() == Qt.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag_pos)
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        self._drag_pos = None
        super().mouseReleaseEvent(e)

    # ── Fetch releases ─────────────────────────────────────────────────────────

    def _start_fetch(self):
        def _worker():
            try:
                from ..github_ops import get_github_releases
                self._releases = get_github_releases(self.owner, self.repo_name)
                self._dl_result.emit(True, str(len(self._releases)), None)
            except Exception as exc:
                self._releases = []
                self._dl_result.emit(False, str(exc), None)
        threading.Thread(target=_worker, daemon=True).start()

    def _on_dl_result(self, success: bool, info: str, btn):
        if btn is None:
            # fetch finished
            self.progress.setVisible(False)
            if success:
                count = int(info) if str(info).isdigit() else 0
                if count:
                    self.lbl_status.setText(f"\u2705  {count} release(s) found")
                    self._populate_table()
                else:
                    self.lbl_status.setText("\u26a0\ufe0f  No releases yet for this repo")
            else:
                self.lbl_status.setText(f"\u274c  {info}")
        else:
            # asset download finished
            btn.setEnabled(True)
            if success:
                btn.setText("\u2705 Done")
                fpath = Path(info)
                _open_folder(fpath.parent, fpath)
            else:
                btn.setText("\u2b07 Retry")
                btn.setToolTip(info)

    # ── Populate table ─────────────────────────────────────────────────────────

    def _populate_table(self):
        self.table.setRowCount(0)
        for rel in self._releases:
            row = self.table.rowCount()
            self.table.insertRow(row)

            badge = " [pre]" if rel["prerelease"] else (" [draft]" if rel["draft"] else "")
            ni = QTableWidgetItem(f"{rel['tag']}{badge}")
            ni.setToolTip(rel["body"][:400] if rel["body"] else "")
            self.table.setItem(row, 0, ni)
            self.table.setItem(row, 1, QTableWidgetItem(rel["published_at"]))

            t_text = "Pre" if rel["prerelease"] else ("Draft" if rel["draft"] else "Stable")
            self.table.setItem(row, 2, QTableWidgetItem(t_text))

            n = len(rel["assets"])
            self.table.setItem(row, 3, QTableWidgetItem(
                f"{n} file(s)" if n else "Source only"
            ))

            cell = QWidget()
            lay  = QHBoxLayout(cell)
            lay.setContentsMargins(3, 1, 3, 1)
            lay.setSpacing(4)

            if n == 0:
                tag   = rel["tag"]
                url   = (f"https://github.com/{self.owner}/{self.repo_name}"
                         f"/archive/refs/tags/{tag}.zip")
                fname = f"{self.repo_name}_{tag}_source.zip"
                btn   = QPushButton("\u2b07 Source")
                btn.setObjectName("btnDlAsset")
                btn.setFixedSize(80, 22)
                btn.clicked.connect(self._make_dl(url, fname, btn))
                lay.addWidget(btn)
            else:
                for asset in rel["assets"][:3]:
                    short = (asset["name"][:16] +
                             ("\u2026" if len(asset["name"]) > 16 else ""))
                    size_kb = asset["size"] // 1024
                    btn = QPushButton(f"\u2b07 {short}")
                    btn.setObjectName("btnDlAsset")
                    btn.setFixedHeight(22)
                    btn.setToolTip(f"{asset['name']}  ({size_kb} KB)")
                    btn.clicked.connect(
                        self._make_dl(asset["browser_download_url"], asset["name"], btn)
                    )
                    lay.addWidget(btn)

            lay.addStretch()
            self.table.setCellWidget(row, 4, cell)

        self.table.resizeRowsToContents()

    def _make_dl(self, url: str, filename: str, btn: QPushButton):
        """Return a slot capturing url/filename/btn."""
        def _slot():
            btn.setEnabled(False)
            btn.setText("\u23f3")
            dest = Path.home() / "Downloads" / filename

            def _worker():
                try:
                    if dest.exists():
                        self._dl_result.emit(True, str(dest), btn)
                        return
                    import urllib.request
                    urllib.request.urlretrieve(url, str(dest))
                    self._dl_result.emit(True, str(dest), btn)
                except Exception as exc:
                    self._dl_result.emit(False, str(exc), btn)

            threading.Thread(target=_worker, daemon=True).start()
        return _slot
