import os
import threading

import darkdetect
from BlurWindow.blurWindow import GlobalBlur
from PySide6.QtCore import QPoint, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QTextCursor, QIcon, QPixmap, QPainter, QPen, QBrush, QPainterPath
from PySide6.QtWidgets import (
    QFileDialog,
    QCheckBox,
    QFrame,
    QGraphicsDropShadowEffect,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTextEdit,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
    QTabBar,
    QDialog,
)

from ..constants import *
from ..git_runner import GitRunner
from ..github_ops import default_github_owner
from ..utils import load_settings, save_settings
from ..i18n_ui import UI_TRANSLATIONS

from .styles import apply_app_theme, add_shadow, update_eye_button_icon, create_eye_icon
from .dialogs import ConflictResolutionDialog, CommitHistoryDialog, ReleaseDialog, CloudReleaseDialog







class AutoGitApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(DEFAULT_WIDTH, DEFAULT_HEIGHT)
        self.is_dark = darkdetect.isDark()
        self._drag_pos = QPoint()
        self.worker_thread = None
        self.projects = []
        self.settings = load_settings()
        self.current_lang = self.settings.get("last_lang", "en")
        self.active_filter_path = self.settings.get("last_explorer_path", "")
        self.selected_paths = set(self.settings.get("last_selected_projects", []))
        self.hidden_project_paths = set(self.settings.get("hidden_projects", []))
        self.show_hidden_projects = False
        self.current_tab = 0
        self.cloud_projects = []
        self.selected_cloud_urls = set(self.settings.get("last_selected_cloud_projects", []))
        self.active_cloud_filter_group = ""
        self.chain_cloud_scan_after_local = False

        self.setAcceptDrops(True)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.WindowMinMaxButtonsHint | Qt.WindowSystemMenuHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.runner = GitRunner()
        self.runner.log_received.connect(self.append_log)
        self.runner.scan_finished.connect(self.on_scan_finished)
        self.runner.cloud_scan_finished.connect(self.on_cloud_scan_finished)
        self.runner.progress_updated.connect(self.update_progress)
        self.runner.operation_finished.connect(self.on_operation_finished)

        self.init_ui()
        self.change_language(self.current_lang)
        self.apply_theme()
        QTimer.singleShot(150, self.auto_scan_on_startup)

    def init_ui(self):
        self.central_widget = QFrame()
        self.central_widget.setObjectName("CentralWidget")
        self.setCentralWidget(self.central_widget)

        layout = QVBoxLayout(self.central_widget)
        layout.setContentsMargins(20, 15, 20, 20)
        layout.setSpacing(14)

        title_bar = QHBoxLayout()
        self.close_btn = QPushButton("")
        self.close_btn.setObjectName("CloseBtn")
        self.close_btn.setFixedSize(16, 16)
        self.close_btn.clicked.connect(self.close)
        self.close_btn.setToolTip("Close")

        self.min_btn = QPushButton("")
        self.min_btn.setObjectName("MinBtn")
        self.min_btn.setFixedSize(16, 16)
        self.min_btn.clicked.connect(self.showMinimized)
        self.min_btn.setToolTip("Minimize")

        self.max_btn = QPushButton("")
        self.max_btn.setObjectName("MaxBtn")
        self.max_btn.setFixedSize(16, 16)
        self.max_btn.clicked.connect(self.toggle_maximize)
        self.max_btn.setToolTip("Maximize/Restore")

        title_bar.addWidget(self.close_btn)
        title_bar.addSpacing(2)
        title_bar.addWidget(self.min_btn)
        title_bar.addSpacing(2)
        title_bar.addWidget(self.max_btn)
        title_bar.addSpacing(15)

        self.lbl_title = QLabel(APP_TITLE)
        self.add_shadow(self.lbl_title)
        title_bar.addWidget(self.lbl_title)
        title_bar.addStretch()

        # Language Switcher Layout
        self.lang_layout = QHBoxLayout()
        self.lang_layout.setSpacing(4)
        
        self.btn_lang_en = QPushButton("🇺🇸 EN")
        self.btn_lang_zh = QPushButton("🇨🇳 ZH")
        self.btn_lang_vi = QPushButton("🇻🇳 VI")
        self.btn_lang_more = QPushButton("🌐 More ➔")
        
        self.btn_lang_en.setObjectName("LangBtn")
        self.btn_lang_zh.setObjectName("LangBtn")
        self.btn_lang_vi.setObjectName("LangBtn")
        self.btn_lang_more.setObjectName("LangBtn")
        
        self.btn_lang_en.setFixedSize(56, 26)
        self.btn_lang_zh.setFixedSize(56, 26)
        self.btn_lang_vi.setFixedSize(56, 26)
        self.btn_lang_more.setFixedSize(72, 26)
        
        self.other_lang_widget = QWidget()
        self.other_lang_widget.setObjectName("OtherLangWidget")
        self.other_lang_widget.setVisible(False)
        other_layout = QHBoxLayout(self.other_lang_widget)
        other_layout.setContentsMargins(0, 0, 0, 0)
        other_layout.setSpacing(4)
        
        self.btn_lang_ja = QPushButton("🇯🇵 JA")
        self.btn_lang_es = QPushButton("🇪🇸 ES")
        self.btn_lang_fr = QPushButton("🇫🇷 FR")
        self.btn_lang_de = QPushButton("🇩🇪 DE")
        self.btn_lang_ru = QPushButton("🇷🇺 RU")
        self.btn_lang_pt = QPushButton("🇵🇹 PT")
        self.btn_lang_ko = QPushButton("🇰🇷 KO")
        
        self.btn_lang_ja.setObjectName("LangBtn")
        self.btn_lang_es.setObjectName("LangBtn")
        self.btn_lang_fr.setObjectName("LangBtn")
        self.btn_lang_de.setObjectName("LangBtn")
        self.btn_lang_ru.setObjectName("LangBtn")
        self.btn_lang_pt.setObjectName("LangBtn")
        self.btn_lang_ko.setObjectName("LangBtn")
        
        self.btn_lang_ja.setFixedSize(56, 26)
        self.btn_lang_es.setFixedSize(56, 26)
        self.btn_lang_fr.setFixedSize(56, 26)
        self.btn_lang_de.setFixedSize(56, 26)
        self.btn_lang_ru.setFixedSize(56, 26)
        self.btn_lang_pt.setFixedSize(56, 26)
        self.btn_lang_ko.setFixedSize(56, 26)
        
        other_layout.addWidget(self.btn_lang_ja)
        other_layout.addWidget(self.btn_lang_es)
        other_layout.addWidget(self.btn_lang_fr)
        other_layout.addWidget(self.btn_lang_de)
        other_layout.addWidget(self.btn_lang_ru)
        other_layout.addWidget(self.btn_lang_pt)
        other_layout.addWidget(self.btn_lang_ko)
        
        # Wrap self.btn_lang_more and self.other_lang_widget in a container widget
        self.lang_more_container = QWidget()
        self.lang_more_container.setObjectName("LangMoreContainer")
        more_container_layout = QHBoxLayout(self.lang_more_container)
        more_container_layout.setContentsMargins(0, 0, 0, 0)
        more_container_layout.setSpacing(4)
        more_container_layout.addWidget(self.btn_lang_more)
        more_container_layout.addWidget(self.other_lang_widget)
        
        self.lang_layout.addWidget(self.btn_lang_en)
        self.lang_layout.addWidget(self.btn_lang_zh)
        self.lang_layout.addWidget(self.btn_lang_vi)
        self.lang_layout.addWidget(self.lang_more_container)
        
        self.btn_lang_en.clicked.connect(lambda: self.change_language("en"))
        self.btn_lang_zh.clicked.connect(lambda: self.change_language("zh-cn"))
        self.btn_lang_vi.clicked.connect(lambda: self.change_language("vi"))
        self.btn_lang_ja.clicked.connect(lambda: self.change_language("ja-jp"))
        self.btn_lang_es.clicked.connect(lambda: self.change_language("es"))
        self.btn_lang_fr.clicked.connect(lambda: self.change_language("fr"))
        self.btn_lang_de.clicked.connect(lambda: self.change_language("de"))
        self.btn_lang_ru.clicked.connect(lambda: self.change_language("ru"))
        self.btn_lang_pt.clicked.connect(lambda: self.change_language("pt"))
        self.btn_lang_ko.clicked.connect(lambda: self.change_language("ko"))
        
        # Connect hover events for the container widget
        self.lang_more_container.enterEvent = self.on_lang_container_enter
        self.lang_more_container.leaveEvent = self.on_lang_container_leave
        
        self.lang_buttons = {
            "en": self.btn_lang_en,
            "zh-cn": self.btn_lang_zh,
            "vi": self.btn_lang_vi,
            "ja-jp": self.btn_lang_ja,
            "es": self.btn_lang_es,
            "fr": self.btn_lang_fr,
            "de": self.btn_lang_de,
            "ru": self.btn_lang_ru,
            "pt": self.btn_lang_pt,
            "ko": self.btn_lang_ko,
        }
        
        title_bar.addLayout(self.lang_layout)
        title_bar.addSpacing(10)

        self.btn_theme = QPushButton()
        self.btn_theme.setFixedHeight(30)
        self.btn_theme.clicked.connect(self.toggle_theme)
        title_bar.addWidget(self.btn_theme)
        layout.addLayout(title_bar)

        split_layout = QHBoxLayout()
        split_layout.setSpacing(20)

        left_panel = self.build_left_panel()
        split_layout.addWidget(left_panel, 4)

        right_panel = QVBoxLayout()
        right_panel.setSpacing(12)

        h_tree_header = QHBoxLayout()
        self.lbl_tree = QLabel("PROJECT GIT STATUS TREE (0)")
        self.lbl_tree.setObjectName("ConsoleLabel")
        self.add_shadow(self.lbl_tree)
        h_tree_header.addWidget(self.lbl_tree)
        h_tree_header.addStretch()

        self.btn_toggle_hidden = QPushButton()
        self.btn_toggle_hidden.setObjectName("EyeBtn")
        self.btn_toggle_hidden.setFixedSize(32, 32)
        self.btn_toggle_hidden.clicked.connect(self.on_toggle_hidden_visibility)
        h_tree_header.addWidget(self.btn_toggle_hidden)

        right_panel.addLayout(h_tree_header)

        self.tabs = QTabBar()
        self.tabs.setObjectName("ViewTabs")
        self.tabs.addTab("Local Workspace")
        self.tabs.addTab("GitHub Cloud")
        self.tabs.currentChanged.connect(self.on_tab_changed)
        right_panel.addWidget(self.tabs)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(13)
        self.tree.setHeaderLabels(["Project", "Kind", "Version", ".git", "Branch", ".gitignore", "README", "LICENSE", "ABOUT", "Remote", "Clean", "Status", "Release"])
        self.tree.setRootIsDecorated(True)
        self.tree.setAlternatingRowColors(True)
        self.tree.itemChanged.connect(self.on_tree_item_changed)
        self.tree.setSortingEnabled(True)
        self.tree.sortByColumn(0, Qt.AscendingOrder)
        right_panel.addWidget(self.tree, 4)

        h_tree_toolbar = QHBoxLayout()
        self.btn_check_all = QPushButton("☑️")
        self.btn_check_all.setFixedSize(36, 30)
        self.btn_check_all.clicked.connect(lambda: self.set_all_checked(True))
        
        self.btn_uncheck_all = QPushButton("⬜")
        self.btn_uncheck_all.setFixedSize(36, 30)
        self.btn_uncheck_all.clicked.connect(lambda: self.set_all_checked(False))
        
        self.btn_check_has_git = QPushButton("✅")
        self.btn_check_has_git.setFixedSize(36, 30)
        self.btn_check_has_git.clicked.connect(lambda: self.select_by_predicate(lambda project: project["has_git"]))
        
        self.btn_check_no_git = QPushButton("❌")
        self.btn_check_no_git.setFixedSize(36, 30)
        self.btn_check_no_git.clicked.connect(lambda: self.select_by_predicate(lambda project: not project["has_git"]))
        
        self.btn_check_missing_form = QPushButton("⚠️")
        self.btn_check_missing_form.setFixedSize(36, 30)
        self.btn_check_missing_form.clicked.connect(lambda: self.select_by_predicate(lambda project: not project["standard_ok"]))
        
        self.btn_filter_not_cloned = QPushButton("📥")
        self.btn_filter_not_cloned.setFixedSize(36, 30)
        self.btn_filter_not_cloned.clicked.connect(self.select_not_cloned)
        self.btn_filter_not_cloned.setVisible(False)
        
        self.btn_filter_behind_cloud = QPushButton("🔄")
        self.btn_filter_behind_cloud.setFixedSize(36, 30)
        self.btn_filter_behind_cloud.clicked.connect(self.select_behind_cloud)
        self.btn_filter_behind_cloud.setVisible(False)
        
        self.btn_open_project = QPushButton("📂")
        self.btn_open_project.setFixedSize(36, 30)
        self.btn_open_project.clicked.connect(self.open_selected_project)
        
        self.btn_hide_project = QPushButton("👁️")
        self.btn_hide_project.setFixedSize(36, 30)
        self.btn_hide_project.clicked.connect(self.on_hide_project_clicked)
        
        self.btn_rename_project = QPushButton("✏️")
        self.btn_rename_project.setFixedSize(36, 30)
        self.btn_rename_project.clicked.connect(self.on_rename_project_clicked)
        
        self.btn_delete_project = QPushButton("🗑️")
        self.btn_delete_project.setFixedSize(36, 30)
        self.btn_delete_project.clicked.connect(self.on_delete_project_clicked)
        
        self.btn_change_visibility = QPushButton("🌐")
        self.btn_change_visibility.setFixedSize(36, 30)
        self.btn_change_visibility.clicked.connect(self.on_change_visibility_clicked)
        self.btn_change_visibility.setVisible(False)
        
        # Add widgets to single horizontal toolbar layout
        h_tree_toolbar.addWidget(self.btn_check_all)
        h_tree_toolbar.addWidget(self.btn_uncheck_all)
        h_tree_toolbar.addWidget(self.btn_check_has_git)
        h_tree_toolbar.addWidget(self.btn_check_no_git)
        h_tree_toolbar.addWidget(self.btn_check_missing_form)
        h_tree_toolbar.addWidget(self.btn_filter_not_cloned)
        h_tree_toolbar.addWidget(self.btn_filter_behind_cloud)
        
        h_tree_toolbar.addSpacing(15) # Group separator spacing
        
        h_tree_toolbar.addWidget(self.btn_open_project)
        h_tree_toolbar.addWidget(self.btn_hide_project)
        h_tree_toolbar.addWidget(self.btn_rename_project)
        h_tree_toolbar.addWidget(self.btn_delete_project)
        h_tree_toolbar.addWidget(self.btn_change_visibility)
        h_tree_toolbar.addStretch()
        
        right_panel.addLayout(h_tree_toolbar)

        h_console = QHBoxLayout()
        self.lbl_console = QLabel("LIVE GIT CONSOLE")
        self.lbl_console.setObjectName("ConsoleLabel")
        self.add_shadow(self.lbl_console)
        h_console.addWidget(self.lbl_console)
        h_console.addStretch()
        self.btn_clear_console = QPushButton("Clear Console")
        self.btn_clear_console.clicked.connect(self.txt_console_clear)
        h_console.addWidget(self.btn_clear_console)
        right_panel.addLayout(h_console)

        self.txt_console = QTextEdit()
        self.txt_console.setReadOnly(True)
        self.txt_console.setPlaceholderText("Dang cho lenh Git...")
        right_panel.addWidget(self.txt_console, 2)

        split_layout.addLayout(right_panel, 7)
        layout.addLayout(split_layout)

        self.lbl_status = QLabel("Trang thai: Dang cho quet project...")
        layout.addWidget(self.lbl_status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(5)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        h_actions = QHBoxLayout()
        self.btn_scan = QPushButton("QUET PROJECT")
        self.btn_scan.setObjectName("BuildBtn")
        self.btn_scan.setFixedHeight(50)
        self.btn_scan.setFont(QFont(FONT_PRIMARY, 12, QFont.Bold))
        self.btn_scan.clicked.connect(self.start_scan)

        self.btn_fix = QPushButton("TAO / SUA GIT FORM")
        self.btn_fix.setObjectName("BuildBtn")
        self.btn_fix.setFixedHeight(50)
        self.btn_fix.setFont(QFont(FONT_PRIMARY, 12, QFont.Bold))
        self.btn_fix.clicked.connect(self.start_fix_selected)

        self.btn_push = QPushButton("COMMIT & PUSH SELECTED")
        self.btn_push.setObjectName("BuildBtn")
        self.btn_push.setFixedHeight(50)
        self.btn_push.setFont(QFont(FONT_PRIMARY, 12, QFont.Bold))
        self.btn_push.clicked.connect(self.start_push_selected)

        self.btn_sync_cloud = QPushButton("SYNC / CLONE SELECTED")
        self.btn_sync_cloud.setObjectName("BuildBtn")
        self.btn_sync_cloud.setFixedHeight(50)
        self.btn_sync_cloud.setFont(QFont(FONT_PRIMARY, 12, QFont.Bold))
        self.btn_sync_cloud.clicked.connect(self.start_cloud_sync)
        self.btn_sync_cloud.setVisible(False)

        h_actions.addWidget(self.btn_scan)
        h_actions.addWidget(self.btn_fix)
        h_actions.addWidget(self.btn_push)
        h_actions.addWidget(self.btn_sync_cloud)
        layout.addLayout(h_actions)

    def build_left_panel(self):
        scroll_area = QScrollArea()
        scroll_area.setMinimumWidth(320)
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setStyleSheet("QScrollArea { background: transparent; }")

        left_widget = QWidget()
        left_widget.setStyleSheet("background: transparent;")
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 10, 0)
        left_layout.setSpacing(14)

        self.grp_scan = QGroupBox("SCAN ROOT")
        scan_layout = QVBoxLayout(self.grp_scan)
        scan_layout.setSpacing(10)

        self.lbl_scan_root = QLabel("Thu muc chua cac nhom project:")
        scan_layout.addWidget(self.lbl_scan_root)
        h_root = QHBoxLayout()
        self.txt_root = QLineEdit(self.settings.get("last_root", DEFAULT_ROOT))
        self.txt_root.setPlaceholderText("Vi du: D:\\...\\JA_PROJECT")
        self.btn_browse_root = QPushButton("Browse...")
        self.btn_browse_root.clicked.connect(self.browse_root)
        h_root.addWidget(self.txt_root)
        h_root.addWidget(self.btn_browse_root)
        scan_layout.addLayout(h_root)

        h_depth = QHBoxLayout()
        self.lbl_scan_depth = QLabel("Do sau quet:")
        h_depth.addWidget(self.lbl_scan_depth)
        self.spin_depth = QSpinBox()
        self.spin_depth.setRange(1, 8)
        self.spin_depth.setValue(int(self.settings.get("max_depth", 3)))
        h_depth.addWidget(self.spin_depth)
        h_depth.addStretch()
        scan_layout.addLayout(h_depth)

        left_layout.addWidget(self.grp_scan)

        self.grp_sidebar = QGroupBox("PROJECT EXPLORER")
        sidebar_layout = QVBoxLayout(self.grp_sidebar)
        sidebar_layout.setSpacing(8)
        self.sidebar_tree = QTreeWidget()
        self.sidebar_tree.setHeaderHidden(True)
        self.sidebar_tree.setRootIsDecorated(True)
        self.sidebar_tree.itemClicked.connect(self.on_sidebar_item_clicked)
        sidebar_layout.addWidget(self.sidebar_tree)
        left_layout.addWidget(self.grp_sidebar, 1)

        self.grp_push = QGroupBox("GITHUB PUSH")
        push_layout = QVBoxLayout(self.grp_push)
        push_layout.setSpacing(10)

        self.lbl_owner = QLabel("GitHub base URL hoac owner URL:")
        push_layout.addWidget(self.lbl_owner)
        self.txt_remote_base = QLineEdit(self.settings.get("remote_base", "") or default_github_owner())
        self.txt_remote_base.setPlaceholderText("Vi du: jatechvn hoac https://github.com/jatechvn")
        push_layout.addWidget(self.txt_remote_base)

        self.chk_auto_create_repo = QCheckBox("Tu tao GitHub repository neu chua co (can GitHub CLI gh)")
        self.chk_auto_create_repo.setChecked(bool(self.settings.get("auto_create_repo", True)))
        push_layout.addWidget(self.chk_auto_create_repo)

        self.chk_repo_public = QCheckBox("Tao repository o che do Public (mac dinh Private)")
        self.chk_repo_public.setChecked(bool(self.settings.get("repo_public", False)))
        push_layout.addWidget(self.chk_repo_public)

        self.lbl_commit_msg = QLabel("Commit message:")
        push_layout.addWidget(self.lbl_commit_msg)
        self.txt_commit = QLineEdit(self.settings.get("commit_message", DEFAULT_COMMIT_MESSAGE))
        push_layout.addWidget(self.txt_commit)

        self.lbl_push_note = QLabel(
            "App sẽ tạo remote theo mẫu "
            "https://github.com/<owner>/<ten-project>.git. GCM sẽ xử lý xác thực khi git push."
        )
        self.lbl_push_note.setWordWrap(True)
        push_layout.addWidget(self.lbl_push_note)
        left_layout.addWidget(self.grp_push)

        self.grp_standard = QGroupBox("GIT FORM CHUAN")
        std_layout = QVBoxLayout(self.grp_standard)
        std_layout.setSpacing(8)
        self.lbl_std_note = QLabel(
            "Moi project duoc xem la chuan khi co .git, branch main, .gitignore (kem license.key neu co), "
            "git_push.bat, README.md, LICENSE, va khong thieu remote neu can push."
        )
        self.lbl_std_note.setWordWrap(True)
        std_layout.addWidget(self.lbl_std_note)

        self.lbl_license_author = QLabel("LICENSE Author:")
        std_layout.addWidget(self.lbl_license_author)
        self.txt_license_author = QLineEdit(self.settings.get("license_author", "John Alaa"))
        std_layout.addWidget(self.txt_license_author)

        left_layout.addWidget(self.grp_standard)

        left_layout.addStretch()
        scroll_area.setWidget(left_widget)
        return scroll_area

    def browse_root(self):
        path = QFileDialog.getExistingDirectory(self, "Chon thu muc project", self.txt_root.text().strip() or DEFAULT_ROOT)
        if path:
            self.txt_root.setText(path)
            self.active_filter_path = ""
            self.save_current_settings(include_tree_state=False)
            self.chain_cloud_scan_after_local = True
            self.start_scan()

    def start_scan(self):
        if self.current_tab == 1:
            self.start_cloud_scan()
            return

        root = self.txt_root.text().strip()
        if not os.path.isdir(root):
            t = UI_TRANSLATIONS[self.current_lang]
            QMessageBox.critical(self, t["msg_error"], t["msg_invalid_root"])
            return

        self.save_current_settings(include_tree_state=False)
        self.lock_actions(True)
        if self.current_tab == 0:
            self.tree.clear()
            self.sidebar_tree.clear()
        self.projects = []
        self.active_filter_path = self.settings.get("last_explorer_path", "")
        if self.active_filter_path and not self.path_is_inside(root, self.active_filter_path):
            self.active_filter_path = ""
        self.txt_console.clear()
        self.progress_bar.setValue(5)
        t = UI_TRANSLATIONS[self.current_lang]
        self.lbl_status.setText(t["status_scanning"])
        self.append_log(f"[SCAN] Root: {root}\n")
        self.worker_thread = threading.Thread(
            target=self.runner.scan,
            args=(root, self.spin_depth.value()),
            daemon=True,
        )
        self.worker_thread.start()

    def on_scan_finished(self, projects):
        self.projects = projects
        if self.current_tab == 0:
            self.populate_sidebar(self.visible_projects())
            self.populate_tree(self.filtered_projects())
            self.restore_selected_projects()
        self.lock_actions(False)
        self.progress_bar.setValue(100)
        t = UI_TRANSLATIONS[self.current_lang]
        self.lbl_status.setText(t["status_scanned"].format(count=len(projects)))
        self.append_log(f"[OK] Found {len(projects)} project(s).\n")
        
        if getattr(self, "chain_cloud_scan_after_local", False):
            self.chain_cloud_scan_after_local = False
            self.start_cloud_scan()

    def populate_sidebar(self, projects):
        self.sidebar_tree.blockSignals(True)
        self.sidebar_tree.clear()

        root_path = os.path.abspath(self.txt_root.text().strip())
        root_label = os.path.basename(root_path) or root_path
        root_item = QTreeWidgetItem([f"{root_label} ({len(projects)})"])
        root_item.setData(0, Qt.UserRole, "")
        self.sidebar_tree.addTopLevelItem(root_item)

        nodes = {"": root_item, root_path: root_item}
        counts = {}
        for project in projects:
            current = os.path.dirname(project["path"])
            while current.startswith(root_path):
                counts[current] = counts.get(current, 0) + 1
                if current == root_path:
                    break
                current = os.path.dirname(current)

        for path in sorted(counts, key=lambda item: item.lower()):
            if path == root_path:
                continue
            parent_path = os.path.dirname(path)
            parent_item = nodes.get(parent_path, root_item)
            item = QTreeWidgetItem([f"{os.path.basename(path)} ({counts[path]})"])
            item.setData(0, Qt.UserRole, path)
            parent_item.addChild(item)
            nodes[path] = item

        root_item.setExpanded(True)
        if self.active_filter_path:
            self.select_sidebar_path(self.active_filter_path)
        self.sidebar_tree.blockSignals(False)

    def filtered_projects(self):
        projects = self.projects
        if self.active_filter_path:
            filter_path = os.path.abspath(self.active_filter_path)
            projects = [
                project for project in projects
                if os.path.commonpath([filter_path, os.path.abspath(project["path"])]) == filter_path
            ]
        if not self.show_hidden_projects:
            projects = [
                project for project in projects
                if project["path"] not in self.hidden_project_paths
            ]
        return projects

    def path_is_inside(self, root, path):
        try:
            root_abs = os.path.abspath(root)
            path_abs = os.path.abspath(path)
            return os.path.commonpath([root_abs, path_abs]) == root_abs
        except ValueError:
            return False

    def on_sidebar_item_clicked(self, item, column):
        if self.current_tab == 1:
            self.active_cloud_filter_group = item.data(0, Qt.UserRole) or ""
            self.populate_cloud_tree()
            t = UI_TRANSLATIONS[self.current_lang]
            self.lbl_status.setText(t["status_filtering"].format(name=item.text(0)))
            return

        self.active_filter_path = item.data(0, Qt.UserRole) or ""
        self.populate_tree(self.filtered_projects())
        self.restore_selected_projects()
        self.save_current_settings()
        t = UI_TRANSLATIONS[self.current_lang]
        self.lbl_status.setText(t["status_filtering"].format(name=item.text(0)))

    def populate_tree(self, projects):
        self.tree.blockSignals(True)
        self.tree.setSortingEnabled(False)
        self.tree.clear()
        total = len(projects)
        selected_count = len(self.selected_paths)
        hidden_count = sum(1 for p in self.projects if p["path"] in self.hidden_project_paths)
        t = UI_TRANSLATIONS[self.current_lang]
        self.lbl_tree.setText(t["lbl_tree_live"].format(total=total, selected=selected_count, hidden=hidden_count))
        roots = {}
        for project in projects:
            parent_path = os.path.dirname(project["path"])
            parent_name = os.path.basename(parent_path) or parent_path
            if parent_path not in roots:
                parent_item = QTreeWidgetItem([parent_name, "group", "", "", "", "", "", "", "", "", "", "", parent_path])
                parent_item.setFlags(parent_item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsAutoTristate)
                parent_item.setCheckState(0, Qt.Unchecked)
                parent_item.setData(0, Qt.UserRole, "")
                roots[parent_path] = parent_item
                self.tree.addTopLevelItem(parent_item)

            if not project["has_gitignore"]:
                gitignore_status = t["no"]
            elif not project["gitignore_ok"]:
                gitignore_status = t["non_std"]
            else:
                gitignore_status = t["yes"]

            item = QTreeWidgetItem([
                project["name"],
                project["kind"],
                project.get("version") or "-",
                self.yes_no_local(project["has_git"]),
                project["branch"] or "-",
                gitignore_status,
                self.yes_no_local(project["readme_ok"]),
                self.yes_no_local(project["license_ok"]),
                self.yes_no_local(project["about_ok"]),
                self.yes_no_local(project["has_remote"]),
                self.yes_no_local(project["clean"]),
                project["status"],
            ])
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            checked = project["path"] in self.selected_paths
            item.setCheckState(0, Qt.Checked if checked else Qt.Unchecked)
            item.setData(0, Qt.UserRole, project["path"])
            if self.is_dark:
                color = QColor("#00ff9d") if project["standard_ok"] else QColor("#ffbd2e")
                if not project["has_git"]:
                    color = QColor("#ff5f56")
                is_hidden = project["path"] in self.hidden_project_paths
                if is_hidden:
                    color = QColor(140, 140, 140)
            else:
                color = QColor("#008f5d") if project["standard_ok"] else QColor("#b87a00")
                if not project["has_git"]:
                    color = QColor("#d93829")
                is_hidden = project["path"] in self.hidden_project_paths
                if is_hidden:
                    color = QColor(120, 120, 120)

            for col in range(self.tree.columnCount()):
                item.setForeground(col, color)
                if is_hidden:
                    font = item.font(col)
                    font.setItalic(True)
                    item.setFont(col, font)
            roots[parent_path].addChild(item)

            # Release button — only enabled for projects with git + remote
            btn_rel = QPushButton("\U0001f680 Release")
            btn_rel.setObjectName("btnRelease")
            btn_rel.setFixedSize(80, 22)
            can_release = project["has_git"] and project.get("has_remote", False)
            btn_rel.setEnabled(can_release)
            btn_rel.setToolTip(
                f"Create a GitHub Release for {project['name']}"
                if can_release else
                "Requires git init + remote configured"
            )
            btn_rel.clicked.connect(
                lambda _checked=False, p=project: self._open_release_dialog(p)
            )
            rel_cell = QWidget()
            rel_lay  = QHBoxLayout(rel_cell)
            rel_lay.setContentsMargins(2, 1, 2, 1)
            rel_lay.setAlignment(Qt.AlignCenter)
            rel_lay.addWidget(btn_rel)
            self.tree.setItemWidget(item, 12, rel_cell)

        self.tree.expandAll()
        release_col = self.tree.columnCount() - 1
        hdr = self.tree.header()
        hdr.setStretchLastSection(False)          # prevent Release col from filling space
        for col in range(release_col):
            self.tree.resizeColumnToContents(col)
            hdr.setSectionResizeMode(col, QHeaderView.Interactive)
        hdr.setSectionResizeMode(release_col, QHeaderView.Fixed)
        self.tree.setColumnWidth(release_col, 88)  # Release col fixed narrow
        self.tree.setSortingEnabled(True)
        self.tree.blockSignals(False)
        self.update_tree_count_label()

    def on_tree_item_changed(self, item, column):
        if column != 0:
            return
        if self.current_tab == 1:
            url = item.data(0, Qt.UserRole)
            if url:
                if item.checkState(0) == Qt.Checked:
                    self.selected_cloud_urls.add(url)
                else:
                    self.selected_cloud_urls.discard(url)
            self.update_tree_count_label()
            self.save_current_settings()
            return

        path = item.data(0, Qt.UserRole)
        if path:
            if item.checkState(0) == Qt.Checked:
                self.selected_paths.add(path)
            else:
                self.selected_paths.discard(path)
        self.update_tree_count_label()
        self.save_current_settings()

    def selected_project_paths(self):
        current_paths = {p["path"] for p in self.projects}
        return [path for path in self.selected_paths if path in current_paths]

    def start_fix_selected(self):
        paths = self.selected_project_paths()
        if not paths:
            t = UI_TRANSLATIONS[self.current_lang]
            QMessageBox.information(self, t["msg_notice"], t["msg_no_selected"])
            return
        self.save_current_settings()
        self.run_operation("Dang tao/sua Git form...", self.runner.fix_projects, paths)

    def start_push_selected(self):
        paths = self.selected_project_paths()
        if not paths:
            t = UI_TRANSLATIONS[self.current_lang]
            QMessageBox.information(self, t["msg_notice"], t["msg_no_selected"])
            return
        self.save_current_settings()
        self.run_operation(
            "Dang commit/push project...",
            self.runner.push_projects,
            paths,
            self.txt_remote_base.text().strip(),
            self.txt_commit.text().strip() or DEFAULT_COMMIT_MESSAGE,
            self.chk_auto_create_repo.isChecked(),
            self.chk_repo_public.isChecked(),
        )

    def run_operation(self, status, target, *args):
        self.lock_actions(True)
        self.progress_bar.setValue(0)
        t = UI_TRANSLATIONS[self.current_lang]
        if status == "Dang tao/sua Git form...":
            status_text = t["status_fixing"]
        elif status == "Dang commit/push project...":
            status_text = t["status_pushing"]
        else:
            status_text = f"Status: {status}"
        self.lbl_status.setText(status_text)
        self.worker_thread = threading.Thread(target=target, args=args, daemon=True)
        self.worker_thread.start()

    def on_operation_finished(self, success, message):
        self.lock_actions(False)
        t = UI_TRANSLATIONS[self.current_lang]
        self.lbl_status.setText(f"{t['grp_sidebar']}: {message}")
        self.append_log(f"[DONE] {message}\n")
        
        if success and self.current_tab == 1:
            self.chain_cloud_scan_after_local = True
            
        root = self.txt_root.text().strip()
        if os.path.isdir(root):
            self.worker_thread = threading.Thread(
                target=self.runner.scan,
                args=(root, self.spin_depth.value()),
                daemon=True,
            )
            self.worker_thread.start()
        if not success:
            QMessageBox.warning(self, t["msg_notice"], message)

    def lock_actions(self, locked):
        buttons = (
            self.btn_scan,
            self.btn_fix,
            self.btn_push,
            self.btn_browse_root,
            self.btn_check_all,
            self.btn_uncheck_all,
            self.btn_check_has_git,
            self.btn_check_no_git,
            self.btn_check_missing_form,
            self.btn_open_project,
            self.btn_hide_project,
            self.btn_rename_project,
            self.btn_delete_project,
            self.btn_change_visibility,
            self.btn_sync_cloud,
            self.btn_filter_not_cloned,
            self.btn_filter_behind_cloud,
        )
        for btn in buttons:
            btn.setEnabled(not locked)

    def auto_scan_on_startup(self):
        root = self.txt_root.text().strip()
        if os.path.isdir(root):
            self.chain_cloud_scan_after_local = True
            self.start_scan()

    def set_all_checked(self, checked):
        state = Qt.Checked if checked else Qt.Unchecked
        root = self.tree.invisibleRootItem()
        self.tree.blockSignals(True)
        for i in range(root.childCount()):
            group = root.child(i)
            group.setCheckState(0, state)
            for j in range(group.childCount()):
                item = group.child(j)
                val = item.data(0, Qt.UserRole)
                if val:
                    item.setCheckState(0, state)
                    if self.current_tab == 1:
                        if checked:
                            self.selected_cloud_urls.add(val)
                        else:
                            self.selected_cloud_urls.discard(val)
                    else:
                        if checked:
                            self.selected_paths.add(val)
                        else:
                            self.selected_paths.discard(val)
        self.tree.blockSignals(False)
        self.update_tree_count_label()
        self.save_current_settings()

    def select_by_predicate(self, predicate):
        visible_paths = {project["path"]: predicate(project) for project in self.filtered_projects()}
        root = self.tree.invisibleRootItem()
        self.tree.blockSignals(True)
        for i in range(root.childCount()):
            group = root.child(i)
            for j in range(group.childCount()):
                item = group.child(j)
                path = item.data(0, Qt.UserRole)
                if path:
                    checked = bool(visible_paths.get(path, False))
                    item.setCheckState(0, Qt.Checked if checked else Qt.Unchecked)
                    if checked:
                        self.selected_paths.add(path)
                    else:
                        self.selected_paths.discard(path)
        self.tree.blockSignals(False)
        self.update_tree_count_label()
        self.save_current_settings()

    def restore_selected_projects(self):
        root = self.tree.invisibleRootItem()
        self.tree.blockSignals(True)
        for i in range(root.childCount()):
            group = root.child(i)
            for j in range(group.childCount()):
                item = group.child(j)
                path = item.data(0, Qt.UserRole)
                if path:
                    checked = path in self.selected_paths
                    item.setCheckState(0, Qt.Checked if checked else Qt.Unchecked)
        self.tree.blockSignals(False)
        self.update_tree_count_label()

    def select_sidebar_path(self, path):
        target = os.path.abspath(path)
        root = self.sidebar_tree.invisibleRootItem()
        for i in range(root.childCount()):
            found = self.find_sidebar_item(root.child(i), target)
            if found:
                self.sidebar_tree.setCurrentItem(found)
                parent = found.parent()
                while parent:
                    parent.setExpanded(True)
                    parent = parent.parent()
                return

    def find_sidebar_item(self, item, target):
        path = item.data(0, Qt.UserRole)
        if path and os.path.abspath(path) == target:
            return item
        for i in range(item.childCount()):
            found = self.find_sidebar_item(item.child(i), target)
            if found:
                return found
        return None

    def update_tree_count_label(self):
        t = UI_TRANSLATIONS[self.current_lang]
        if self.current_tab == 1:
            total = len(self.cloud_projects)
            selected = len(self.selected_cloud_urls)
            lbl_text = f"GITHUB CLOUD ({total} repo(s), {selected} selected)"
            if self.current_lang == "vi":
                lbl_text = f"GITHUB CLOUD ({total} dự án, đã chọn {selected})"
            self.lbl_tree.setText(lbl_text)
            return

        visible = len(self.filtered_projects())
        selected = len(self.selected_project_paths())
        hidden = sum(1 for p in self.projects if p["path"] in self.hidden_project_paths)
        self.lbl_tree.setText(t["lbl_tree_live"].format(total=visible, selected=selected, hidden=hidden))

    def open_selected_project(self):
        selected = self.selected_project_paths()
        if len(selected) == 1 and os.path.isdir(selected[0]):
            os.startfile(selected[0])
            return

        item = self.tree.currentItem()
        if not item:
            return
        path = item.data(0, Qt.UserRole) or item.text(10)
        if path and os.path.isdir(path):
            os.startfile(path)

    def save_current_settings(self, include_tree_state=True):
        selected_projects = (
            list(self.selected_paths)
            if include_tree_state
            else self.settings.get("last_selected_projects", [])
        )
        selected_cloud = (
            list(self.selected_cloud_urls)
            if include_tree_state
            else self.settings.get("last_selected_cloud_projects", [])
        )
        self.settings = {
            "last_root": self.txt_root.text().strip() or DEFAULT_ROOT,
            "remote_base": self.txt_remote_base.text().strip(),
            "commit_message": self.txt_commit.text().strip() or DEFAULT_COMMIT_MESSAGE,
            "max_depth": self.spin_depth.value(),
            "auto_create_repo": self.chk_auto_create_repo.isChecked(),
            "repo_public": self.chk_repo_public.isChecked(),
            "last_explorer_path": self.active_filter_path,
            "last_selected_projects": selected_projects,
            "last_selected_cloud_projects": selected_cloud,
            "last_lang": self.current_lang,
            "hidden_projects": list(self.hidden_project_paths),
            "license_author": self.txt_license_author.text().strip(),
        }
        save_settings(self.settings)

    def closeEvent(self, event):
        self.save_current_settings()
        super().closeEvent(event)

    def append_log(self, text):
        self.txt_console.moveCursor(QTextCursor.End)
        self.txt_console.insertPlainText(text)
        self.txt_console.verticalScrollBar().setValue(self.txt_console.verticalScrollBar().maximum())

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def txt_console_clear(self):
        self.txt_console.clear()

    def add_shadow(self, widget, color=None, radius=12):
        add_shadow(widget, self.is_dark, color, radius)

    def toggle_theme(self):
        self.is_dark = not self.is_dark
        self.apply_theme()
        
        # Refresh tree and sidebar views to apply correct theme colors
        if self.current_tab == 0:
            if hasattr(self, "projects") and self.projects:
                self.populate_sidebar(self.visible_projects())
                self.populate_tree(self.filtered_projects())
                self.restore_selected_projects()
        else:
            if hasattr(self, "cloud_projects") and self.cloud_projects:
                self.populate_cloud_sidebar()
                self.populate_cloud_tree()

    def toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def apply_theme(self):
        apply_app_theme(self)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if not urls:
            return
        path = urls[0].toLocalFile()
        if os.path.isdir(path):
            self.txt_root.setText(path)
            self.active_filter_path = ""
            self.save_current_settings(include_tree_state=False)
            self.start_scan()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self._drag_pos.isNull():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        self._drag_pos = QPoint()
        event.accept()

    # New localization methods
    def yes_no_local(self, value):
        t = UI_TRANSLATIONS[self.current_lang]
        return t["yes"] if value else t["no"]

    def change_language(self, lang):
        self.current_lang = lang
        
        # Update active properties for visual styling
        for code, btn in self.lang_buttons.items():
            active = (code == lang)
            btn.setProperty("active", active)
            btn.style().unpolish(btn)
            btn.style().polish(btn)
            
        self.retranslate_ui()
        self.save_current_settings()

    def set_other_languages_visible(self, visible):
        self.other_lang_widget.setVisible(visible)
        arrow = "⬅" if visible else "➔"
        t = UI_TRANSLATIONS[self.current_lang]
        self.btn_lang_more.setText(f"🌐 {t['btn_more']} {arrow}")

    def on_lang_container_enter(self, event):
        self.set_other_languages_visible(True)
        event.accept()

    def on_lang_container_leave(self, event):
        self.set_other_languages_visible(False)
        event.accept()

    def retranslate_ui(self):
        t = UI_TRANSLATIONS[self.current_lang]
        
        # Title
        self.lbl_title.setText(t["title_bar"])
        
        # More button text
        arrow = "⬅" if self.other_lang_widget.isVisible() else "➔"
        self.btn_lang_more.setText(f"🌐 {t['btn_more']} {arrow}")
        
        # Check select quick buttons
        self.btn_check_all.setToolTip(t["btn_check_all"])
        self.btn_uncheck_all.setToolTip(t["btn_uncheck_all"])
        self.btn_check_has_git.setToolTip(t["btn_check_has_git"])
        self.btn_check_no_git.setToolTip(t["btn_check_no_git"])
        self.btn_check_missing_form.setToolTip(t["btn_check_missing_form"])
        self.btn_open_project.setToolTip(t["btn_open_project"])
        self.btn_hide_project.setToolTip(t["btn_hide_project"])
        self.btn_rename_project.setToolTip(t["btn_rename_project"])
        self.btn_delete_project.setToolTip(t["btn_delete_project"])

        # Cloud quick buttons
        self.btn_filter_not_cloned.setToolTip(t["btn_filter_not_cloned"])
        self.btn_filter_behind_cloud.setToolTip(t["btn_filter_behind_cloud"])
        self.btn_change_visibility.setToolTip(t.get("btn_change_visibility", "Toggle Public/Private"))
        self.btn_sync_cloud.setText(t["btn_sync_cloud"])
        
        # View tabs
        self.tabs.setTabText(0, t["tab_local"])
        self.tabs.setTabText(1, t["tab_cloud"])
        
        # Console
        self.lbl_console.setText(t["lbl_console"])
        self.btn_clear_console.setText(t["btn_clear_console"])
        self.txt_console.setPlaceholderText(t["console_placeholder"])
        
        # Scan & Actions
        if self.current_tab == 1:
            self.btn_scan.setText(t["btn_scan_cloud"])
        else:
            self.btn_scan.setText(t["btn_scan"])
        self.btn_fix.setText(t["btn_fix"])
        self.btn_push.setText(t["btn_push"])
        
        # Left panel
        self.grp_scan.setTitle(t["grp_scan"])
        self.lbl_scan_root.setText(t["scan_label"])
        self.txt_root.setPlaceholderText(t["scan_placeholder"])
        self.lbl_scan_depth.setText(t["depth_label"])
        
        self.grp_sidebar.setTitle(t["grp_sidebar"])
        self.grp_push.setTitle(t["grp_push"])
        self.lbl_owner.setText(t["owner_label"])
        self.txt_remote_base.setPlaceholderText(t["owner_placeholder"])
        self.chk_auto_create_repo.setText(t["chk_auto_create"])
        self.chk_repo_public.setText(t["chk_repo_public"])
        self.lbl_commit_msg.setText(t["commit_label"])
        # Commit Message Placeholder
        commit_ph = "Enter commit message (leave blank to auto-generate)..."
        if self.current_lang == "vi":
            commit_ph = "Nhập commit message (để trống để tự động tạo)..."
        elif self.current_lang == "zh-cn":
            commit_ph = "输入提交信息 (留空以自动生成)..."
        elif self.current_lang == "ja-jp":
            commit_ph = "コミットメッセージを入力 (空欄で自動生成)..."
        elif self.current_lang == "es":
            commit_ph = "Ingresar mensaje (dejar en blanco para auto-generar)..."
        elif self.current_lang == "fr":
            commit_ph = "Saisir le message (laisser vide pour générer automatiquement)..."
        elif self.current_lang == "de":
            commit_ph = "Commit-Nachricht eingeben (leer lassen für automatische Erstellung)..."
        elif self.current_lang == "ru":
            commit_ph = "Введите сообщение (оставьте пустым для автогенерации)..."
        elif self.current_lang == "pt":
            commit_ph = "Digite a mensagem (deixe em branco para gerar automaticamente)..."
        elif self.current_lang == "ko":
            commit_ph = "커밋 메시지 입력 (자동 생성을 위해 비워둠)..."
        self.txt_commit.setPlaceholderText(commit_ph)
        
        self.lbl_push_note.setText(t["push_note"])
        
        self.grp_standard.setTitle(t["grp_standard"])
        self.lbl_std_note.setText(t["std_note"])
        self.lbl_license_author.setText(t["license_author_label"])
        
        # Status Label
        if self.lbl_status.text().startswith("Trang thai: Dang cho quet") or self.lbl_status.text().startswith("Status:") or self.lbl_status.text().startswith("Trạng thái:") or self.lbl_status.text().startswith("Trang thai:"):
            self.lbl_status.setText(t["status_waiting"])
            
        # Headers of tree & Repopulate
        if self.current_tab == 1:
            headers = [
                t["tree_headers"][0],
                t["tree_headers"][1],
                t["col_visibility"],
                "GitHub URL",
                "Last Updated",
                "Sync Status"
            ]
            self.tree.setHeaderLabels(headers)
            self.populate_cloud_tree()
        else:
            self.tree.setHeaderLabels(t["tree_headers"])
            self.update_eye_button_icon()
            if self.projects:
                self.populate_tree(self.filtered_projects())
                self.restore_selected_projects()
            else:
                self.update_tree_count_label()

    def visible_projects(self):
        if self.show_hidden_projects:
            return self.projects
        return [p for p in self.projects if p["path"] not in self.hidden_project_paths]

    def create_eye_icon(self, crossed=False):
        return create_eye_icon(self, crossed)

    def update_eye_button_icon(self):
        update_eye_button_icon(self)

    def on_toggle_hidden_visibility(self):
        self.show_hidden_projects = not self.show_hidden_projects
        self.update_eye_button_icon()
        
        # Update both sidebar and tree counts
        self.populate_sidebar(self.visible_projects())
        self.populate_tree(self.filtered_projects())
        self.restore_selected_projects()

    def on_hide_project_clicked(self):
        selected = self.selected_project_paths()
        if not selected:
            t = UI_TRANSLATIONS[self.current_lang]
            QMessageBox.information(self, t["msg_notice"], t["msg_no_selected"])
            return
            
        # Toggle hidden status
        any_not_hidden = any(path not in self.hidden_project_paths for path in selected)
        
        for path in selected:
            if any_not_hidden:
                self.hidden_project_paths.add(path)
                self.selected_paths.discard(path)
            else:
                self.hidden_project_paths.discard(path)
                
        self.save_current_settings()
        
        # Update sidebar and tree views
        self.populate_sidebar(self.visible_projects())
        self.populate_tree(self.filtered_projects())
        self.restore_selected_projects()
        
        t = UI_TRANSLATIONS[self.current_lang]
        msg = f"Đã ẩn/hiện {len(selected)} dự án." if self.current_lang == "vi" else f"Toggled visibility of {len(selected)} projects."
        self.lbl_status.setText(msg)

    def on_tab_changed(self, index):
        self.current_tab = index
        t = UI_TRANSLATIONS[self.current_lang]
        
        if index == 0:
            # Local Tab
            self.tree.setColumnCount(11)
            self.tree.setHeaderLabels(t["tree_headers"])
            
            self.btn_check_has_git.setVisible(True)
            self.btn_check_no_git.setVisible(True)
            self.btn_check_missing_form.setVisible(True)
            self.btn_open_project.setVisible(True)
            self.btn_hide_project.setVisible(True)
            self.btn_toggle_hidden.setVisible(True)
            self.btn_rename_project.setVisible(True)
            self.btn_delete_project.setVisible(True)
            self.btn_change_visibility.setVisible(False)
            
            self.btn_filter_not_cloned.setVisible(False)
            self.btn_filter_behind_cloud.setVisible(False)
            
            self.btn_fix.setVisible(True)
            self.btn_push.setVisible(True)
            self.btn_sync_cloud.setVisible(False)
            self.grp_push.setVisible(True)
            
            self.btn_scan.setText(t["btn_scan"])
            self.update_tree_count_label()
            
            self.populate_sidebar(self.visible_projects())
            self.populate_tree(self.filtered_projects())
            self.restore_selected_projects()
        else:
            # Cloud Tab
            self.tree.setColumnCount(8)
            headers = [
                t["tree_headers"][0],  # Project
                t["tree_headers"][1],  # Kind
                t["col_visibility"],   # Visibility
                "GitHub URL",
                "Last Updated",
                "Sync Status",
                "Commits",
                "Releases",
            ]
            self.tree.setHeaderLabels(headers)
            
            self.btn_check_has_git.setVisible(False)
            self.btn_check_no_git.setVisible(False)
            self.btn_check_missing_form.setVisible(False)
            self.btn_open_project.setVisible(False)
            self.btn_hide_project.setVisible(False)
            self.btn_toggle_hidden.setVisible(False)
            self.btn_rename_project.setVisible(True)
            self.btn_delete_project.setVisible(True)
            self.btn_change_visibility.setVisible(True)
            
            self.btn_filter_not_cloned.setVisible(True)
            self.btn_filter_behind_cloud.setVisible(True)
            
            self.btn_fix.setVisible(False)
            self.btn_push.setVisible(False)
            self.btn_sync_cloud.setVisible(True)
            self.grp_push.setVisible(False)
            
            self.btn_scan.setText(t["btn_scan_cloud"])
            
            self.populate_cloud_sidebar()
            self.populate_cloud_tree()

    def filtered_cloud_projects(self):
        if not self.active_cloud_filter_group:
            return self.cloud_projects
            
        filtered = []
        for project in self.cloud_projects:
            kind = project["kind"]
            if kind == "python" and self.active_cloud_filter_group == "PROJECT_PY":
                filtered.append(project)
            elif kind == "c#" and self.active_cloud_filter_group == "PROJECT_C#":
                filtered.append(project)
            elif kind == "ahk" and self.active_cloud_filter_group == "PROJECT_AHK":
                filtered.append(project)
            elif kind == "node" and self.active_cloud_filter_group == "PROJECT_JS":
                filtered.append(project)
            elif kind == "powershell" and self.active_cloud_filter_group == "PROJECT_PS1":
                filtered.append(project)
            elif kind == "project" and self.active_cloud_filter_group == "OTHERS":
                filtered.append(project)
        return filtered

    def populate_cloud_sidebar(self):
        self.sidebar_tree.blockSignals(True)
        self.sidebar_tree.clear()
        
        t = UI_TRANSLATIONS[self.current_lang]
        total = len(self.cloud_projects)
        
        root_label = "GitHub Cloud"
        root_item = QTreeWidgetItem([f"{root_label} ({total})"])
        root_item.setData(0, Qt.UserRole, "")
        self.sidebar_tree.addTopLevelItem(root_item)
        
        counts = {
            "PROJECT_PY": 0,
            "PROJECT_C#": 0,
            "PROJECT_AHK": 0,
            "PROJECT_JS": 0,
            "PROJECT_PS1": 0,
            "OTHERS": 0,
        }
        for project in self.cloud_projects:
            kind = project["kind"]
            if kind == "python":
                counts["PROJECT_PY"] += 1
            elif kind == "c#":
                counts["PROJECT_C#"] += 1
            elif kind == "ahk":
                counts["PROJECT_AHK"] += 1
            elif kind == "node":
                counts["PROJECT_JS"] += 1
            elif kind == "powershell":
                counts["PROJECT_PS1"] += 1
            else:
                counts["OTHERS"] += 1
                
        for group, count in counts.items():
            if count > 0:
                item = QTreeWidgetItem([f"{group} ({count})"])
                item.setData(0, Qt.UserRole, group)
                root_item.addChild(item)
                
        root_item.setExpanded(True)
        if hasattr(self, "active_cloud_filter_group") and self.active_cloud_filter_group:
            self.select_cloud_sidebar_group(self.active_cloud_filter_group)
        self.sidebar_tree.blockSignals(False)

    def select_cloud_sidebar_group(self, group):
        root = self.sidebar_tree.invisibleRootItem()
        for i in range(root.childCount()):
            found = self.find_sidebar_item(root.child(i), group)
            if found:
                self.sidebar_tree.setCurrentItem(found)
                return

    def populate_cloud_tree(self):
        self.tree.blockSignals(True)
        self.tree.setSortingEnabled(False)
        self.tree.clear()
        
        t = UI_TRANSLATIONS[self.current_lang]
        filtered_repos = self.filtered_cloud_projects()
        total = len(filtered_repos)
        selected_count = len(self.selected_cloud_urls)
        
        lbl_text = f"GITHUB CLOUD ({total} repo(s), {selected_count} selected)"
        if self.current_lang == "vi":
            lbl_text = f"GITHUB CLOUD ({total} dự án, đã chọn {selected_count})"
        self.lbl_tree.setText(lbl_text)
        
        roots = {}
        for project in filtered_repos:
            kind = project["kind"]
            if kind == "python":
                group_name = "PROJECT_PY"
            elif kind == "c#":
                group_name = "PROJECT_C#"
            elif kind == "ahk":
                group_name = "PROJECT_AHK"
            elif kind == "node":
                group_name = "PROJECT_JS"
            elif kind == "powershell":
                group_name = "PROJECT_PS1"
            else:
                group_name = "OTHERS"
                
            if group_name not in roots:
                parent_item = QTreeWidgetItem([group_name, "group", "", "", "", "", "", ""])
                parent_item.setFlags(parent_item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsAutoTristate)
                parent_item.setCheckState(0, Qt.Unchecked)
                parent_item.setData(0, Qt.UserRole, "")
                roots[group_name] = parent_item
                self.tree.addTopLevelItem(parent_item)
                
            status_key = f"status_{project['sync_status'].lower().replace(' ', '_')}"
            localized_status = t.get(status_key, project["sync_status"])
            
            is_priv = project.get("is_private", True)
            vis_text = f"🔒 {t.get('vis_private', 'Private')}" if is_priv else f"🌐 {t.get('vis_public', 'Public')}"
            
            item = QTreeWidgetItem([
                project["name"],
                project["kind"],
                vis_text,
                project["url"],
                project["updated_at"],
                localized_status,
                "",   # commits btn placeholder
                "",   # releases btn placeholder
            ])
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            checked = project["url"] in self.selected_cloud_urls
            item.setCheckState(0, Qt.Checked if checked else Qt.Unchecked)
            item.setData(0, Qt.UserRole, project["url"])
            item.setData(0, Qt.UserRole + 1, project["name"])   # store repo name
            
            sync_status = project["sync_status"]
            if self.is_dark:
                if sync_status == "Up to date":
                    color = QColor("#00ff9d")
                elif sync_status == "Not Cloned":
                    color = QColor("#00f0ff")
                elif sync_status == "Needs Pull":
                    color = QColor("#ffbd2e")
                else: # Local Modified
                    color = QColor("#ff5f56")
            else:
                if sync_status == "Up to date":
                    color = QColor("#008f5d")
                elif sync_status == "Not Cloned":
                    color = QColor("#007da0")
                elif sync_status == "Needs Pull":
                    color = QColor("#b87a00")
                else: # Local Modified
                    color = QColor("#d93829")
                
            for col in range(self.tree.columnCount()):
                item.setForeground(col, color)
                
            roots[group_name].addChild(item)

            # Commits button - col 6
            repo_url  = project["url"]
            repo_name = project["name"]
            btn_commits = QPushButton("🕐 Commits")
            btn_commits.setObjectName("CommitsBtn")
            btn_commits.setToolTip(f"View commit history for {repo_name}")
            btn_commits.setFixedSize(88, 22)
            btn_commits.clicked.connect(
                lambda checked=False, rn=repo_name, ru=repo_url, b=btn_commits:
                    self._open_commit_history(rn, ru, btn_ref=b)
            )
            cell_w = QWidget()
            cell_l = QHBoxLayout(cell_w)
            cell_l.setContentsMargins(3, 1, 3, 1)
            cell_l.setAlignment(Qt.AlignCenter)
            cell_l.addWidget(btn_commits)
            self.tree.setItemWidget(item, 6, cell_w)

            # Releases button - col 7
            btn_releases = QPushButton("📦 Releases")
            btn_releases.setObjectName("btnCloudRelease")
            btn_releases.setToolTip(f"View and download releases for {repo_name}")
            btn_releases.setFixedSize(90, 22)
            btn_releases.clicked.connect(
                lambda checked=False, rn=repo_name: self._open_cloud_release_dialog(rn)
            )
            cell_r  = QWidget()
            cell_rl = QHBoxLayout(cell_r)
            cell_rl.setContentsMargins(3, 1, 3, 1)
            cell_rl.setAlignment(Qt.AlignCenter)
            cell_rl.addWidget(btn_releases)
            self.tree.setItemWidget(item, 7, cell_r)

        self.tree.expandAll()
        n_cols = self.tree.columnCount()
        hdr = self.tree.header()
        hdr.setStretchLastSection(False)          # prevent last col from filling all space
        # Content-fit all cols except last 2 (buttons)
        for col in range(n_cols - 2):
            self.tree.resizeColumnToContents(col)
            hdr.setSectionResizeMode(col, QHeaderView.Interactive)
        # Lock button cols to fixed width so they never stretch
        hdr.setSectionResizeMode(n_cols - 2, QHeaderView.Fixed)
        hdr.setSectionResizeMode(n_cols - 1, QHeaderView.Fixed)
        self.tree.setColumnWidth(n_cols - 2, 96)    # Commits
        self.tree.setColumnWidth(n_cols - 1, 100)   # Releases
        self.tree.setSortingEnabled(True)
        self.tree.blockSignals(False)

    def select_not_cloned(self):
        if self.current_tab != 1:
            return
        self.tree.blockSignals(True)
        for i in range(self.tree.topLevelItemCount()):
            parent = self.tree.topLevelItem(i)
            for j in range(parent.childCount()):
                child = parent.child(j)
                url = child.data(0, Qt.UserRole)
                for p in self.cloud_projects:
                    if p["url"] == url:
                        if p["sync_status"] == "Not Cloned":
                            child.setCheckState(0, Qt.Checked)
                            self.selected_cloud_urls.add(url)
                        else:
                            child.setCheckState(0, Qt.Unchecked)
                            self.selected_cloud_urls.discard(url)
        self.tree.blockSignals(False)
        self.update_tree_count_label()
        self.save_current_settings()

    def select_behind_cloud(self):
        if self.current_tab != 1:
            return
        self.tree.blockSignals(True)
        for i in range(self.tree.topLevelItemCount()):
            parent = self.tree.topLevelItem(i)
            for j in range(parent.childCount()):
                child = parent.child(j)
                url = child.data(0, Qt.UserRole)
                for p in self.cloud_projects:
                    if p["url"] == url:
                        if p["sync_status"] == "Needs Pull":
                            child.setCheckState(0, Qt.Checked)
                            self.selected_cloud_urls.add(url)
                        else:
                            child.setCheckState(0, Qt.Unchecked)
                            self.selected_cloud_urls.discard(url)
        self.tree.blockSignals(False)
        self.update_tree_count_label()
        self.save_current_settings()

    def on_cloud_scan_finished(self, cloud_projects):
        self.cloud_projects = cloud_projects
        self.lock_actions(False)
        self.progress_bar.setValue(100)
        
        t = UI_TRANSLATIONS[self.current_lang]
        msg = f"Đã quét xong {len(cloud_projects)} dự án đám mây." if self.current_lang == "vi" else f"Scanned {len(cloud_projects)} cloud repositories."
        self.lbl_status.setText(msg)
        self.append_log(f"[OK] Fetched {len(cloud_projects)} cloud repo(s).\n")
        
        if self.current_tab == 1:
            self.populate_cloud_sidebar()
            self.populate_cloud_tree()

    def start_cloud_scan(self):
        root = self.txt_root.text().strip()
        if not root or not os.path.isdir(root):
            t = UI_TRANSLATIONS[self.current_lang]
            QMessageBox.critical(self, t["msg_error"], t["msg_invalid_root"])
            return

        self.save_current_settings(include_tree_state=False)
        self.lock_actions(True)
        if self.current_tab == 1:
            self.tree.clear()
        self.cloud_projects = []
        self.txt_console.clear()
        self.progress_bar.setValue(5)
        t = UI_TRANSLATIONS[self.current_lang]
        self.lbl_status.setText(t["status_scanning"])
        self.append_log("[CLOUD SCAN] Fetching cloud repository list...\n")
        
        self.worker_thread = threading.Thread(
            target=self.runner.fetch_cloud_repositories,
            args=(self.txt_remote_base.text().strip(), root),
            daemon=True,
        )
        self.worker_thread.start()

    def start_cloud_sync(self):
        if not self.selected_cloud_urls:
            t = UI_TRANSLATIONS[self.current_lang]
            QMessageBox.information(self, t["msg_notice"], t["msg_no_selected"])
            return
            
        sync_tasks = []
        for url in self.selected_cloud_urls:
            proj = next((p for p in self.cloud_projects if p["url"] == url), None)
            if not proj:
                continue
                
            sync_status = proj["sync_status"]
            repo_name = proj["name"]
            local_path = proj["local_path"]
            
            action_type = "skip"
            if sync_status == "Not Cloned":
                action_type = "clone"
            elif sync_status == "Needs Pull":
                action_type = "pull"
            elif sync_status == "Local Modified":
                choice = self.prompt_conflict_resolution(repo_name)
                if choice == "overwrite":
                    action_type = "overwrite"
                elif choice == "stash":
                    action_type = "stash"
                else:
                    action_type = "skip"
            elif sync_status == "Up to date":
                action_type = "skip"
                
            if action_type != "skip":
                sync_tasks.append({
                    "action_type": action_type,
                    "repo_url": url,
                    "local_path": local_path,
                    "repo_name": repo_name
                })
                
        if not sync_tasks:
            msg = "Không có tác vụ đồng bộ nào cần thực hiện." if self.current_lang == "vi" else "No sync tasks to perform."
            self.lbl_status.setText(msg)
            return
            
        self.save_current_settings(include_tree_state=False)
        self.run_operation(
            "Dang dong bo repository cloud...",
            self.runner.sync_cloud_projects,
            sync_tasks
        )

    def on_rename_project_clicked(self):
        t = UI_TRANSLATIONS[self.current_lang]
        if self.current_tab == 1:
            if not self.selected_cloud_urls:
                QMessageBox.information(self, t["msg_notice"], t["msg_no_selected"])
                return
            if len(self.selected_cloud_urls) > 1:
                msg = "Vui lòng chỉ chọn một dự án để đổi tên." if self.current_lang == "vi" else "Please select only one project to rename."
                QMessageBox.information(self, t["msg_notice"], msg)
                return
                
            old_url = list(self.selected_cloud_urls)[0]
            proj = next((p for p in self.cloud_projects if p["url"] == old_url), None)
            if not proj:
                return
            old_name = proj["name"]
            
            from PySide6.QtWidgets import QInputDialog
            dialog = QInputDialog(self)
            dialog.setWindowTitle(t["msg_rename_title"])
            dialog.setLabelText(t["msg_rename_prompt"].format(name=old_name))
            dialog.setTextValue(old_name)
            dialog.setWindowFlags(dialog.windowFlags() & ~Qt.WindowContextHelpButtonHint)
            
            border = "rgba(255, 255, 255, 0.15)" if self.is_dark else "rgba(0, 0, 0, 0.15)"
            bg = "rgba(18, 18, 18, 0.95)" if self.is_dark else "rgba(240, 240, 240, 0.95)"
            text_color = "#ffffff" if self.is_dark else "#121212"
            accent_cyan = "#00f0ff"
            dialog.setStyleSheet(f"""
                QInputDialog {{ background-color: {bg}; color: {text_color}; }}
                QLabel {{ color: {text_color}; font-family: '{FONT_PRIMARY}'; font-size: 12px; }}
                QLineEdit {{ background-color: rgba({('0,0,0' if self.is_dark else '255,255,255')}, 0.4); color: {text_color}; border: 1px solid {border}; border-radius: 6px; padding: 5px; }}
                QPushButton {{ background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')}, 0.05); color: {text_color}; border: 1px solid {border}; border-radius: 6px; padding: 6px 12px; font-weight: bold; }}
                QPushButton:hover {{ border-color: {accent_cyan}; background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')}, 0.12); }}
            """)
            if dialog.exec() != QInputDialog.Accepted:
                return
                
            new_name = dialog.textValue().strip()
            if not new_name or new_name == old_name:
                return
                
            invalid_chars = '<>:"/\\|?* '
            if any(c in new_name for c in invalid_chars):
                invalid_msg = "Tên không hợp lệ (không chứa khoảng trắng hoặc ký tự <>:\"/\\|?*)." if self.current_lang == "vi" else "Invalid name (cannot contain spaces or <>:\"/\\|?*)."
                QMessageBox.critical(self, t["msg_error"], invalid_msg)
                return
                
            self.run_operation(
                f"Đang đổi tên repo {old_name} thành {new_name} trên GitHub...",
                self.runner.rename_cloud_repo,
                self.txt_remote_base.text().strip(),
                old_name,
                new_name
            )
            self.selected_cloud_urls.clear()
            return

        selected = self.selected_project_paths()
        if not selected:
            QMessageBox.information(self, t["msg_notice"], t["msg_no_selected"])
            return
        if len(selected) > 1:
            msg = "Vui lòng chỉ chọn một dự án để đổi tên." if self.current_lang == "vi" else "Please select only one project to rename."
            QMessageBox.information(self, t["msg_notice"], msg)
            return

        old_path = selected[0]
        old_name = os.path.basename(old_path)
        
        from PySide6.QtWidgets import QInputDialog
        dialog = QInputDialog(self)
        dialog.setWindowTitle(t["msg_rename_title"])
        dialog.setLabelText(t["msg_rename_prompt"].format(name=old_name))
        dialog.setTextValue(old_name)
        dialog.setWindowFlags(dialog.windowFlags() & ~Qt.WindowContextHelpButtonHint)
        
        border = "rgba(255, 255, 255, 0.15)" if self.is_dark else "rgba(0, 0, 0, 0.15)"
        bg = "rgba(18, 18, 18, 0.95)" if self.is_dark else "rgba(240, 240, 240, 0.95)"
        text_color = "#ffffff" if self.is_dark else "#121212"
        accent_cyan = "#00f0ff"
        
        dialog.setStyleSheet(f"""
            QInputDialog {{
                background-color: {bg};
                color: {text_color};
            }}
            QLabel {{
                color: {text_color};
                font-family: '{FONT_PRIMARY}';
                font-size: 12px;
            }}
            QLineEdit {{
                background-color: rgba({('0,0,0' if self.is_dark else '255,255,255')}, 0.4);
                color: {text_color};
                border: 1px solid {border};
                border-radius: 6px;
                padding: 5px;
            }}
            QPushButton {{
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')}, 0.05);
                color: {text_color};
                border: 1px solid {border};
                border-radius: 6px;
                padding: 6px 12px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                border-color: {accent_cyan};
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')}, 0.12);
            }}
        """)
        
        if dialog.exec() != QInputDialog.Accepted:
            return
            
        new_name = dialog.textValue().strip()
        if not new_name or new_name == old_name:
            return
            
        invalid_chars = '<>:"/\\|?*'
        if any(c in new_name for c in invalid_chars):
            invalid_msg = "Tên không hợp lệ (không chứa ký tự <>:\"/\\|?*)." if self.current_lang == "vi" else "Invalid folder name (cannot contain <>:\"/\\|?*)."
            QMessageBox.critical(self, t["msg_error"], invalid_msg)
            return
            
        parent_dir = os.path.dirname(old_path)
        new_path = os.path.join(parent_dir, new_name)
        
        if os.path.exists(new_path):
            exists_msg = "Thư mục đích đã tồn tại." if self.current_lang == "vi" else "Destination folder already exists."
            QMessageBox.critical(self, t["msg_error"], exists_msg)
            return
            
        try:
            os.rename(old_path, new_path)
            self.selected_paths.discard(old_path)
            self.selected_paths.add(new_path)
            if old_path in self.hidden_project_paths:
                self.hidden_project_paths.discard(old_path)
                self.hidden_project_paths.add(new_path)
                
            self.append_log(f"[RENAME] Renamed {old_path} -> {new_path}\n")
            QMessageBox.information(self, t["msg_notice"], t["msg_rename_success"])
            self.start_scan()
        except Exception as e:
            QMessageBox.critical(self, t["msg_error"], str(e))

    def on_delete_project_clicked(self):
        t = UI_TRANSLATIONS[self.current_lang]
        if self.current_tab == 1:
            if not self.selected_cloud_urls:
                QMessageBox.information(self, t["msg_notice"], t["msg_no_selected"])
                return
            selected_repos = []
            for url in self.selected_cloud_urls:
                proj = next((p for p in self.cloud_projects if p["url"] == url), None)
                if proj:
                    selected_repos.append(proj)
            if not selected_repos:
                return
            if len(selected_repos) == 1:
                name = selected_repos[0]["name"]
                confirm_msg = f"Bạn có chắc chắn muốn xóa vĩnh viễn kho lưu trữ '{name}' trên GitHub không? Hành động này không thể hoàn tác." if self.current_lang == "vi" else f"Are you sure you want to permanently delete repository '{name}' on GitHub? This cannot be undone."
            else:
                confirm_msg = (
                    f"Bạn có chắc chắn muốn xóa vĩnh viễn {len(selected_repos)} kho lưu trữ đã chọn trên GitHub không? Hành động này không thể hoàn tác."
                    if self.current_lang == "vi"
                    else f"Are you sure you want to permanently delete {len(selected_repos)} selected repositories on GitHub? This cannot be undone."
                )
            reply = QMessageBox.question(
                self,
                t["msg_delete_title"],
                confirm_msg,
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
            repo_names = [r["name"] for r in selected_repos]
            self.run_operation(
                f"Đang xóa {len(repo_names)} repo trên GitHub...",
                self.runner.delete_cloud_repos,
                self.txt_remote_base.text().strip(),
                repo_names
            )
            self.selected_cloud_urls.clear()
            return

        selected = self.selected_project_paths()
        if not selected:
            QMessageBox.information(self, t["msg_notice"], t["msg_no_selected"])
            return
            
        if len(selected) == 1:
            name = os.path.basename(selected[0])
            confirm_msg = t["msg_delete_confirm"].format(name=name)
        else:
            confirm_msg = (
                f"Bạn có chắc chắn muốn xóa vĩnh viễn {len(selected)} dự án đã chọn khỏi đĩa? Thao tác này không thể hoàn tác."
                if self.current_lang == "vi"
                else f"Are you sure you want to permanently delete {len(selected)} selected projects from disk? This cannot be undone."
            )
            
        reply = QMessageBox.question(
            self,
            t["msg_delete_title"],
            confirm_msg,
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply != QMessageBox.Yes:
            return
            
        import shutil
        success_count = 0
        for path in selected:
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path)
                    self.selected_paths.discard(path)
                    self.hidden_project_paths.discard(path)
                    self.append_log(f"[DELETE] Deleted project folder: {path}\n")
                    success_count += 1
            except Exception as e:
                self.append_log(f"[ERROR] Failed to delete {path}: {e}\n")
                QMessageBox.critical(self, t["msg_error"], f"Failed to delete {path}: {e}")
                
        if success_count > 0:
            QMessageBox.information(self, t["msg_notice"], t["msg_delete_success"])
            self.start_scan()
    def on_change_visibility_clicked(self):
        t = UI_TRANSLATIONS[self.current_lang]
        if not self.selected_cloud_urls:
            QMessageBox.information(self, t["msg_notice"], t["msg_no_selected"])
            return
            
        selected_repos = []
        for url in self.selected_cloud_urls:
            proj = next((p for p in self.cloud_projects if p["url"] == url), None)
            if proj:
                selected_repos.append(proj)
                
        if not selected_repos:
            return
            
        changes_msg = ""
        repo_items = []
        for r in selected_repos:
            current_priv = r.get("is_private", True)
            target_vis = "public" if current_priv else "private"
            repo_items.append((r["name"], target_vis))
            
            curr_str = t["vis_private"] if current_priv else t["vis_public"]
            tgt_str = t["vis_public"] if current_priv else t["vis_private"]
            changes_msg += f"- {r['name']}: {curr_str} ➔ {tgt_str}\n"
            
        confirm_title = "Thay đổi chế độ hiển thị" if self.current_lang == "vi" else "Change Repository Visibility"
        confirm_prompt = (
            f"Bạn có chắc chắn muốn thay đổi chế độ hiển thị cho các repository sau trên GitHub không?\n\n{changes_msg}\nLưu ý: Thay đổi chế độ hiển thị có thể ảnh hưởng đến fork, stars và các cài đặt khác."
            if self.current_lang == "vi"
            else f"Are you sure you want to change repository visibility on GitHub for the following?\n\n{changes_msg}\nNote: Changing visibility may affect forks, stars, and other settings."
        )
        
        reply = QMessageBox.question(
            self,
            confirm_title,
            confirm_prompt,
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return
            
        self.run_operation(
            f"Đang thay đổi chế độ hiển thị cho {len(repo_items)} repo trên GitHub...",
            self.runner.change_cloud_repos_visibility,
            self.txt_remote_base.text().strip(),
            repo_items
        )
        self.selected_cloud_urls.clear()

    def prompt_conflict_resolution(self, repo_name):
        dialog = ConflictResolutionDialog(self, repo_name, self.current_lang, self.is_dark)
        dialog.exec()
        return dialog.choice

    # ── Commit history (Cloud tab) ────────────────────────────────────────────

    def _open_commit_history(self, repo_name: str, repo_url: str, btn_ref=None):
        """Open the CommitHistoryDialog for the given cloud repo."""
        from ..github_ops import resolve_github_owner
        remote_base = self.txt_remote_base.text().strip()
        owner = resolve_github_owner(remote_base)
        if not owner:
            from ..github_ops import default_github_owner
            owner = default_github_owner()
        dlg = CommitHistoryDialog(
            self,
            owner=owner,
            repo_name=repo_name,
            repo_url=repo_url,
            current_lang=self.current_lang,
            is_dark=self.is_dark,
            btn_ref=btn_ref,
        )
        dlg.exec()

    def _open_release_dialog(self, project: dict):
        """Open the ReleaseDialog to create a GitHub Release for a local project."""
        dlg = ReleaseDialog(self, project=project, is_dark=self.is_dark)
        dlg.exec()

    def _open_cloud_release_dialog(self, repo_name: str):
        """Open CloudReleaseDialog to view and download GitHub Releases."""
        from ..github_ops import resolve_github_owner, default_github_owner
        remote_base = self.txt_remote_base.text().strip()
        owner = resolve_github_owner(remote_base) or default_github_owner()
        dlg = CloudReleaseDialog(self, owner=owner, repo_name=repo_name, is_dark=self.is_dark)
        dlg.exec()


def yes_no(value):
    return "YES" if value else "NO"
