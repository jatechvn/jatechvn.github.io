<a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="README.zh-CN.md">🇨🇳 中文</a> • <a href="README.ja-JP.md">🇯🇵 日本語</a> • <a href="README.es.md">🇪🇸 Español</a> • <a href="README.fr.md">🇫🇷 Français</a> • 🇩🇪 Deutsch • <a href="README.ru.md">🇷🇺 Русский</a> • <a href="README.pt.md">🇵🇹 Português</a> • <a href="README.ko.md">🇰🇷 한국어</a>

# 🚀 JA Auto Git

**Professionelle Git-Automatisierung & Release-Management-Suite**

> Ein leistungsstarkes Desktop-Tool zum Automatisieren von Git-Commits, Verwalten von Versionierungs-Workflows und Veröffentlichen von GitHub-Releases — alles über eine elegante Liquid-Glass-Benutzeroberfläche.

---

## ✨ Funktionen

### 1. 🔍 Dynamischer Projekt-Scanner (automatische Versionserkennung)

- Scannt automatisch Projekte im konfigurierten Stammverzeichnis
- Erkennt intelligente Versionsnummern aus verschiedenen Projekttypen:
  - `package.json` → Node.js / JavaScript
  - `pyproject.toml` / `setup.py` → Python
  - `pubspec.yaml` → Flutter / Dart
  - `build.gradle` / `build.gradle.kts` → Android / Kotlin
  - `*.csproj` → .NET / C#
  - `Cargo.toml` → Rust
  - `composer.json` → PHP
  - `pom.xml` → Java / Maven
  - `CMakeLists.txt` → C / C++
  - `*.gemspec` / `Gemfile` → Ruby
- Zeigt die Version jedes Projekts in Echtzeit in der Tabelle an
- Unterstützt mehrere Projekte gleichzeitig in einer einzigen Sitzung

---

### 2. 📁 Standardisierte Projektstruktur

JA Auto Git setzt eine saubere, konsistente Ordnerstruktur für alle verwalteten Projekte durch:

```
PROJECT_ROOT/
├── assets/
│   └── images/          # Screenshots, Vorschaubilder
├── i18n/                # Übersetzte README-Dateien
├── src/                 # Quellcode
├── tests/               # Tests
├── docs/                # Dokumentation
├── CHANGELOG.md         # Automatisch gepflegt
└── README.md
```

- Verzeichnisse werden bei Bedarf automatisch erstellt
- Hält Projekte organisiert und GitHub-bereit

---

### 3. 🧠 Intelligente Auto-Changelog Commit-Engine

- Generiert automatisch gut formatierte `CHANGELOG.md`-Einträge
- Konventionelle Commit-Typen: `feat`, `fix`, `docs`, `refactor`, `chore`, `test`, `style`, `perf`
- Jeder Commit enthält:
  - Versionsnummer
  - Commit-Typ und -Beschreibung
  - Zeitstempel
  - Vollständige Git-Metadaten
- Staged-Änderungen werden automatisch erkannt und committed
- Unterstützt optionale benutzerdefinierte Commit-Nachrichten
- Führt automatisch `git push` nach dem Commit durch

---

### 4. 🚀 Release-Manager *(Neu in v1.5.0)*

Ein vollständig integrierter Release-Workflow direkt in der App:

- **🚀 Release-Button** — Startet den geführten Release-Erstellungs-Dialog
- **Auto-Tag** — Erstellt automatisch Git-Tags im Format `v{version}` basierend auf der erkannten Projektversion
- **Assets anhängen** — Wähle beliebige Dateien (ZIP, APK, EXE, DMG usw.) aus und lade sie als Release-Assets hoch
- **Hintergrund-Push** — Tag und Release werden im Hintergrund gepusht, ohne den UI-Thread zu blockieren
- **Release-Notizen** — Füge benutzerdefinierte Release-Notizen hinzu oder generiere sie automatisch aus dem Changelog
- Zeigt Echtzeit-Fortschrittsstatus während des Uploads an

---

### 5. ☁️ GitHub Cloud Tab — Commits & Releases *(Aktualisiert v1.5.0)*

Ein eingebetteter Cloud-Browser direkt in der App:

**Commit-Verlauf:**
- Zeigt die neuesten Commits für jedes Projekt an
- Spalten: Nachricht, Autor, Datum, SHA
- **ZIP-Download** — Lade den Repository-Snapshot für jeden Commit als ZIP-Datei herunter

**Release-Browser:**
- Listet alle GitHub-Releases für das ausgewählte Projekt auf
- Spalten: Tag, Titel, Datum, Assets
- **Asset-Download** — Lade einzelne Release-Assets direkt aus der App herunter
- Unterstützt öffentliche und private Repositories (über konfigurierten Token)

---

### 6. 🪟 Liquid Glass UI (macOS-Steuerelemente, feste Spaltenbreiten)

- Modernes **Liquid Glass**-Design mit transluzenten Ebenen und weichen Schatten
- **macOS-ähnliche Fenstersteuerelemente** (Schließen, Minimieren, Maximieren) — benutzerdefiniert gestaltet
- **Feste Spaltenbreiten** in allen Tabellen für konsistente, übersichtliche Darstellung
- Sanfte Übergänge und Animationen
- Reaktionsfähiges Layout für verschiedene Fenstergrößen
- Dunkles Design als Standard — optimiert für lange Arbeitszeiten

---

### 7. 🔀 Plattformübergreifende Hybrid-Engine

- Erkennt automatisch das Betriebssystem (Windows / macOS / Linux)
- Passt Git-Befehle, Dateipfade und Shell-Aufrufe je nach Plattform an
- Einheitliche Benutzeroberfläche auf allen Plattformen
- Kein plattformspezifischer Code erforderlich — einfach ausführen und es funktioniert

---

### 8. 🔄 Automatische Cloud-Synchronisation

- Pusht Commits automatisch nach jedem erfolgreichen lokalen Commit zu GitHub
- Erkennt Remote-URL und Branch-Informationen aus der Git-Konfiguration
- Behandelt Authentifizierung über gespeicherte Anmeldedaten oder konfigurierten Token
- Zeigt Push-Ergebnis (Erfolg / Fehler) in der Statusleiste an
- Optionaler Hintergrund-Push-Modus für Release-Tags

---

### 9. 🪪 Automatische Git-Identitätskonfiguration

- Erkennt und konfiguriert automatisch `user.name` und `user.email` für Git
- Liest aus der globalen Git-Konfiguration oder dem gespeicherten App-Profil
- Verhindert „Unbekannter Autor"-Commits
- Unterstützt die Verwendung mehrerer Identitäten für verschiedene Projekte

---

## 📸 Screenshots

![Hauptoberfläche](../assets/images/screenshot-main.png)
![Release-Manager](../assets/images/screenshot-release.png)
![Cloud-Tab](../assets/images/screenshot-cloud.png)

---

## 🛠️ Installation

### Voraussetzungen

- Python 3.10 oder höher
- Git (installiert und im PATH)
- GitHub-Konto (für Cloud-Funktionen)

### Schnellstart

```bash
# Repository klonen
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY

# Abhängigkeiten installieren
pip install -r requirements.txt

# App starten
python src/main.py
```

---

## ⚙️ Konfiguration

Beim ersten Start wird eine Konfigurationsdatei erstellt unter:

```
~/.ja_auto_git/config.json
```

Wichtige Einstellungen:

```json
{
  "root_dir": "D:/Projects",
  "github_token": "ghp_xxxxxxxxxxxx",
  "default_branch": "main",
  "auto_push": true,
  "language": "de"
}
```

| Einstellung | Beschreibung |
|---|---|
| `root_dir` | Stammverzeichnis, das nach Projekten durchsucht wird |
| `github_token` | GitHub Personal Access Token für API-Zugriff |
| `default_branch` | Standard-Branch für Push-Vorgänge |
| `auto_push` | Automatisch nach dem Commit pushen |
| `language` | UI-Sprache |

---

## 📦 Changelog

### v1.5.0 — Release-Manager & Cloud-Verbesserungen

- 🚀 **Neu:** Release-Manager — geführter Release-Erstellungs-Dialog mit Asset-Upload
- 🌐 **Neu:** Release-Browser im Cloud-Tab — alle GitHub-Releases durchsuchen und Assets herunterladen
- 📊 **Neu:** Versions-Spalte in der Projekttabelle — Versionsnummer auf einen Blick
- 📐 **Neu:** Feste Spaltenbreiten in allen Tabellen — konsistente, übersichtliche Darstellung
- 🐛 Diverse Fehlerbehebungen und Performance-Verbesserungen

### v1.4.0

- Hinzufügen des GitHub Cloud Tabs mit Commit-Verlauf und ZIP-Download
- Plattformübergreifende Verbesserungen der Hybrid-Engine
- Automatische Git-Identitätserkennung

### v1.3.0

- Liquid Glass UI eingeführt
- macOS-Fenstersteuerelemente hinzugefügt
- Verbesserte Changelog-Generierung

### v1.2.0

- Dynamischer Projekt-Scanner mit Versionserkennung
- Unterstützung für 10+ Projekttypen

### v1.1.0

- Erste stabile Version
- Standardisierte Projektstruktur
- Automatische Cloud-Synchronisation

---

## 🤝 Mitwirken

Beiträge sind herzlich willkommen! Bitte öffne zuerst ein Issue, um Änderungen zu besprechen, bevor du einen Pull Request einreichst.

1. Forke das Repository
2. Erstelle einen Feature-Branch: `git checkout -b feature/meine-funktion`
3. Committe deine Änderungen: `git commit -m 'feat: meine neue Funktion hinzufügen'`
4. Pushe zum Branch: `git push origin feature/meine-funktion`
5. Öffne einen Pull Request

---

## 📄 Lizenz

Dieses Projekt ist unter der MIT-Lizenz lizenziert — siehe die Datei [LICENSE](../LICENSE) für Details.

---

<p align="center">
  Copyright © John Alaa @ 2026. Alle Rechte vorbehalten.<br/>
  Erstellt mit ❤️ für Entwickler weltweit.
</p>
