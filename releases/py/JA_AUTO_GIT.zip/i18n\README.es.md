# 🤖 JA Auto Git — Liquid Glass Edition

<p align="center">
  <img src="../assets/images/icon.ico" alt="JA Auto Git Logo" width="120" height="120">
  <br>
  <i>Gestión automatizada de Git y creador inteligente de repositorios GitHub para desarrolladores.</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=for-the-badge&logo=python&logoColor=white" alt="Python Version">
  <img src="https://img.shields.io/badge/GUI-PySide6-green.svg?style=for-the-badge&logo=qt&logoColor=white" alt="UI Framework">
  <img src="https://img.shields.io/badge/Integrations-GitHub_CLI-purple.svg?style=for-the-badge&logo=github&logoColor=white" alt="Integrations">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge" alt="License">
  <img src="https://img.shields.io/badge/Platform-Windows_%7C_macOS_%7C_Linux-0078D6.svg?style=for-the-badge&logo=windows&logoColor=white" alt="Platform">
  <img src="https://img.shields.io/badge/Version-1.5.0-orange.svg?style=for-the-badge" alt="Version">
</p>

<p align="center"><a href="#inicio-rapido">🚀 Inicio Rápido</a> • <a href="#caracteristicas">💡 Características</a> • <a href="#configuracion">📖 Configuración</a> • <a href="https://jatechvn.github.io/">🌐 Sitio Web</a></p>

<p align="center"><a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="README.zh-CN.md">🇨🇳 中文</a> • <a href="README.ja-JP.md">🇯🇵 日本語</a> • 🇪🇸 Español • <a href="README.fr.md">🇫🇷 Français</a> • <a href="README.de.md">🇩🇪 Deutsch</a> • <a href="README.ru.md">🇷🇺 Русский</a> • <a href="README.pt.md">🇵🇹 Português</a> • <a href="README.ko.md">🇰🇷 한국어</a></p>

---

<a id="introduccion"></a>
## 🌟 Introducción

**JA Auto Git** es una herramienta GUI profesional que simplifica la configuración del control de versiones y el almacenamiento remoto en GitHub para múltiples subproyectos de forma simultánea. Diseñada para desarrolladores que gestionan múltiples mini-proyectos (scripts de Python, paquetes de Node.js, scripts de AutoHotkey, aplicaciones .NET), automatiza la estandarización de directorios y la publicación de repositorios privados en GitHub con unos pocos clics.

Con su estilo de diseño **Liquid Glass** y los controles de ventana inspirados en macOS, la interfaz ofrece una experiencia moderna e intuitiva que maximiza la productividad del desarrollador en Windows, macOS y Linux.

## 📸 Capturas de Pantalla

<p align="center">
  <img src="../assets/images/screenshot_dark.png" alt="JA Auto Git Tema Oscuro" width="48%">
  <img src="../assets/images/screenshot_light.png" alt="JA Auto Git Tema Claro" width="48%">
</p>

---

<a id="flujo-de-trabajo"></a>
## 📊 Flujo de Trabajo

```mermaid
graph TD
    A[Launch JA Auto Git] --> B[Scan working directory up to max depth]
    B --> C[Analyze & detect project types + versions]
    C --> D{Check project status}
    D -->|Missing .git / gitignore / README / LICENSE| E[Show warning in UI tree]
    D -->|Standard files present| F[Show Standard OK status]
    E --> G[User selects projects → CREATE / EDIT GIT FORM]
    G --> H[Init Git · create .gitignore · write LICENSE · generate 10-lang READMEs]
    H --> I[User types Commit Message or leaves blank for auto-message]
    I --> J[Auto-generate subject + structured Change Log from staged diff]
    J --> K[Auto-create Private Repo on GitHub if missing · Push via GitHub CLI]
    K --> L[Update status · Auto-sync Cloud tab]
    L --> M{GitHub Cloud tab}
    M --> N[View per-repo Commit History · Download any commit ZIP]
    M --> O[View GitHub Releases · Download release assets to ~/Downloads]
    K --> P[Push GitHub Release with tag + assets via Release Manager]
```

---

<a id="caracteristicas"></a>
## ✨ Características Principales

### 1. 🔍 Scanner Dinámico de Proyectos
- **Detección Automática de Stack Tecnológico**: Analiza las firmas de archivos para identificar el tipo de proyecto (Python, Node.js, AHK, .NET, Batch/PowerShell).
- **Escaneo Recursivo**: Escanea directorios hasta una profundidad configurada, ignorando automáticamente directorios grandes del sistema/dependencias como `node_modules`, `.venv`, `__pycache__`, `dist`.
- **Procesamiento Paralelo Multi-núcleo**: Las operaciones de escaneo aprovechan el multi-threading para utilizar todos los núcleos de CPU disponibles simultáneamente, manteniendo la interfaz completamente responsiva.
- **Detección Automática de Versión**: Detecta automáticamente la versión de cada proyecto desde `package.json`, `pyproject.toml`, `setup.cfg`, `setup.py`, `*.csproj`, `constants.py`/`version.py`, `ABOUT.txt`, o la última etiqueta de Git — mostrada en la columna **Versión**.

### 2. 🛡️ Estructura Estándar de Proyecto (Git Form)
- **Seguridad Absoluta**: Configura automáticamente archivos `.gitignore` específicos por lenguaje, ignorando credenciales y claves de licencia (p. ej. `license.key`) de forma predeterminada.
- **Generador de Documentos Multi-idioma**: Crea automáticamente un `README.md` raíz (en inglés) y **9 versiones en idiomas populares** en `i18n/` con barras de navegación enlazadas.
- **Generador de Licencia MIT**: Genera un archivo `LICENSE` estándar de forma dinámica utilizando el año actual y el nombre del autor configurado (personalizable a través de la UI / `config.ini`).
- **Utilidad de Push**: Incluye un script `git_push.bat` / `git_push.sh` en cada subproyecto para push manual rápido.

### 3. 📝 Motor de Auto-Changelog Inteligente
- **Generación Automática de Asunto**: Deje el mensaje de commit en blanco (o con el marcador de posición) y la aplicación genera automáticamente una línea de asunto descriptiva como `"Update main.py, utils.py and 3 other files"` analizando el diff preparado.
- **Cuerpo de Change Log Estructurado**: Cada commit añade automáticamente una sección `Change Log:` que lista todos los archivos modificados, añadidos y eliminados con su estado (`M`, `A`, `D`, `R`).
- **Migración Legada**: Los ajustes existentes que usan el antiguo mensaje predeterminado `"Update project"` se migran silenciosamente al nuevo flujo de trabajo de commit vacío/automático.

Ejemplo de mensaje de commit generado automáticamente:
```
Update main.py, config.ini and 2 other files

Change Log:
  M  modules/git_actions.py
  M  modules/ui/main_window.py
  A  modules/ui/dialogs.py
  D  temp_debug.txt
```

### 4. 🚀 Gestor de Releases — Publicar GitHub Releases *(Nuevo en v1.5.0)*
- **Release con Un Clic**: Cada fila de proyecto con Git + remoto configurado muestra un botón **🚀 Release** en la pestaña de Espacio de Trabajo Local.
- **Generación Automática de Etiqueta**: El Gestor de Releases rellena automáticamente el nombre de la etiqueta desde la versión detectada del proyecto (p. ej. `v1.5.0`).
- **Adjuntar Assets**: Adjunte cualquier archivo de compilación (`.exe`, `.zip`, `.whl`, etc.) al release con un selector de archivos.
- **Push en Segundo Plano**: La creación del release se ejecuta en un hilo en segundo plano mediante `gh release create`, manteniendo la UI responsiva.
- **Estado en Tiempo Real**: Los estados del botón se actualizan en vivo: `⏳ Pushing...` → `✅ Released` al tener éxito, con tooltip de error en caso de fallo.

### 5. ☁️ Pestaña GitHub Cloud — Commits y Releases *(Actualizado en v1.5.0)*

#### 🕐 Historial de Commits y Descarga
- **Historial de Commits por Repositorio**: Cada fila de proyecto muestra un botón **🕐 Commits** que abre un diálogo completo del historial de commits.
- **Diálogo de Historial de Commits**: Diálogo sin marco estilo macOS que muestra SHA · Insignia Tag/Versión · Autor · Fecha · Asunto (al pasar el cursor se muestra el mensaje completo).
- **Descarga ZIP por Commit**: Cada fila de commit tiene un botón **⬇ sha** que:
  1. Descarga el ZIP de la instantánea directamente a `~/Downloads/{repo}_{sha7}.zip` mediante GitHub CLI.
  2. Tras la descarga, abre el **Explorador con el archivo resaltado** (`explorer /select,file`).
  3. Omite la re-descarga si el archivo ya existe localmente.
  4. Estados del botón en tiempo real: `⏳ Downloading...` → `✅ sha7` al tener éxito.

#### 📦 Navegador de Releases y Descarga *(Nuevo en v1.5.0)*
- **Lista de Releases por Repositorio**: Cada fila de proyecto muestra un botón **📦 Releases** que abre un diálogo dedicado del Navegador de Releases.
- **Diálogo del Navegador de Releases**: Diálogo sin marco estilo macOS que lista todos los GitHub Releases con:
  - Tag / Nombre · Fecha · Tipo (Estable / Pre-release / Borrador) · Cantidad de assets
- **Descarga por Asset**: Cada fila de release muestra botones de descarga para cada asset adjunto (hasta 3 visibles):
  - Descarga directamente a `~/Downloads/` mediante `urllib`.
  - Recurre a la descarga del **ZIP de origen** si no hay assets adjuntos.
  - Abre el Explorador con el archivo resaltado tras la descarga.
  - Estados del botón en tiempo real: `⏳` → `✅ Done` al tener éxito, `⬇ Retry` en caso de fallo.
- **Actualizaciones de UI Thread-safe**: Todas las operaciones de descarga utilizan emisión Qt `Signal` desde hilos de trabajo.

### 6. 🎨 Interfaz Liquid Glass — Diseño y Controles
- **Proporciones de Panel Optimizadas**: El Árbol de Estado Git del Proyecto ocupa **4/6** de la altura del panel derecho; la Consola Git en Vivo ocupa **2/6** — dando al árbol un área de visualización significativamente mayor.
- **Encabezado de Consola Unificado**: La etiqueta "LIVE GIT CONSOLE" y el botón "Clear Console" ahora comparten una sola fila de barra de herramientas.
- **Controles de Ventana Estilo macOS**: Todos los diálogos presentan botones semáforo rojo/verde (🔴 Cerrar, 🟢 Maximizar/Restaurar), diseño sin marco con esquinas redondeadas y soporte de arrastre para mover.
- **Filtrado de Estado**: Botones de filtrado (`Has .git`, `No .git`, `Missing Form`, `Not Cloned`, `Behind Cloud`) para selección rápida.
- **Ocultación de Proyectos (Interruptor de Ojo)**: Oculte proyectos no deseados del árbol y la barra lateral con persistencia en `config.ini`.
- **Consola en Vivo**: Muestra la salida en tiempo real de todas las operaciones Git en segundo plano.
- **Columnas de Botones de Ancho Fijo**: Las columnas de Commits y Releases usan el modo `QHeaderView.Fixed` — nunca se estiran cuando se redimensiona o maximiza la ventana.

### 7. ⚙️ Motor Híbrido Multiplataforma
- **Enrutamiento Dinámico del SO**: Detecta el SO anfitrión en tiempo de ejecución (Windows, macOS, Linux) y enruta las operaciones del sistema a componentes optimizados nativos de la plataforma a través de `native_bridge.py`.
  - **Windows**: Win32 API / PowerShell / DLL C++ opcional (`modules/native/win_core.py`)
  - **macOS**: Objective-C / AppleScript / `.dylib` opcional (`modules/native/mac_core.py`)
  - **Linux**: Bash / biblioteca compartida `.so` opcional (`modules/native/linux_core.py`)
- **Fallback de Ejecución Seguro**: Recurre automáticamente a Python puro si los componentes nativos están ausentes — cero fallos, máxima compatibilidad.
- **Scripts de Inicio Multiplataforma**: Se proporcionan `run.bat` / `run.sh` y `setup_venv.sh` para Windows y sistemas de la familia Unix.

```
modules/
├── ui/                        # PySide6 GUI layer
├── native/                    # Hybrid Engine Core
│   ├── win_core.py            # Windows: Win32 API, DLL, PowerShell
│   ├── mac_core.py            # macOS: Objective-C, dylib, AppleScript
│   └── linux_core.py          # Linux: Bash, .so shared library
├── native_bridge.py           # Dynamic OS router (singleton)
├── git_actions.py             # Git operations + auto-changelog
├── github_ops.py              # GitHub CLI + commit/release API
├── project_scan.py            # Project scanner + version detector
├── project_model.py           # ProjectInfo dataclass
├── git_runner.py              # Background thread runner
├── constants.py               # App-wide constants (APP_VERSION)
└── utils.py / i18n_ui.py      # Settings + 10-language translations
```

### 8. 🔄 Sincronización Cloud Automática y Persistencia de Selección
- **Obtención Automática de Cloud al Inicio**: Recupera los estados de los repositorios cloud de GitHub en segundo plano tras el escaneo local.
- **Persistencia de Selección**: Recuerda los estados de las casillas de verificación entre ejecuciones mediante `config.ini`.
- **Vista de Multi-commit por Repositorio**: Historial completo de commits (hasta 30 commits, con anotaciones de etiquetas) bajo demanda.

### 9. 👤 Configuración Automática de Identidad Git
- **Commit Sin Configuración**: Detecta la ausencia de `user.name` / `user.email` de Git y los configura automáticamente desde el perfil de GitHub mediante `gh`.

---

<a id="configuracion"></a>
## 🚀 Instalación y Configuración

### Requisitos del Sistema

| Componente | Versión Mínima | Notas |
|---|---|---|
| Python | 3.13 | Asegúrese de marcar "Add Python to PATH" |
| GitHub CLI (`gh`) | 2.92.0 | Autentíquese con `gh auth login` |
| Git Credential Manager | 2.8.0 | Autenticación segura de push |

> ⚠️ **Importante**: Si una variable de entorno del sistema `GITHUB_TOKEN` está configurada con un valor caducado o inválido, la aplicación la elimina automáticamente antes de llamar a `gh api` para prevenir fallos de autenticación.

<a id="inicio-rapido"></a>
### Instalación Paso a Paso

#### Paso 1: Instalar prerequisitos

1. **Python 3.13+** — [Descargar (oficial)](https://www.python.org/downloads/)
2. **GitHub CLI 2.92.0** — evite vulnerabilidades de inyección en terminal en versiones anteriores:
   - [Descargar gh_2.92.0_windows_amd64.msi](https://github.com/cli/cli/releases/download/v2.92.0/gh_2.92.0_windows_amd64.msi)
3. **Git Credential Manager 2.8.0**:
   - [Descargar gcm-win-x64-2.8.0.exe](https://github.com/git-ecosystem/git-credential-manager/releases/download/v2.8.0/gcm-win-x64-2.8.0.exe)

#### Paso 2: Clonar el repositorio
```cmd
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY
```

#### Paso 3: Instalar dependencias de Python
```cmd
pip install -r requirements.txt
```

#### Paso 4: Autenticar GitHub CLI
```cmd
gh auth login
```
*(Seleccione autenticación por navegador o SSH según su preferencia.)*

#### Paso 5: Lanzar la aplicación

**Windows:**
```cmd
run.bat
```
**macOS / Linux:**
```bash
chmod +x run.sh && ./run.sh
```

---

<a id="config"></a>
## ⚙️ Configuración

### `config.ini` — Configuración Principal
```ini
[settings]
root_dir       = D:\Workspaces\MyProjects   ; Directorio raíz a escanear
remote_base    = github.com/username         ; Su nombre de usuario de GitHub
branch         = main                        ; Rama predeterminada
commit_message =                             ; Vacío = generar asunto y changelog automáticamente
max_depth      = 3                           ; Profundidad máxima de escaneo
auto_create_repo = yes                       ; Crear repo de GitHub automáticamente si falta
```

> 💡 **Consejo**: Deje `commit_message` vacío para activar el modo **Auto-Changelog**. La aplicación generará automáticamente un asunto descriptivo y el cuerpo completo de `Change Log:` a partir del diff preparado.

### `config.json` — Configuración Avanzada de Sincronización
```json
{
  "git": {
    "default_branch": "main",
    "default_commit_message": "",
    "auto_create_github_repo": true
  }
}
```

---

## 🗂️ Estructura del Proyecto

```
JA_AUTO_GIT/
├── main.py                    # Punto de entrada
├── run.bat / run.sh           # Scripts de inicio rápido (Windows / Unix)
├── setup_venv.sh              # Configuración del entorno virtual (Unix)
├── requirements.txt
├── config.ini                 # Configuración del usuario
├── config.json                # Configuración avanzada
├── assets/                    # Iconos e imágenes
├── i18n/                      # READMEs localizados (9 idiomas)
├── logs/                      # Registros de ejecución
└── modules/
    ├── ui/
    │   ├── main_window.py     # Ventana principal de la aplicación
    │   ├── dialogs.py         # Todos los diálogos (Commit, Release, Cloud Release)
    │   └── styles.py          # Hoja de estilos Liquid Glass
    ├── native/                # Motor Híbrido Multiplataforma
    │   ├── win_core.py
    │   ├── mac_core.py
    │   └── linux_core.py
    ├── native_bridge.py       # Enrutador de SO (singleton)
    ├── git_actions.py         # Operaciones Git + auto-changelog
    ├── github_ops.py          # GitHub CLI + API de commits/releases
    ├── project_scan.py        # Scanner de proyectos + detector de versiones
    ├── project_model.py       # Dataclass ProjectInfo
    ├── git_runner.py          # Ejecutor de hilos en segundo plano
    ├── constants.py           # Constantes de la aplicación (APP_VERSION = "1.5.0")
    └── utils.py               # Carga/guardado de configuración + migraciones
```

---

## 📋 Historial de Cambios

### v1.5.0 *(Última)*
- ✨ **Gestor de Releases**: Publique GitHub Releases con etiqueta + assets desde la pestaña de Espacio de Trabajo Local
- ✨ **Navegador de Releases**: Visualice y descargue GitHub Releases (con assets) desde la pestaña Cloud
- ✨ **Columna de Versión**: Detecta automáticamente la versión del proyecto desde archivos de paquete o etiquetas git
- 🔧 **Columnas de botones de ancho fijo**: Las columnas de Commits y Releases ya no se estiran al redimensionar la ventana
- 🔧 **QHeaderView.Fixed**: Aplicado a todas las columnas de botones en ambas pestañas del espacio de trabajo

### v1.4.0
- ✨ **Diálogo de Historial de Commits**: Historial de commits por repositorio con descarga ZIP por commit
- ✨ **Motor de Auto-Changelog**: Genera automáticamente el asunto del commit + cuerpo del Change Log
- 🔧 **Descargas thread-safe**: Actualizaciones de UI entre hilos mediante Qt Signal/Slot

### v1.3.0
- ✨ **Motor Híbrido Multiplataforma**: Puente nativo para Windows/macOS/Linux
- ✨ **Ocultación de Proyectos**: Interruptor de ojo con persistencia en configuración
- 🔧 **Controles de ventana estilo macOS**: Todos los diálogos unificados

---

<a id="licencia"></a>
## 📜 Licencia y Derechos de Autor

Este proyecto se distribuye bajo la **Licencia MIT**. Consulte el archivo [LICENSE](LICENSE) para más detalles.

Copyright John Alaa @ 2026.
