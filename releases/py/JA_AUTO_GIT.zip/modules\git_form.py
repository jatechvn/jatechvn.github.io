import os

from .constants import DEFAULT_BRANCH, GIT_PUSH_BAT, REQUIRED_GITIGNORE_LINES, LICENSE_TEMPLATE, generate_readme_content
from .git_process import log, run_git


def fix_project_git_form(project_dir, log_callback=None):
    project_dir = os.path.abspath(project_dir)
    if not os.path.isdir(project_dir):
        raise FileNotFoundError(project_dir)

    if not os.path.isdir(os.path.join(project_dir, ".git")):
        run_git(project_dir, ["init"], log_callback)
        log(log_callback, "[OK] Created .git repository.\n")

    run_git(project_dir, ["branch", "-M", DEFAULT_BRANCH], log_callback, allow_fail=True)
    ensure_gitignore(project_dir)
    ensure_git_push_bat(project_dir, log_callback)
    ensure_license(project_dir, log_callback)
    ensure_readme(project_dir, log_callback)
    ensure_about_txt(project_dir, log_callback)
    log(log_callback, "[OK] Git form is ready: .git, main branch, .gitignore, git_push.bat, LICENSE, README.md, ABOUT.txt.\n")
    return True


def gitignore_is_standard(project_dir):
    path = os.path.join(project_dir, ".gitignore")
    if not os.path.isfile(path):
        return False
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as file:
            content = {line.strip() for line in file if line.strip()}
    except OSError:
        return False
    required = {line for line in REQUIRED_GITIGNORE_LINES if line and not line.startswith("#")}
    return required.issubset(content)


def ensure_gitignore(project_dir):
    path = os.path.join(project_dir, ".gitignore")
    existing = []
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8", errors="ignore") as file:
            existing = file.read().splitlines()

    existing_set = {line.strip() for line in existing if line.strip()}
    merged = list(existing)
    if merged and merged[-1].strip():
        merged.append("")

    for line in REQUIRED_GITIGNORE_LINES:
        if line and not line.startswith("#") and line in existing_set:
            continue
        merged.append(line)

    with open(path, "w", encoding="utf-8", newline="\n") as file:
        file.write("\n".join(merged).rstrip() + "\n")


def ensure_git_push_bat(project_dir, log_callback=None):
    path = os.path.join(project_dir, "git_push.bat")
    with open(path, "w", encoding="utf-8", newline="\r\n") as file:
        file.write(GIT_PUSH_BAT)
    log(log_callback, "[OK] Created/Updated git_push.bat.\n")


def ensure_license(project_dir, log_callback=None):
    import datetime
    from .utils import load_settings
    settings = load_settings()
    author = settings.get("license_author", "John Alaa")
    year = datetime.date.today().year

    path = os.path.join(project_dir, "LICENSE")
    with open(path, "w", encoding="utf-8", newline="\n") as file:
        file.write(LICENSE_TEMPLATE.format(year=year, author=author))
    log(log_callback, f"[OK] Created/Updated LICENSE file (Author: {author}).\n")


def ensure_readme(project_dir, log_callback=None):
    path = os.path.join(project_dir, "README.md")
    files = os.listdir(project_dir)
    from .project_scan import detect_project_kind
    kind = detect_project_kind(project_dir, files)
    project_name = os.path.basename(project_dir)

    # Resolve project repository URL
    from .utils import load_settings, repo_url_for_project, repo_name_for_project
    settings = load_settings()
    repo_name = repo_name_for_project(project_dir)
    repo_url = repo_url_for_project(settings.get("remote_base"), repo_name)
    if not repo_url:
        repo_url = f"https://github.com/JohnAlaa/{repo_name}"

    # 1. Always update/create main README.md in English
    content = generate_readme_content(project_name, kind, "en", repo_url)
    with open(path, "w", encoding="utf-8", newline="\n") as file:
        file.write(content)
    log(log_callback, "[OK] Created/Updated main README.md (English).\n")

    # 2. Always update/create i18n/ directory and translations
    i18n_dir = os.path.join(project_dir, "i18n")
    if not os.path.exists(i18n_dir):
        os.makedirs(i18n_dir)

    languages = ["vi", "zh-CN", "ja-JP", "es", "fr", "de", "ru", "pt", "ko"]
    for lang in languages:
        lang_path = os.path.join(i18n_dir, f"README.{lang}.md")
        content = generate_readme_content(project_name, kind, lang, repo_url)
        with open(lang_path, "w", encoding="utf-8", newline="\n") as file:
            file.write(content)

    log(log_callback, "[OK] Created/Updated translated READMEs in i18n/.\n")


def ensure_about_txt(project_dir, log_callback=None):
    path = os.path.join(project_dir, "ABOUT.txt")
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as file:
                if file.read().strip():
                    return
        except OSError:
            pass

    from .project_scan import detect_project_kind
    files = os.listdir(project_dir)
    kind = detect_project_kind(project_dir, files)
    project_name = os.path.basename(project_dir)

    if kind == "python":
        tech_stack = "Python 3.13 / PySide6"
        description = "A high-performance Python application designed with modular architecture for robust operations."
    elif kind == "node":
        tech_stack = "Node.js / JavaScript"
        description = "A modern Node.js application built for scale and efficiency using JavaScript/TypeScript."
    elif kind == "ahk":
        tech_stack = "AutoHotkey (AHK)"
        description = "An efficient automation script developed in AutoHotkey to streamline Windows workflows."
    elif kind == "dotnet":
        tech_stack = ".NET / C#"
        description = "A robust C#/.NET application engineered for reliability and high performance."
    else:
        tech_stack = "General / Polyglot"
        description = "A structured project configuration optimized for automated CI/CD and Git workflows."

    card = f"""========================================================================
                       PROJECT INFORMATION CARD
========================================================================
Project Name : {project_name}
Tech Stack   : {tech_stack}
Managed By   : JA Auto Git
Website      : https://jatechvn.github.io/
------------------------------------------------------------------------
Description  : {description}
========================================================================
"""

    with open(path, "w", encoding="utf-8", newline="\n") as file:
        file.write(card)
    log(log_callback, "[OK] Created/Updated ABOUT.txt.\n")

