# 🤖 JA Auto Git — Liquid Glass Edition

<p align="center">
  <img src="../assets/images/icon.ico" alt="JA Auto Git Logo" width="120" height="120">
  <br>
  <i>開発者向け自動Git管理とスマートなGitHubリポジトリ作成ツール。</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=for-the-badge&logo=python&logoColor=white" alt="Python Version">
  <img src="https://img.shields.io/badge/GUI-PySide6-green.svg?style=for-the-badge&logo=qt&logoColor=white" alt="UI Framework">
  <img src="https://img.shields.io/badge/Integrations-GitHub_CLI-purple.svg?style=for-the-badge&logo=github&logoColor=white" alt="Integrations">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge" alt="License">
  <img src="https://img.shields.io/badge/Platform-Windows_%7C_macOS_%7C_Linux-0078D6.svg?style=for-the-badge&logo=windows&logoColor=white" alt="Platform">
  <img src="https://img.shields.io/badge/Version-1.5.0-orange.svg?style=for-the-badge" alt="Version">
</p>

<p align="center"><a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="README.zh-CN.md">🇨🇳 中文</a> • 🇯🇵 日本語 • <a href="README.es.md">🇪🇸 Español</a> • <a href="README.fr.md">🇫🇷 Français</a> • <a href="README.de.md">🇩🇪 Deutsch</a> • <a href="README.ru.md">🇷🇺 Русский</a> • <a href="README.pt.md">🇵🇹 Português</a> • <a href="README.ko.md">🇰🇷 한국어</a></p>

---

## 📋 目次

- [概要](#-概要)
- [機能](#-機能)
- [スクリーンショット](#-スクリーンショット)
- [必要環境](#-必要環境)
- [インストール](#-インストール)
- [使い方](#-使い方)
- [プロジェクト構成](#-プロジェクト構成)
- [変更履歴](#-変更履歴)
- [ライセンス](#-ライセンス)

---

## 🌟 概要

**JA Auto Git — Liquid Glass Edition** は、Git操作とGitHubリポジトリ管理を自動化するために設計された、洗練されたデスクトップアプリケーションです。美しいLiquid GlassテーマのUIと強力なバックエンドロジックを組み合わせ、コミット、プッシュ、リリース管理、リポジトリ作成などの繰り返し作業を簡素化します。

---

## ✨ 機能

### 1. 🔍 ダイナミックプロジェクトスキャナー（自動バージョン検出付き）

設定したルートディレクトリを自動的にスキャンし、Gitプロジェクトを検出します。

- 複数のルートディレクトリを自動でスキャン
- **バージョン列**を新規追加 — 各プロジェクトの現在のバージョン番号をリアルタイムで表示
- `setup.py`、`pyproject.toml`、`package.json`、`version.txt` などのバージョンソースファイルを自動検出
- プロジェクトのステータス（クリーン・変更あり・未追跡）を色分けして表示
- プロジェクト一覧から特定のプロジェクトを非表示にする機能をサポート

### 2. 📁 標準化されたプロジェクト構成

新しいプロジェクトを、最初から業界標準のフォルダ構成で自動生成します。

- `src/`、`tests/`、`docs/`、`assets/` などの標準ディレクトリを自動作成
- `.gitignore`、`README.md`、`LICENSE` などの必須ファイルをテンプレートから生成
- GitHub上でリポジトリをすぐに公開できる状態に初期化

### 3. 📝 スマート自動変更履歴コミットエンジン

コミットメッセージを自動で生成・管理する、インテリジェントなエンジンです。

- 変更されたファイルを解析し、意味のあるコミットメッセージを自動生成
- コミット履歴ダイアログで過去のすべてのコミットを閲覧・管理
- コミット種別（`feat`、`fix`、`docs`、`refactor` など）を自動タグ付け
- `CHANGELOG.md` を自動生成・更新し、リリースノートとして活用可能

### 4. 🚀 リリースマネージャー（v1.5.0 新機能）

プロジェクトのリリースを、ワンクリックで作成・管理できる新機能です。

- バージョン番号を自動インクリメントし、Gitタグを付与
- GitHub Releases を自動作成（リリースノート付き）
- セマンティックバージョニング（`v1.0.0`、`v1.5.0` など）に対応
- ドラフトリリースとプレリリースの両方をサポート
- リリース前にリリースノートをプレビュー・編集可能

### 5. ☁️ GitHub クラウドタブ — コミット & リリース（v1.5.0 更新）

GitHubのコミット履歴とリリース情報をアプリ内で直接確認できます。

- 選択したリポジトリの最新コミット履歴をリアルタイムで表示
- **リリースブラウザ**を新規追加 — GitHub上の全リリースをタイムライン形式で表示
- リリースのダウンロード数・公開日・タグ名を一覧表示
- コミット・リリース詳細をクリック一つでブラウザに展開
- **固定幅カラム**レイアウトで、長いテキストも見やすく整列表示

### 6. 🪟 Liquid Glass UI

モダンで透明感のある「Liquid Glass」デザインを採用した、美しいユーザーインターフェースです。

- ガラス質感のパネル・ボタン・ウィジェットで構成されたUI
- ライト / ダークモードを自動切替（システム設定に連動）
- スムーズなアニメーションとホバーエフェクトを搭載
- PySide6（Qt6）ベースの高品質レンダリング
- 高DPIディスプレイ（Retina / 4K）に完全対応

### 7. 🖥️ クロスプラットフォームハイブリッドエンジン

Windows・macOS・Linux すべてで動作する、適応型バックエンドエンジンです。

- プラットフォームごとに最適なGit実行方式を自動選択
- Windowsでは `subprocess` + PowerShell、Unix系では `subprocess` + bash を使用
- GitHub CLI（`gh`）コマンドとのシームレスな統合
- 各OSのファイルシステム・パス区切り文字に自動対応

### 8. 🔄 自動クラウド同期

ローカルの変更を、設定した間隔で自動的にGitHubへプッシュします。

- バックグラウンドで定期的に変更を検出し、自動コミット＆プッシュ
- 同期間隔は自由に設定可能（分単位）
- 同期ログをリアルタイムでUIに表示
- コンフリクト発生時は自動で通知し、手動解決をサポート

### 9. 👤 Git IDの自動設定

初回セットアップ時に、Gitのユーザー情報を自動で構成します。

- `git config --global user.name` と `git config --global user.email` を自動設定
- GitHub CLIの認証状態を確認し、未認証の場合はガイドを表示
- `.gitconfig` が存在しない場合は自動生成

---

## 📸 スクリーンショット

<p align="center">
  <img src="../assets/images/screenshot_main.png" alt="メイン画面" width="700">
  <br>
  <i>メイン画面 — プロジェクト一覧とバージョン列</i>
</p>

<p align="center">
  <img src="../assets/images/screenshot_cloud.png" alt="クラウドタブ" width="700">
  <br>
  <i>GitHubクラウドタブ — コミット & リリースブラウザ</i>
</p>

---

## 💻 必要環境

| 項目 | 要件 |
|---|---|
| OS | Windows 10/11、macOS 12+、Ubuntu 20.04+ |
| Python | 3.13 以上 |
| Git | 2.30 以上 |
| GitHub CLI | 2.0 以上（`gh`） |
| インターネット接続 | GitHub機能の使用時に必要 |

---

## 🚀 インストール

### 方法 1：リポジトリをクローン

```bash
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY
```

### 方法 2：依存パッケージのインストール

```bash
pip install -r requirements.txt
```

### 方法 3：アプリを起動

```bash
python main.py
```

> [!TIP]
> GitHub機能を使用するには、事前に `gh auth login` を実行してGitHub CLIにログインしてください。

---

## 📖 使い方

### 基本的なワークフロー

1. **プロジェクトルートを追加** — 設定画面からスキャン対象のディレクトリを指定します。
2. **プロジェクトを選択** — 左側のプロジェクト一覧から対象を選択します。
3. **変更を確認** — 変更されたファイルと自動生成されたコミットメッセージを確認します。
4. **コミット & プッシュ** — ボタン一つで変更をGitHubにプッシュします。

### リリースの作成

1. プロジェクトを選択し、**「リリースマネージャー」タブ**を開きます。
2. バージョン番号を入力するか、自動インクリメントを使用します。
3. リリースノートを編集します（自動生成も可能）。
4. **「リリースを作成」**ボタンをクリックします。

### 自動同期の設定

```python
# config.py 内の同期間隔設定（分単位）
AUTO_SYNC_INTERVAL_MINUTES = 30
```

> [!NOTE]
> 自動同期はバックグラウンドで動作し、アプリを最小化してもプッシュを継続します。

---

## 📁 プロジェクト構成

```
JA_AUTO_GIT_PY/
├── main.py                  # アプリケーションエントリポイント
├── requirements.txt         # Python依存パッケージ一覧
├── config.py                # アプリ設定ファイル
├── src/
│   ├── ui/                  # UIコンポーネント（PySide6）
│   ├── git_engine/          # Gitオペレーションエンジン
│   ├── github_api/          # GitHub CLI & API連携
│   ├── release_manager/     # リリース管理モジュール
│   └── utils/               # ユーティリティ関数群
├── assets/
│   └── images/              # アイコン・スクリーンショット
├── i18n/                    # 多言語対応READMEファイル
├── tests/                   # テストスイート
└── docs/                    # ドキュメント
```

---

## 📦 変更履歴

### v1.5.0 — リリースマネージャー & クラウドUI強化
> 🗓️ 2026年5月

- ✅ **リリースマネージャー**を新規追加 — ワンクリックでGitHub Releasesを作成・管理
- ✅ **リリースブラウザ**を新規追加 — GitHubクラウドタブ内で全リリースをタイムライン表示
- ✅ **バージョン列**をプロジェクト一覧に追加 — 各プロジェクトのバージョンをリアルタイム表示
- ✅ **固定幅カラム**レイアウトを導入 — 長いテキストも整然と表示
- 🐛 クラウドタブのコミット履歴が正しく更新されない問題を修正

### v1.4.0 — コミット履歴 & 自動変更履歴エンジン
> 🗓️ 2025年12月

- ✅ **コミット履歴ダイアログ**を追加 — 過去のコミットを一覧で閲覧・検索可能
- ✅ **自動変更履歴コミットエンジン**を実装 — `CHANGELOG.md` を自動生成・更新
- ✅ コミット種別タグ（`feat`、`fix`、`docs` など）の自動付与

### v1.3.0 — クロスプラットフォーム対応 & プロジェクト非表示機能
> 🗓️ 2025年8月

- ✅ **クロスプラットフォームハイブリッドエンジン**を導入 — Windows・macOS・Linuxに対応
- ✅ **プロジェクト非表示機能**を追加 — 一覧に表示したくないプロジェクトを個別に非表示化
- ✅ macOS・Linux環境での安定性を大幅に向上

---

## 📄 ライセンス

このプロジェクトは [MIT ライセンス](../LICENSE) のもとで公開されています。

---

<p align="center">
  Copyright &copy; 2026 <strong>John Alaa</strong>. All rights reserved.<br>
  ❤️ 開発者コミュニティへの愛を込めて制作しました。
</p>
