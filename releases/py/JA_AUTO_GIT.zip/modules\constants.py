# Global constants for JA Auto Git

APP_ID = "JA_AUTO_GIT"
APP_NAME = "JA Auto Git"
APP_VERSION = "1.5.0"
APP_USER_MODEL_ID = "JohnAlaa.JAAutoGit.1.0"
APP_TITLE = "JA AUTO GIT - LIQUID GLASS"

DEFAULT_WIDTH = 1220
DEFAULT_HEIGHT = 780

FONT_PRIMARY = "Inter"
FONT_MONO = "Consolas"

ACCENT_CYAN = "#00d4ff"
ACCENT_GREEN = "#00ff9d"
ACCENT_PURPLE = "#b026ff"
COLOR_CLOSE_NORMAL = "#ff5f56"
COLOR_CLOSE_BORDER = "#e0443e"
COLOR_CLOSE_HOVER = "#ff7b72"
COLOR_MIN_NORMAL = "#ffbd2e"
COLOR_MIN_BORDER = "#dea123"
COLOR_MIN_HOVER = "#ffca52"
COLOR_MAX_NORMAL = "#27c93f"
COLOR_MAX_BORDER = "#1aab29"
COLOR_MAX_HOVER = "#38e04f"

DEFAULT_ROOT = r"D:\OS-Software\OneDrive\OpenClaw_Workspace\JA_PROJECT"
DEFAULT_BRANCH = "main"
DEFAULT_COMMIT_MESSAGE = ""

PROJECT_MARKERS = {
    "python": ["main.py", "requirements.txt", "pyproject.toml", "setup.py"],
    "node": ["package.json"],
    "ahk": ["*.ahk"],
    "batch": ["*.bat", "*.cmd"],
    "powershell": ["*.ps1"],
    "dotnet": ["*.sln", "*.csproj"],
}

SKIP_DIRS = {
    ".git",
    ".venv",
    "venv",
    "ENV",
    "__pycache__",
    "node_modules",
    "dist",
    "build",
    "build_pyinstall",
    "build_nuitka",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
}

REQUIRED_GITIGNORE_LINES = [
    "# Virtual environment",
    ".venv/",
    "venv/",
    "ENV/",
    "",
    "# Python cache / compiled files",
    "__pycache__/",
    "*.py[cod]",
    "*$py.class",
    "*.pyd",
    "",
    "# Build output",
    "build/",
    "dist/",
    "build_pyinstall/",
    "build_nuitka/",
    "*.spec",
    "",
    "# Logs and temporary files",
    "logs/*.log",
    "assets/temp/",
    "",
    "# Local IDE / OS files",
    ".vscode/",
    ".idea/",
    ".DS_Store",
    "Thumbs.db",
    "",
    "# Personal config - uncomment if config has password/token/key",
    "# config.ini",
    "# config.json",
    "",
    "# License thật tuyệt đối không commit",
    "license.key",
    "",
    "# Hybrid native libraries",
    "modules/native/*.dll",
    "modules/native/*.so",
    "modules/native/*.dylib",
]

GIT_PUSH_BAT = """@echo off
cd /d %~dp0

set /p remote_url="Nhap GitHub repo URL: "
set /p commit_msg="Nhap commit message: "
if "%commit_msg%"=="" set commit_msg=Update project

if exist "license.key" (
    echo [WARNING] Phat hien license.key. File nay phai nam trong .gitignore va khong duoc commit.
)

if not exist ".git" (
    git init
    git branch -M main
)

git status --short
git add .
git commit -m "%commit_msg%"
git remote remove origin 2>nul
git remote add origin "%remote_url%"
git push -u origin main

pause
"""

LICENSE_TEMPLATE = """MIT License

Copyright (c) {year} {author}

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


README_TRANSLATIONS = {
    "en": {
        "intro_python": "is an application developed in Python.",
        "intro_node": "is a project developed on Node.js.",
        "intro_ahk": "is an automation tool written in AutoHotkey.",
        "intro_dotnet": "is software developed on the .NET platform.",
        "intro_generic": "is a project/automation tool.",
        "intro_desc": "The project is standardized according to professional project structures, supporting efficient source code management via Git.",
        "title_intro": "Introduction",
        "title_features": "Features",
        "feature_1": "Quick setup and professional packaging.",
        "feature_2": "Lightweight configuration, easy to maintain and extend.",
        "feature_3": "Automated Git push workflow with included script.",
        "title_structure": "Directory Structure",
        "struct_main": "Entry point of the application",
        "struct_run": "Quick start script on Windows",
        "struct_req": "Dependencies list",
        "struct_config_ini": "Simple configuration file",
        "struct_config_json": "Structured JSON configuration file",
        "struct_gitignore": "Git ignore patterns",
        "struct_readme": "Project documentation (this file)",
        "struct_license": "License file",
        "struct_about": "Project short description",
        "struct_push_bat": "Auto push script to GitHub",
        "struct_logs": "Application logs",
        "struct_modules": "Core modules containing business logic",
        "struct_assets": "Static assets of the application",
        "title_setup": "Setup & Usage Guide",
        "setup_reqs": "System Requirements",
        "setup_os": "OS: **Windows 10/11**",
        "setup_interpreter_python": "Interpreter: **Python 3.13** or matching environment.",
        "setup_run_title": "How to Run",
        "setup_run_python_install": "Install required dependencies:",
        "setup_run_node_install": "Install required dependencies:",
        "setup_run_dotnet_build": "Build the project using .NET CLI:",
        "setup_run_ahk": "Run the script directly via AutoHotkey:",
        "setup_run_run": "Run the application:",
        "title_license": "License",
        "license_body": "This project is licensed under the **MIT License**. See the [LICENSE](LICENSE) file for details."
    },
    "vi": {
        "intro_python": "là một ứng dụng được phát triển bằng ngôn ngữ Python.",
        "intro_node": "là một dự án phát triển trên nền tảng Node.js.",
        "intro_ahk": "là một công cụ tự động hóa viết bằng AutoHotkey.",
        "intro_dotnet": "là một phần mềm phát triển trên nền tảng .NET.",
        "intro_generic": "là một dự án/công cụ tự động hóa.",
        "intro_desc": "Dự án được thiết lập chuẩn hóa theo khung dự án phát triển chuyên nghiệp, hỗ trợ quản lý mã nguồn hiệu quả qua Git.",
        "title_intro": "Giới Thiệu Chung",
        "title_features": "Tính Năng Nổi Bật",
        "feature_1": "Khởi tạo nhanh chóng và đóng gói chuyên nghiệp.",
        "feature_2": "Cấu hình tinh gọn, dễ bảo trì và phát triển mở rộng.",
        "feature_3": "Tự động hóa quy trình đẩy code lên Git thông qua script đi kèm.",
        "title_structure": "Cấu Trúc Mã Nguồn",
        "struct_main": "Điểm vào chương trình (entry point)",
        "struct_run": "Script khởi động nhanh trên Windows",
        "struct_req": "Danh sách thư viện cần thiết",
        "struct_config_ini": "File cấu hình đơn giản",
        "struct_config_json": "File cấu hình dạng JSON",
        "struct_gitignore": "Các tệp bỏ qua khi commit",
        "struct_readme": "Tài liệu giới thiệu dự án (File này)",
        "struct_license": "Giấy phép sử dụng",
        "struct_about": "Tài liệu mô tả ngắn về dự án",
        "struct_push_bat": "Script đẩy code tự động lên GitHub",
        "struct_logs": "Nhật ký hoạt động của ứng dụng",
        "struct_modules": "Các module xử lý chính",
        "struct_assets": "Tài nguyên tĩnh của ứng dụng",
        "title_setup": "Hướng Dẫn Cài Đặt & Sử Dụng",
        "setup_reqs": "Điều kiện cấu hình hệ thống",
        "setup_os": "Hệ điều hành: **Windows 10/11**",
        "setup_interpreter_python": "Trình thông dịch: **Python 3.13** hoặc môi trường phù hợp.",
        "setup_run_title": "Khởi động ứng dụng",
        "setup_run_python_install": "Cài đặt các thư viện cần thiết:",
        "setup_run_node_install": "Cài đặt các gói phụ thuộc:",
        "setup_run_dotnet_build": "Build dự án bằng .NET CLI:",
        "setup_run_ahk": "Chạy trực tiếp file script bằng AutoHotkey:",
        "setup_run_run": "Khởi chạy ứng dụng:",
        "title_license": "Giấy Phép Sử Dụng",
        "license_body": "Dự án này được cấp phép theo các điều khoản của **MIT License**. Chi tiết xem tại tệp [LICENSE](LICENSE)."
    },
    "zh-cn": {
        "intro_python": "是一个使用 Python 开发的应用程序。",
        "intro_node": "是一个基于 Node.js 平台开发的项目。",
        "intro_ahk": "是一个使用 AutoHotkey 编写的自动化工具。",
        "intro_dotnet": "是一个基于 .NET 平台开发的软件。",
        "intro_generic": "是一个项目或自动化工具。",
        "intro_desc": "项目按照专业的项目结构进行标准化配置，支持通过 Git 进行高效的源代码管理。",
        "title_intro": "项目简介",
        "title_features": "核心特性",
        "feature_1": "快速部署与专业化打包。",
        "feature_2": "轻量化配置，易于维护与扩展。",
        "feature_3": "附带的脚本支持自动推送代码至 Git 仓库。",
        "title_structure": "目录结构",
        "struct_main": "应用程序入口点",
        "struct_run": "Windows 快速启动脚本",
        "struct_req": "所需依赖库列表",
        "struct_config_ini": "简单键值配置文件",
        "struct_config_json": "JSON 结构化配置文件",
        "struct_gitignore": "Git 忽略文件配置",
        "struct_readme": "项目说明文档 (本文件)",
        "struct_license": "开源许可证文件",
        "struct_about": "项目简短描述",
        "struct_push_bat": "自动推送代码至 GitHub 的脚本",
        "struct_logs": "应用程序运行日志",
        "struct_modules": "核心业务逻辑模块",
        "struct_assets": "静态资源目录",
        "title_setup": "安装与使用指南",
        "setup_reqs": "系统环境要求",
        "setup_os": "操作系统: **Windows 10/11**",
        "setup_interpreter_python": "解释器/环境: **Python 3.13** 或匹配环境。",
        "setup_run_title": "如何运行",
        "setup_run_python_install": "安装必要依赖：",
        "setup_run_node_install": "安装包依赖：",
        "setup_run_dotnet_build": "使用 .NET CLI 构建项目：",
        "setup_run_ahk": "直接通过 AutoHotkey 运行脚本：",
        "setup_run_run": "启动应用程序：",
        "title_license": "开源许可证",
        "license_body": "本项目基于 **MIT 许可证** 开源。详情请参阅 [LICENSE](LICENSE) 文件。"
    },
    "ja-jp": {
        "intro_python": "は Python で開発されたアプリケーションです。",
        "intro_node": "は Node.js プラットフォーム上で開発されたプロジェクトです。",
        "intro_ahk": "は AutoHotkey で記述された自動化ツールです。",
        "intro_dotnet": "は .NET プラットフォーム上で開発されたソフトウェアです。",
        "intro_generic": "はプロジェクト/自動化ツールです。",
        "intro_desc": "プロジェクトはプロフェッショナルな設計に従って標準化されており、Git を使用した効率的なソースコード管理をサポートします。",
        "title_intro": "はじめに",
        "title_features": "主な機能",
        "feature_1": "迅速なセットアップとプロフェッショナルなパッケージング。",
        "feature_2": "軽量な構成で、メンテナンスや拡張が容易。",
        "feature_3": "付属スクリプトによる Git 自動プッシュワークフロー。",
        "title_structure": "ディレクトリ構造",
        "struct_main": "アプリケーションのエントリポイント",
        "struct_run": "Windows 用クイックスタートスクリプト",
        "struct_req": "依存パッケージのリスト",
        "struct_config_ini": "シンプルな設定ファイル",
        "struct_config_json": "JSON 形式の設定ファイル",
        "struct_gitignore": "Git 除外設定ファイル",
        "struct_readme": "プロジェクト説明ドキュメント (このファイル)",
        "struct_license": "ライセンスファイル",
        "struct_about": "プロジェクトの概要説明",
        "struct_push_bat": "GitHub への自動プッシュスクリプト",
        "struct_logs": "アプリケーションログ",
        "struct_modules": "コアロジックを含むモジュール",
        "struct_assets": "静的アセット",
        "title_setup": "セットアップと使用方法",
        "setup_reqs": "システム環境要件",
        "setup_os": "OS: **Windows 10/11**",
        "setup_interpreter_python": "実行環境: **Python 3.13** または互換性のある環境。",
        "setup_run_title": "実行方法",
        "setup_run_python_install": "必要な依存関係をインストールします:",
        "setup_run_node_install": "依存パッケージをインストールします:",
        "setup_run_dotnet_build": ".NET CLI を使用してプロジェクトをビルドします:",
        "setup_run_ahk": "AutoHotkey でスクリプトを直接実行します:",
        "setup_run_run": "アプリケーションを起動します:",
        "title_license": "ライセンス",
        "license_body": "このプロジェクトは **MIT ライセンス** の下でライセンスされています。詳細は [LICENSE](LICENSE) ファイルを参照してください。"
    },
    "es": {
        "intro_python": "es una aplicación desarrollada en Python.",
        "intro_node": "es un proyecto desarrollado sobre Node.js.",
        "intro_ahk": "es una herramienta de automatización escrita en AutoHotkey.",
        "intro_dotnet": "es un software desarrollado en la plataforma .NET.",
        "intro_generic": "es un proyecto/herramienta de automatización.",
        "intro_desc": "El proyecto está estandarizado de acuerdo con estructuras de proyectos profesionales, lo que permite una gestión eficiente del código fuente a través de Git.",
        "title_intro": "Introducción",
        "title_features": "Características Clave",
        "feature_1": "Configuración rápida y empaquetado profesional.",
        "feature_2": "Configuración ligera, fácil de mantener y extender.",
        "feature_3": "Flujo de trabajo de envío automático a Git mediante el script incluido.",
        "title_structure": "Estructura de Directorios",
        "struct_main": "Punto de entrada de la aplicación",
        "struct_run": "Script de inicio rápido para Windows",
        "struct_req": "Lista de dependencias",
        "struct_config_ini": "Archivo de configuración simple",
        "struct_config_json": "Archivo de configuración JSON estructurado",
        "struct_gitignore": "Patrones para ignorar en Git",
        "struct_readme": "Documentación del proyecto (este archivo)",
        "struct_license": "Archivo de licencia",
        "struct_about": "Breve descripción del proyecto",
        "struct_push_bat": "Script de envío automático a GitHub",
        "struct_logs": "Archivos de registro de la aplicación",
        "struct_modules": "Módulos principales con la lógica de negocio",
        "struct_assets": "Recursos estáticos de la aplicación",
        "title_setup": "Guía de Instalación y Uso",
        "setup_reqs": "Requisitos del Sistema",
        "setup_os": "Sistema Operativo: **Windows 10/11**",
        "setup_interpreter_python": "Intérprete: **Python 3.13** o entorno equivalente.",
        "setup_run_title": "Cómo Ejecutar",
        "setup_run_python_install": "Instalar dependencias necesarias:",
        "setup_run_node_install": "Instalar dependencias del paquete:",
        "setup_run_dotnet_build": "Compilar el proyecto usando la CLI de .NET:",
        "setup_run_ahk": "Ejecutar el script directamente con AutoHotkey:",
        "setup_run_run": "Ejecutar la aplicación:",
        "title_license": "Licencia",
        "license_body": "Este proyecto está bajo la **Licencia MIT**. Ver el archivo [LICENSE](LICENSE) para más detalles."
    },
    "fr": {
        "intro_python": "est une application développée en Python.",
        "intro_node": "est un projet développé sur Node.js.",
        "intro_ahk": "est un outil d'automatisation écrit en AutoHotkey.",
        "intro_dotnet": "est un logiciel développé sur la plateforme .NET.",
        "intro_generic": "est un projet/outil d'automatisation.",
        "intro_desc": "Le projet est standardisé selon des structures de projet professionnelles, supportant une gestion efficace du code source via Git.",
        "title_intro": "Introduction",
        "title_features": "Caractéristiques Principales",
        "feature_1": "Configuration rapide et packaging professionnel.",
        "feature_2": "Configuration légère, facile à maintenir et à étendre.",
        "feature_3": "Processus d'envoi automatique vers Git grâce au script fourni.",
        "title_structure": "Structure des Répertoires",
        "struct_main": "Point d'entrée de l'application",
        "struct_run": "Script de démarrage rapide sur Windows",
        "struct_req": "Liste des dépendances",
        "struct_config_ini": "Fichier de configuration simple",
        "struct_config_json": "Fichier de configuration JSON",
        "struct_gitignore": "Modèles d'exclusion Git",
        "struct_readme": "Documentation du projet (ce fichier)",
        "struct_license": "Fichier de licence",
        "struct_about": "Brève description du projet",
        "struct_push_bat": "Script d'envoi automatique vers GitHub",
        "struct_logs": "Journaux d'activité de l'application",
        "struct_modules": "Modules principaux contenant la logique métier",
        "struct_assets": "Ressources statiques de l'application",
        "title_setup": "Guide d'Installation et d'Utilisation",
        "setup_reqs": "Configuration Système Requise",
        "setup_os": "Système d'exploitation : **Windows 10/11**",
        "setup_interpreter_python": "Interpréteur : **Python 3.13** ou environnement correspondant.",
        "setup_run_title": "Comment Lancer",
        "setup_run_python_install": "Installer les dépendances requises :",
        "setup_run_node_install": "Installer les dépendances du paquet :",
        "setup_run_dotnet_build": "Compiler le projet avec la CLI .NET :",
        "setup_run_ahk": "Lancer le script directement via AutoHotkey :",
        "setup_run_run": "Lancer l'application :",
        "title_license": "Licence",
        "license_body": "Ce projet est sous **Licence MIT**. Voir le fichier [LICENSE](LICENSE) pour plus de détails."
    },
    "de": {
        "intro_python": "ist eine in Python entwickelte Anwendung.",
        "intro_node": "ist ein auf Node.js entwickeltes Projekt.",
        "intro_ahk": "ist ein in AutoHotkey geschriebenes Automatisierungstool.",
        "intro_dotnet": "ist eine auf der .NET-Plattform entwickelte Software.",
        "intro_generic": "ist ein Projekt/Automatisierungstool.",
        "intro_desc": "Das Projekt ist nach professionellen Projektstrukturen standardisiert und unterstützt eine effiziente Quellcodeverwaltung über Git.",
        "title_intro": "Einführung",
        "title_features": "Hauptmerkmale",
        "feature_1": "Schnelle Einrichtung und professionelle Paketierung.",
        "feature_2": "Leichtgewichtige Konfiguration, einfach zu warten und zu erweitern.",
        "feature_3": "Automatisierter Git-Push-Workflow mit mitgeliefertem Skript.",
        "title_structure": "Verzeichnisstruktur",
        "struct_main": "Haupteinstiegspunkt der Anwendung",
        "struct_run": "Schnellstart-Skript für Windows",
        "struct_req": "Liste der Abhängigkeiten",
        "struct_config_ini": "Einfache Konfigurationsdatei",
        "struct_config_json": "Strukturierte JSON-Konfigurationsdatei",
        "struct_gitignore": "Git-Ausschlussmuster",
        "struct_readme": "Projektdokumentation (diese Datei)",
        "struct_license": "Lizenzdatei",
        "struct_about": "Kurze Projektbeschreibung",
        "struct_push_bat": "Automatisches Push-Skript zu GitHub",
        "struct_logs": "Anwendungsprotokolle",
        "struct_modules": "Kernmodule mit der Geschäftslogik",
        "struct_assets": "Statische Ressourcen der Anwendung",
        "title_setup": "Installations- und Nutzungsanleitung",
        "setup_reqs": "Systemanforderungen",
        "setup_os": "Betriebssystem: **Windows 10/11**",
        "setup_interpreter_python": "Interpreter: **Python 3.13** oder entsprechende Umgebung.",
        "setup_run_title": "Ausführung",
        "setup_run_python_install": "Erforderliche Abhängigkeiten installieren:",
        "setup_run_node_install": "Paketabhängigkeiten installieren:",
        "setup_run_dotnet_build": "Projekt mit .NET CLI erstellen:",
        "setup_run_ahk": "Skript direkt über AutoHotkey ausführen:",
        "setup_run_run": "Anwendung starten:",
        "title_license": "Lizenz",
        "license_body": "Dieses Projekt steht unter der **MIT-Lizenz**. Weitere Details finden Sie in der [LICENSE](LICENSE)-Datei."
    },
    "ru": {
        "intro_python": "— это приложение, разработанное на Python.",
        "intro_node": "— это проект, разработанный на Node.js.",
        "intro_ahk": "— это инструмент автоматизации, написанный на AutoHotkey.",
        "intro_dotnet": "— это программное обеспечение, разработанное на платформе .NET.",
        "intro_generic": "— это проект/инструмент автоматизации.",
        "intro_desc": "Проект стандартизирован в соответствии с профессиональной структурой проекта и поддерживает эффективное управление исходным кодом с помощью Git.",
        "title_intro": "Описание проекта",
        "title_features": "Ключевые возможности",
        "feature_1": "Быстрая настройка и профессиональная упаковка.",
        "feature_2": "Легковесная конфигурация, простота поддержки и расширения.",
        "feature_3": "Автоматизированный процесс отправки изменений в Git с помощью встроенного скрипта.",
        "title_structure": "Структура каталогов",
        "struct_main": "Точка входа в приложение",
        "struct_run": "Скрипт запуска для Windows",
        "struct_req": "Список зависимостей",
        "struct_config_ini": "Простой файл конфигурации",
        "struct_config_json": "Файл конфигурации JSON",
        "struct_gitignore": "Файл исключений Git",
        "struct_readme": "Документация проекта (этот файл)",
        "struct_license": "Файл лицензии",
        "struct_about": "Краткое описание проекта",
        "struct_push_bat": "Скрипт автоотправки кода на GitHub",
        "struct_logs": "Журналы работы приложения",
        "struct_modules": "Основные модули с бизнес-логикой",
        "struct_assets": "Статические ресурсы приложения",
        "title_setup": "Руководство по установке и запуску",
        "setup_reqs": "Системные требования",
        "setup_os": "Операционная система: **Windows 10/11**",
        "setup_interpreter_python": "Интерпретатор: **Python 3.13** или соответствующая среда.",
        "setup_run_title": "Запуск",
        "setup_run_python_install": "Установите необходимые зависимости:",
        "setup_run_node_install": "Установите зависимости пакета:",
        "setup_run_dotnet_build": "Соберите проект с помощью .NET CLI:",
        "setup_run_ahk": "Запустите скрипт напрямую через AutoHotkey:",
        "setup_run_run": "Запустите приложение:",
        "title_license": "Лицензия",
        "license_body": "Этот проект распространяется под **лицензией MIT**. Подробности см. в файле [LICENSE](LICENSE)."
    },
    "pt": {
        "intro_python": "é um aplicativo desenvolvido em Python.",
        "intro_node": "é um projeto desenvolvido em Node.js.",
        "intro_ahk": "é uma ferramenta de automação escrita em AutoHotkey.",
        "intro_dotnet": "é um software desenvolvido na plataforma .NET.",
        "intro_generic": "é um projeto/ferramenta de automação.",
        "intro_desc": "O projeto é padronizado de acordo com estruturas de projetos profissionais, suportando gerenciamento eficiente de código-fonte via Git.",
        "title_intro": "Introdução",
        "title_features": "Recursos Principais",
        "feature_1": "Configuração rápida e empacotamento profissional.",
        "feature_2": "Configuração leve, fácil de manter e estender.",
        "feature_3": "Fluxo de trabalho de push automatizado para Git com o script incluso.",
        "title_structure": "Estrutura de Diretórios",
        "struct_main": "Ponto de entrada do aplicativo",
        "struct_run": "Script de início rápido no Windows",
        "struct_req": "Lista de dependências",
        "struct_config_ini": "Arquivo de configuração simples",
        "struct_config_json": "Arquivo de configuração JSON estruturado",
        "struct_gitignore": "Padrões de exclusão do Git",
        "struct_readme": "Documentação do projeto (este arquivo)",
        "struct_license": "Arquivo de licença",
        "struct_about": "Breve descrição do projeto",
        "struct_push_bat": "Script de push automático para o GitHub",
        "struct_logs": "Logs do aplicativo",
        "struct_modules": "Módulos principais contendo a lógica de negócios",
        "struct_assets": "Recursos estáticos do aplicativo",
        "title_setup": "Guia de Instalação e Uso",
        "setup_reqs": "Requisitos do Sistema",
        "setup_os": "SO: **Windows 10/11**",
        "setup_interpreter_python": "Intérprete: **Python 3.13** ou ambiente equivalente.",
        "setup_run_title": "Como Executar",
        "setup_run_python_install": "Instalar as dependências necessárias:",
        "setup_run_node_install": "Instalar as dependências do pacote:",
        "setup_run_dotnet_build": "Compilar o projeto usando a CLI do .NET:",
        "setup_run_ahk": "Executar o script diretamente via AutoHotkey:",
        "setup_run_run": "Executar o aplicativo:",
        "title_license": "Licença",
        "license_body": "Este projeto está licenciado sob a **Licença MIT**. Consulte o arquivo [LICENSE](LICENSE) para obter detalhes."
    },
    "ko": {
        "intro_python": "Python으로 개발된 애플리케이션입니다.",
        "intro_node": "Node.js 플랫폼에서 개발된 프로젝트입니다.",
        "intro_ahk": "AutoHotkey로 작성된 자동화 도구입니다.",
        "intro_dotnet": ".NET 플랫폼에서 개발된 소프트웨어입니다.",
        "intro_generic": "프로젝트/자동화 도구입니다.",
        "intro_desc": "본 프로젝트는 전문적인 프로젝트 구조에 따라 표준화되어 있으며, Git을 통한 효율적인 소스 코드 관리를 지원합니다.",
        "title_intro": "소개",
        "title_features": "주요 기능",
        "feature_1": "빠른 설정 및 전문가 수준의 패키징.",
        "feature_2": "유지 관리와 확장이 용이한 가벼운 구성.",
        "feature_3": "포함된 스크립트를 통한 자동 Git 푸시 워크플로우.",
        "title_structure": "디렉토리 구조",
        "struct_main": "애플리케이션 진입점",
        "struct_run": "Windows용 빠른 시작 스크립트",
        "struct_req": "의존성 목록",
        "struct_config_ini": "간단한 설정 파일",
        "struct_config_json": "구조화된 JSON 설정 파일",
        "struct_gitignore": "Git 제외 패턴",
        "struct_readme": "프로젝트 문서 (본 파일)",
        "struct_license": "라이센스 파일",
        "struct_about": "프로젝트에 대한 짧은 설명",
        "struct_push_bat": "GitHub 자동 푸시 스크립트",
        "struct_logs": "애플리케이션 로그",
        "struct_modules": "비즈니스 로직을 포함하는 핵심 모듈",
        "struct_assets": "애플리케이션 정적 리소스",
        "title_setup": "설치 및 사용 가이드",
        "setup_reqs": "시스템 요구 사항",
        "setup_os": "운영체제: **Windows 10/11**",
        "setup_interpreter_python": "인터프리터: **Python 3.13** 또는 해당 환경.",
        "setup_run_title": "실행 방법",
        "setup_run_python_install": "필수 의존성 설치:",
        "setup_run_node_install": "패키지 의존성 설치:",
        "setup_run_dotnet_build": ".NET CLI를 사용하여 프로젝트 빌드:",
        "setup_run_ahk": "AutoHotkey를 통해 스크립트 직접 실행:",
        "setup_run_run": "애플리케이션 실행:",
        "title_license": "라이센스",
        "license_body": "본 프로젝트는 **MIT 라이센스**에 따라 라이센스가 부여됩니다. 자세한 내용은 [LICENSE](LICENSE) 파일을 참조하십시오."
    }
}


def generate_language_bar(current_lang):
    langs = [
        ("en", "🇺🇸 English", "../README.md", "README.md"),
        ("vi", "🇻🇳 Tiếng Việt", "README.vi.md", "i18n/README.vi.md"),
        ("zh-cn", "🇨🇳 中文", "README.zh-CN.md", "i18n/README.zh-CN.md"),
        ("ja-jp", "🇯🇵 日本語", "README.ja-JP.md", "i18n/README.ja-JP.md"),
        ("es", "🇪🇸 Español", "README.es.md", "i18n/README.es.md"),
        ("fr", "🇫🇷 Français", "README.fr.md", "i18n/README.fr.md"),
        ("de", "🇩🇪 Deutsch", "README.de.md", "i18n/README.de.md"),
        ("ru", "🇷🇺 Русский", "README.ru.md", "i18n/README.ru.md"),
        ("pt", "🇵🇹 Português", "README.pt.md", "i18n/README.pt.md"),
        ("ko", "🇰🇷 한국어", "README.ko.md", "i18n/README.ko.md"),
    ]
    parts = []
    for code, label, rel_path, root_path in langs:
        if code == current_lang:
            parts.append(label)
        else:
            path = root_path if current_lang == "en" else rel_path
            parts.append(f'<a href="{path}">{label}</a>')
    return " • ".join(parts)


def generate_readme_content(project_name, kind, lang="en", repo_url=None, website_url=None):
    lang = lang.lower()
    if lang not in README_TRANSLATIONS:
        lang = "en"
        
    t = README_TRANSLATIONS[lang]
    if not repo_url:
        repo_url = f"https://github.com/JohnAlaa/{project_name}"

    if not website_url:
        website_url = "https://jatechvn.github.io/"
    
    if kind == "python":
        intro = f"**{project_name}** {t['intro_python']}"
        logo_url = "https://img.shields.io/badge/Python-3.13-blue.svg?style=flat-square&logo=python"
        tech_badges = f'<img src="{logo_url}" alt="Python Version">\n  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square" alt="License">'
        install_steps = f"""### {t['setup_run_title']}
1. {t['setup_run_python_install']}
   ```cmd
   pip install -r requirements.txt
   ```
2. {t['setup_run_run']}
   ```cmd
   run.bat
   ```"""
        ui_dir_desc = "User Interface package" if lang != "vi" else "Package chứa giao diện người dùng"
        ui_init_desc = "UI package marker" if lang != "vi" else "Đánh dấu package UI"
        ui_main_desc = "Main window interface" if lang != "vi" else "Cửa sổ giao diện chính của ứng dụng"
        ui_styles_desc = "UI stylesheet & styling" if lang != "vi" else "Stylesheet CSS và cấu hình giao diện"
        ui_dialogs_desc = "Popup dialogs (optional)" if lang != "vi" else "Hộp thoại popup phụ (nếu có)"
        logic_desc = "Core logic / Business rules" if lang != "vi" else "Logic nghiệp vụ chính"
        utils_desc = "Shared helper functions" if lang != "vi" else "Các hàm tiện ích dùng chung"
        const_desc = "Global constants" if lang != "vi" else "Hằng số cấu hình"
        logger_desc = "Logger configuration" if lang != "vi" else "Cấu hình logging"
        native_dir_desc = "Hybrid core engine package" if lang != "vi" else "Tầng quản lý xử lý lai (Hybrid Engine Core)"
        native_init_desc = "Native core package marker" if lang != "vi" else "Đánh dấu package native"
        win_core_desc = "Windows optimized core (PowerShell/C++)" if lang != "vi" else "Tối ưu Windows (Win32 API/PowerShell)"
        mac_core_desc = "macOS optimized core" if lang != "vi" else "Tối ưu macOS (Objective-C/dylib)"
        linux_core_desc = "Linux optimized core" if lang != "vi" else "Tối ưu Linux (Bash/so)"
        bridge_desc = "Dynamic routing bridge to active OS core" if lang != "vi" else "Bộ định tuyến động kết nối Logic và OS"

        tree_modules = f"""│   ├── ui/                    # {ui_dir_desc}
│   │   ├── __init__.py        # {ui_init_desc}
│   │   ├── main_window.py     # {ui_main_desc}
│   │   ├── styles.py          # {ui_styles_desc}
│   │   └── dialogs.py         # {ui_dialogs_desc}
│   ├── native/                # {native_dir_desc}
│   │   ├── __init__.py        # {native_init_desc}
│   │   ├── win_core.py        # {win_core_desc}
│   │   ├── mac_core.py        # {mac_core_desc}
│   │   └── linux_core.py      # {linux_core_desc}
│   ├── native_bridge.py       # {bridge_desc}
│   ├── logic.py               # {logic_desc}
│   ├── utils.py               # {utils_desc}
│   ├── constants.py           # {const_desc}
│   └── logger_config.py       # {logger_desc}"""
    elif kind == "node":
        intro = f"**{project_name}** {t['intro_node']}"
        logo_url = "https://img.shields.io/badge/Node.js-JS-green.svg?style=flat-square&logo=node.js"
        tech_badges = f'<img src="{logo_url}" alt="Node.js">\n  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square" alt="License">'
        install_steps = f"""### {t['setup_run_title']}
1. {t['setup_run_node_install']}
   ```cmd
   npm install
   ```
2. {t['setup_run_run']}
   ```cmd
   npm start
   ```"""
        tree_modules = f"│   # {t['struct_modules']}"
    elif kind == "ahk":
        intro = f"**{project_name}** {t['intro_ahk']}"
        tech_badges = '<img src="https://img.shields.io/badge/Language-AutoHotkey-orange.svg?style=flat-square" alt="AutoHotkey">\n  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square" alt="License">'
        install_steps = f"""### {t['setup_run_title']}
{t['setup_run_ahk']}
```cmd
"C:\\\\Program Files\\\\AutoHotkey\\\\AutoHotkey.exe" main.ahk
```"""
        tree_modules = f"│   # {t['struct_modules']}"
    elif kind == "dotnet":
        intro = f"**{project_name}** {t['intro_dotnet']}"
        tech_badges = '<img src="https://img.shields.io/badge/.NET-C%23-purple.svg?style=flat-square&logo=dotnet" alt=".NET">\n  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square" alt="License">'
        install_steps = f"""### {t['setup_run_title']}
{t['setup_run_dotnet_build']}
```cmd
dotnet build
dotnet run
```"""
        tree_modules = f"│   # {t['struct_modules']}"
    else:
        intro = f"**{project_name}** {t['intro_generic']}"
        tech_badges = '<img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square" alt="License">'
        install_steps = f"""### {t['setup_run_title']}
{t['setup_run_run']}"""
        tree_modules = f"│   # {t['struct_modules']}"

    lang_bar = generate_language_bar(lang)
    
    # Generate navigation bar
    nav_quick = t.get("nav_quick_start", "🚀 Quick Start")
    nav_feat = t.get("nav_features", "💡 Features")
    nav_set = t.get("nav_setup", "📖 Setup")
    nav_web = t.get("nav_website", "🌐 Website")
    nav_bar = f'<a href="#quick-start">{nav_quick}</a> • <a href="#features">{nav_feat}</a> • <a href="#setup">{nav_set}</a> • <a href="{website_url}">{nav_web}</a>'
    
    content = f"""# 🤖 {project_name}

<p align="center">
  <br>
  <i>{intro}</i>
</p>

<p align="center">
  {tech_badges}
</p>

<p align="center">{nav_bar}</p>

<p align="center">{lang_bar}</p>

---

<a id="introduction"></a>
## {t['title_intro']}

{t['intro_desc']}

<a id="features"></a>
## {t['title_features']}

- {t['feature_1']}
- {t['feature_2']}
- {t['feature_3']}

---

## {t['title_structure']}

```text
{project_name}/
├── main.py                    # {t['struct_main']}
├── run.bat                    # {t['struct_run']}
├── requirements.txt           # {t['struct_req']}
├── config.ini                 # {t['struct_config_ini']}
├── config.json                # {t['struct_config_json']}
├── .gitignore                 # {t['struct_gitignore']}
├── README.md                  # {t['struct_readme']}
├── LICENSE                    # {t['struct_license']}
├── ABOUT.txt                  # {t['struct_about']}
├── git_push.bat               # {t['struct_push_bat']}
│
├── logs/                      # {t['struct_logs']}
│
├── modules/                   # {t['struct_modules']}
{tree_modules}
│
└── assets/                    # {t['struct_assets']}
```

---

<a id="setup"></a>
## {t['title_setup']}

### {t['setup_reqs']}
*   {t['setup_os']}
*   {t['setup_interpreter_python']}

<a id="quick-start"></a>
{install_steps}

---

## {t['title_license']}

{t['license_body']}
"""
    return content

