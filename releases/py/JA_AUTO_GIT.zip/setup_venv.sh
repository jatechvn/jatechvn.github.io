#!/bin/bash
# Tự động di chuyển về thư mục chứa file script
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
    echo "[INFO] Đang khởi tạo .venv bằng Python 3.13..."
    python3.13 -m venv .venv || python3 -m venv .venv
fi

source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo -e "\n[OK] Môi trường .venv trên Mac/Linux đã sẵn sàng."
