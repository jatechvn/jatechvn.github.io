import subprocess


def git_output(cwd, args):
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=20,
        )
        if result.returncode != 0:
            return ""
        return result.stdout.strip()
    except Exception:
        return ""


def run_git(cwd, args, log_callback=None, allow_fail=False):
    cmd = ["git", *args]
    log(log_callback, f"$ {' '.join(cmd)}\n")
    process = subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if process.stdout:
        log(log_callback, process.stdout)
    if process.stderr:
        log(log_callback, process.stderr)
    if process.returncode != 0 and not allow_fail:
        raise RuntimeError(f"Git command failed: {' '.join(cmd)}")
    return process.returncode == 0


def log(callback, text):
    if callback:
        callback(text)
