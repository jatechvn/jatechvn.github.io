# 🤖 JA Auto Git — Liquid Glass Edition

<p align="center">
  <img src="../assets/images/icon.ico" alt="JA Auto Git Logo" width="120" height="120">
  <br>
  <i>개발자를 위한 자동화된 Git 관리 및 스마트 GitHub 저장소 생성 도구.</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=for-the-badge&logo=python&logoColor=white" alt="Python Version">
  <img src="https://img.shields.io/badge/GUI-PySide6-green.svg?style=for-the-badge&logo=qt&logoColor=white" alt="UI Framework">
  <img src="https://img.shields.io/badge/Integrations-GitHub_CLI-purple.svg?style=for-the-badge&logo=github&logoColor=white" alt="Integrations">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge" alt="License">
  <img src="https://img.shields.io/badge/Platform-Windows_%7C_macOS_%7C_Linux-0078D6.svg?style=for-the-badge&logo=windows&logoColor=white" alt="Platform">
  <img src="https://img.shields.io/badge/Version-1.5.0-orange.svg?style=for-the-badge" alt="Version">
</p>

<p align="center"><a href="#quick-start">🚀 빠른 시작</a> • <a href="#features">💡 기능</a> • <a href="#setup">📖 설치</a> • <a href="https://jatechvn.github.io/">🌐 웹사이트</a></p>

<p align="center"><a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="README.zh-CN.md">🇨🇳 中文</a> • <a href="README.ja-JP.md">🇯🇵 日本語</a> • <a href="README.es.md">🇪🇸 Español</a> • <a href="README.fr.md">🇫🇷 Français</a> • <a href="README.de.md">🇩🇪 Deutsch</a> • <a href="README.ru.md">🇷🇺 Русский</a> • <a href="README.pt.md">🇵🇹 Português</a> • 🇰🇷 한국어</p>

---

<a id="introduction"></a>
## 🌟 소개

**JA Auto Git**은 여러 서브 프로젝트의 버전 관리 설정과 GitHub 원격 저장소를 동시에 간편하게 처리해주는 전문 GUI 도구입니다. Python 스크립트, Node.js 패키지, AutoHotkey 스크립트, .NET 앱 등 여러 미니 프로젝트를 관리하는 개발자를 위해 설계되었으며, 몇 번의 클릭만으로 디렉토리 표준화와 GitHub 비공개 저장소 배포를 자동화합니다.

**Liquid Glass** 디자인 스타일과 macOS 스타일의 윈도우 컨트롤로 구성된 인터페이스는 Windows, macOS, Linux 전반에 걸쳐 현대적이고 직관적인 경험을 제공하며 개발자의 생산성을 극대화합니다.

## 📸 스크린샷

<p align="center">
  <img src="../assets/images/screenshot_dark.png" alt="JA Auto Git Dark Theme" width="48%">
  <img src="../assets/images/screenshot_light.png" alt="JA Auto Git Light Theme" width="48%">
</p>

---

<a id="workflow"></a>
## 📊 워크플로우

```mermaid
graph TD
    A[Launch JA Auto Git] --> B[Scan working directory up to max depth]
    B --> C[Analyze & detect project types + versions]
    C --> D{Check project status}
    D -->|Missing .git / gitignore / README / LICENSE| E[Show warning in UI tree]
    D -->|Standard files present| F[Show Standard OK status]
    E --> G[User selects projects → CREATE / EDIT GIT FORM]
    G --> H[Init Git · create .gitignore · write LICENSE · generate 10-lang READMEs]
    H --> I[User types Commit Message or leaves blank for auto-message]
    I --> J[Auto-generate subject + structured Change Log from staged diff]
    J --> K[Auto-create Private Repo on GitHub if missing · Push via GitHub CLI]
    K --> L[Update status · Auto-sync Cloud tab]
    L --> M{GitHub Cloud tab}
    M --> N[View per-repo Commit History · Download any commit ZIP]
    M --> O[View GitHub Releases · Download release assets to ~/Downloads]
    K --> P[Push GitHub Release with tag + assets via Release Manager]
```

---

<a id="features"></a>
## ✨ 주요 기능

### 1. 🔍 동적 프로젝트 스캐너 (자동 버전 감지)
- **기술 스택 자동 감지**: 파일 시그니처를 분석하여 프로젝트 유형(Python, Node.js, AHK, .NET, Batch/PowerShell)을 식별합니다.
- **재귀적 스캔**: 설정된 깊이까지 디렉토리를 스캔하며, `node_modules`, `.venv`, `__pycache__`, `dist` 등 대형 시스템/의존성 디렉토리는 자동으로 무시합니다.
- **멀티코어 병렬 처리**: 스캔 작업은 멀티스레딩을 활용하여 사용 가능한 모든 CPU 코어를 동시에 사용하며, UI는 항상 반응성을 유지합니다.
- **자동 버전 감지**: `package.json`, `pyproject.toml`, `setup.cfg`, `setup.py`, `*.csproj`, `constants.py`/`version.py`, `ABOUT.txt` 또는 최신 Git 태그에서 각 프로젝트의 버전을 자동으로 감지하여 **Version** 컬럼에 표시합니다.

### 2. 🛡️ 표준화된 프로젝트 구조 (Git Form)
- **완전한 보안**: 언어별 `.gitignore` 파일을 자동으로 구성하며, 기본적으로 자격증명 및 라이선스 키(예: `license.key`)를 무시합니다.
- **다국어 문서 생성기**: 루트 `README.md`(영어)와 `i18n/` 폴더에 교차 링크 탐색 바가 포함된 **9개 주요 언어** 버전을 자동으로 생성합니다.
- **MIT 라이선스 생성기**: 현재 연도와 설정된 저자 이름(UI / `config.ini`에서 사용자 지정 가능)을 사용하여 표준 `LICENSE` 파일을 동적으로 생성합니다.
- **푸시 유틸리티**: 빠른 수동 푸시를 위해 각 서브 프로젝트에 `git_push.bat` / `git_push.sh` 스크립트를 포함합니다.

### 3. 📝 스마트 자동 체인지로그 커밋 엔진
- **자동 제목 생성**: 커밋 메시지를 비워두거나 플레이스홀더로 두면, 앱이 스테이징된 diff를 분석하여 `"Update main.py, utils.py and 3 other files"`와 같은 설명적인 제목을 자동으로 생성합니다.
- **구조화된 변경 로그 본문**: 모든 커밋에는 수정(`M`), 추가(`A`), 삭제(`D`), 이름 변경(`R`) 파일을 상태와 함께 나열하는 `Change Log:` 섹션이 자동으로 추가됩니다.
- **레거시 마이그레이션**: 기존의 기본 `"Update project"` 메시지를 사용하던 설정은 새로운 빈/자동 커밋 워크플로우로 자동 마이그레이션됩니다.

자동 생성된 커밋 메시지 예시:
```
Update main.py, config.ini and 2 other files

Change Log:
  M  modules/git_actions.py
  M  modules/ui/main_window.py
  A  modules/ui/dialogs.py
  D  temp_debug.txt
```

### 4. 🚀 릴리즈 매니저 — GitHub 릴리즈 푸시 *(v1.5.0 신기능)*
- **원클릭 릴리즈**: Git + 원격이 구성된 각 프로젝트 행에는 로컬 워크스페이스 탭에 **🚀 Release** 버튼이 표시됩니다.
- **자동 태그 생성**: 릴리즈 매니저는 감지된 프로젝트 버전(예: `v1.5.0`)으로 태그 이름을 자동으로 채웁니다.
- **에셋 첨부**: 파일 선택기를 사용하여 빌드 파일(`.exe`, `.zip`, `.whl` 등)을 릴리즈에 첨부합니다.
- **백그라운드 푸시**: 릴리즈 생성은 `gh release create`를 통해 백그라운드 스레드에서 실행되어 UI 반응성을 유지합니다.
- **실시간 상태**: 버튼 상태가 실시간으로 업데이트됩니다: `⏳ Pushing...` → 성공 시 `✅ Released`, 실패 시 오류 툴팁 표시.

### 5. ☁️ GitHub Cloud 탭 — 커밋 & 릴리즈 *(v1.5.0 업데이트)*

#### 🕐 커밋 기록 & 다운로드
- **저장소별 커밋 기록**: 각 프로젝트 행에는 전체 커밋 기록 다이얼로그를 여는 **🕐 Commits** 버튼이 표시됩니다.
- **커밋 기록 다이얼로그**: SHA · 태그/버전 배지 · 작성자 · 날짜 · 제목(전체 메시지는 마우스 오버로 확인)을 표시하는 프레임리스 macOS 스타일 다이얼로그.
- **커밋별 ZIP 다운로드**: 각 커밋 행에는 다음을 수행하는 **⬇ sha** 버튼이 있습니다:
  1. GitHub CLI를 통해 스냅샷 ZIP을 `~/Downloads/{repo}_{sha7}.zip`으로 직접 다운로드합니다.
  2. 다운로드 후 **파일이 강조 표시된 탐색기를 엽니다** (`explorer /select,file`).
  3. 파일이 이미 로컬에 존재하는 경우 재다운로드를 건너뜁니다.
  4. 실시간 버튼 상태: `⏳ Downloading...` → 성공 시 `✅ sha7`.

#### 📦 릴리즈 브라우저 & 다운로드 *(v1.5.0 신기능)*
- **저장소별 릴리즈 목록**: 각 프로젝트 행에는 전용 릴리즈 브라우저 다이얼로그를 여는 **📦 Releases** 버튼이 표시됩니다.
- **릴리즈 브라우저 다이얼로그**: 다음을 포함한 모든 GitHub 릴리즈를 나열하는 프레임리스 macOS 스타일 다이얼로그:
  - 태그 / 이름 · 날짜 · 유형 (Stable / Pre-release / Draft) · 에셋 수
- **에셋별 다운로드**: 각 릴리즈 행에는 첨부된 에셋의 다운로드 버튼이 표시됩니다 (최대 3개 표시):
  - `urllib`을 통해 `~/Downloads/`로 직접 다운로드합니다.
  - 에셋이 첨부되지 않은 경우 **소스 ZIP** 다운로드로 폴백합니다.
  - 다운로드 후 파일이 강조 표시된 탐색기를 엽니다.
  - 실시간 버튼 상태: `⏳` → 성공 시 `✅ Done`, 실패 시 `⬇ Retry`.
- **스레드 안전 UI 업데이트**: 모든 다운로드 작업은 워커 스레드에서 Qt `Signal` 방출을 사용합니다.

### 6. 🎨 Liquid Glass UI — 레이아웃 & 컨트롤
- **최적화된 패널 비율**: 프로젝트 Git 상태 트리는 오른쪽 패널 높이의 **4/6**을 차지하고, 라이브 Git 콘솔은 **2/6**을 차지하여 트리에 충분한 표시 공간을 제공합니다.
- **통합 콘솔 헤더**: "LIVE GIT CONSOLE" 레이블과 "Clear Console" 버튼이 단일 툴바 행을 공유합니다.
- **macOS 스타일 윈도우 컨트롤**: 모든 다이얼로그에 빨강/초록 신호등 버튼(🔴 닫기, 🟢 최대화/복원), 프레임리스 둥근 모서리 레이아웃, 드래그 이동 지원이 포함됩니다.
- **상태 필터링**: 빠른 선택을 위한 필터링 버튼(`Has .git`, `No .git`, `Missing Form`, `Not Cloned`, `Behind Cloud`).
- **프로젝트 숨기기 (눈 토글)**: 불필요한 프로젝트를 트리 및 사이드바에서 숨기며 `config.ini`에 설정이 유지됩니다.
- **라이브 콘솔**: 모든 백그라운드 Git 작업의 실시간 출력을 표시합니다.
- **고정 너비 버튼 컬럼**: Commits 및 Releases 컬럼은 `QHeaderView.Fixed` 모드를 사용하여 창 크기가 변경되거나 최대화될 때 늘어나지 않습니다.

### 7. ⚙️ 크로스 플랫폼 하이브리드 엔진 코어
- **동적 OS 라우팅**: 런타임에 호스트 OS(Windows, macOS, Linux)를 감지하고, `native_bridge.py`를 통해 시스템 작업을 플랫폼 네이티브 최적화 컴포넌트로 라우팅합니다.
  - **Windows**: Win32 API / PowerShell / 선택적 C++ DLL (`modules/native/win_core.py`)
  - **macOS**: Objective-C / AppleScript / 선택적 `.dylib` (`modules/native/mac_core.py`)
  - **Linux**: Bash / 선택적 `.so` 공유 라이브러리 (`modules/native/linux_core.py`)
- **안전한 실행 폴백**: 네이티브 컴포넌트가 없는 경우 자동으로 순수 Python으로 폴백하여 충돌 없이 최대 호환성을 보장합니다.
- **크로스 플랫폼 시작 스크립트**: Windows 및 Unix 계열 시스템을 위한 `run.bat` / `run.sh` 및 `setup_venv.sh`가 제공됩니다.

```
modules/
├── ui/                        # PySide6 GUI layer
├── native/                    # Hybrid Engine Core
│   ├── win_core.py            # Windows: Win32 API, DLL, PowerShell
│   ├── mac_core.py            # macOS: Objective-C, dylib, AppleScript
│   └── linux_core.py          # Linux: Bash, .so shared library
├── native_bridge.py           # Dynamic OS router (singleton)
├── git_actions.py             # Git operations + auto-changelog
├── github_ops.py              # GitHub CLI + commit/release API
├── project_scan.py            # Project scanner + version detector
├── project_model.py           # ProjectInfo dataclass
├── git_runner.py              # Background thread runner
├── constants.py               # App-wide constants (APP_VERSION)
└── utils.py / i18n_ui.py      # Settings + 10-language translations
```

### 8. 🔄 자동 클라우드 동기화 & 선택 항목 유지
- **시작 시 자동 클라우드 패치**: 로컬 스캔 후 백그라운드에서 GitHub 클라우드 저장소 상태를 가져옵니다.
- **선택 항목 유지**: `config.ini`를 통해 실행 간에 체크박스 상태를 기억합니다.
- **저장소별 다중 커밋 보기**: 요청 시 전체 커밋 기록(태그 주석 포함, 최대 30개 커밋)을 확인할 수 있습니다.

### 9. 👤 자동 Git 신원 설정
- **제로 설정 커밋**: Git `user.name` / `user.email`이 없는 경우 이를 감지하고 `gh`를 통해 GitHub 프로필에서 자동으로 구성합니다.

---

<a id="setup"></a>
## 🚀 설치 및 설정

### 시스템 요구 사항

| 컴포넌트 | 최소 버전 | 비고 |
|---|---|---|
| Python | 3.13 | "Add Python to PATH" 체크 확인 |
| GitHub CLI (`gh`) | 2.92.0 | `gh auth login`으로 인증 |
| Git Credential Manager | 2.8.0 | 보안 푸시 인증 |

> ⚠️ **중요**: 시스템 환경 변수 `GITHUB_TOKEN`에 만료되거나 유효하지 않은 값이 설정된 경우, 앱은 인증 실패를 방지하기 위해 `gh api` 호출 전에 자동으로 해당 값을 제거합니다.

<a id="quick-start"></a>
### 단계별 설치

#### 1단계: 필수 구성 요소 설치

1. **Python 3.13+** — [공식 다운로드](https://www.python.org/downloads/)
2. **GitHub CLI 2.92.0** — 이전 버전의 터미널 인젝션 취약점 방지:
   - [gh_2.92.0_windows_amd64.msi 다운로드](https://github.com/cli/cli/releases/download/v2.92.0/gh_2.92.0_windows_amd64.msi)
3. **Git Credential Manager 2.8.0**:
   - [gcm-win-x64-2.8.0.exe 다운로드](https://github.com/git-ecosystem/git-credential-manager/releases/download/v2.8.0/gcm-win-x64-2.8.0.exe)

#### 2단계: 저장소 클론
```cmd
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY
```

#### 3단계: Python 의존성 설치
```cmd
pip install -r requirements.txt
```

#### 4단계: GitHub CLI 인증
```cmd
gh auth login
```
*(브라우저 또는 SSH 인증 중 선호하는 방식을 선택하세요.)*

#### 5단계: 애플리케이션 실행

**Windows:**
```cmd
run.bat
```
**macOS / Linux:**
```bash
chmod +x run.sh && ./run.sh
```

---

<a id="config"></a>
## ⚙️ 설정

### `config.ini` — 기본 설정
```ini
[settings]
root_dir       = D:\Workspaces\MyProjects   ; 스캔할 루트 디렉토리
remote_base    = github.com/username         ; GitHub 사용자 이름
branch         = main                        ; 기본 브랜치
commit_message =                             ; 비워두면 제목 및 체인지로그 자동 생성
max_depth      = 3                           ; 최대 스캔 깊이
auto_create_repo = yes                       ; 저장소가 없으면 자동으로 GitHub 저장소 생성
```

> 💡 **팁**: `commit_message`를 비워두면 **자동 체인지로그** 모드가 활성화됩니다. 앱이 스테이징된 diff에서 설명적인 제목과 전체 `Change Log:` 본문을 자동으로 생성합니다.

### `config.json` — 고급 동기화 설정
```json
{
  "git": {
    "default_branch": "main",
    "default_commit_message": "",
    "auto_create_github_repo": true
  }
}
```

---

## 🗂️ 프로젝트 구조

```
JA_AUTO_GIT/
├── main.py                    # 진입점
├── run.bat / run.sh           # 빠른 실행 스크립트 (Windows / Unix)
├── setup_venv.sh              # 가상 환경 설정 (Unix)
├── requirements.txt
├── config.ini                 # 사용자 설정
├── config.json                # 고급 설정
├── assets/                    # 아이콘 및 이미지
├── i18n/                      # 현지화 README (9개 언어)
├── logs/                      # 런타임 로그
└── modules/
    ├── ui/
    │   ├── main_window.py     # 메인 애플리케이션 창
    │   ├── dialogs.py         # 모든 다이얼로그 (Commit, Release, Cloud Release)
    │   └── styles.py          # Liquid Glass 스타일시트
    ├── native/                # 크로스 플랫폼 하이브리드 엔진
    │   ├── win_core.py
    │   ├── mac_core.py
    │   └── linux_core.py
    ├── native_bridge.py       # OS 라우터 (싱글턴)
    ├── git_actions.py         # Git 작업 + 자동 체인지로그
    ├── github_ops.py          # GitHub CLI + 커밋/릴리즈 API
    ├── project_scan.py        # 프로젝트 스캐너 + 버전 감지기
    ├── project_model.py       # ProjectInfo dataclass
    ├── git_runner.py          # 백그라운드 스레드 러너
    ├── constants.py           # 앱 전역 상수 (APP_VERSION = "1.5.0")
    └── utils.py               # 설정 로드/저장 + 마이그레이션
```

---

## 📋 체인지로그

### v1.5.0 *(최신)*
- ✨ **릴리즈 매니저**: 로컬 워크스페이스 탭에서 태그 + 에셋과 함께 GitHub 릴리즈 푸시
- ✨ **릴리즈 브라우저**: Cloud 탭에서 GitHub 릴리즈 보기 및 다운로드 (에셋 포함)
- ✨ **버전 컬럼**: 패키지 파일 또는 git 태그에서 프로젝트 버전 자동 감지
- 🔧 **고정 너비 버튼 컬럼**: 창 크기 조정 시 Commits & Releases 컬럼이 더 이상 늘어나지 않음
- 🔧 **QHeaderView.Fixed**: 두 워크스페이스 탭의 모든 버튼 컬럼에 적용

### v1.4.0
- ✨ **커밋 기록 다이얼로그**: 커밋별 ZIP 다운로드가 포함된 저장소별 커밋 기록
- ✨ **자동 체인지로그 엔진**: 커밋 제목 + Change Log 본문 자동 생성
- 🔧 **스레드 안전 다운로드**: Qt Signal/Slot 크로스 스레드 UI 업데이트

### v1.3.0
- ✨ **크로스 플랫폼 하이브리드 엔진**: Windows/macOS/Linux용 네이티브 브리지
- ✨ **프로젝트 숨기기**: 설정 유지가 포함된 눈 토글
- 🔧 **macOS 스타일 윈도우 컨트롤**: 모든 다이얼로그 통합

---

<a id="license"></a>
## 📜 라이선스 및 저작권

이 프로젝트는 **MIT 라이선스** 하에 배포됩니다. 자세한 내용은 [LICENSE](LICENSE) 파일을 참조하세요.

Copyright John Alaa @ 2026.
