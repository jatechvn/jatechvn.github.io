from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QPixmap, QPainter, QPen, QBrush, QPainterPath, QIcon
from PySide6.QtWidgets import QGraphicsDropShadowEffect
from BlurWindow.blurWindow import GlobalBlur

from ..constants import *
from ..i18n_ui import UI_TRANSLATIONS


def add_shadow(widget, is_dark, color=None, radius=12):
    if color is None:
        color = QColor(0, 0, 0, 160) if is_dark else QColor(0, 0, 0, 50)
    shadow = QGraphicsDropShadowEffect()
    shadow.setBlurRadius(radius)
    shadow.setColor(color)
    shadow.setOffset(2, 2)
    widget.setGraphicsEffect(shadow)


def create_eye_icon(window, crossed=False):
    pixmap = QPixmap(32, 32)
    pixmap.fill(Qt.transparent)
    
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    
    # Color matching theme
    color = QColor(255, 255, 255) if window.is_dark else QColor(30, 30, 30)
    accent_color = QColor(0, 240, 255) # Cyan glow
    
    # Outer eye curve
    path = QPainterPath()
    path.moveTo(4, 16)
    path.quadTo(16, 6, 28, 16)
    path.quadTo(16, 26, 4, 16)
    
    painter.setPen(QPen(color, 2, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
    painter.setBrush(Qt.NoBrush)
    painter.drawPath(path)
    
    # Draw iris (pupil)
    painter.setBrush(QBrush(accent_color if not crossed else color))
    painter.setPen(Qt.NoPen)
    painter.drawEllipse(11, 11, 10, 10)
    
    # Draw pupil center dot
    painter.setBrush(QBrush(color if not crossed else QColor(18, 18, 18) if window.is_dark else QColor(240, 240, 240)))
    painter.drawEllipse(15, 15, 2, 2)
    
    if crossed:
        # Diagonal red line across the eye
        painter.setPen(QPen(QColor(255, 75, 75), 2.5, Qt.SolidLine, Qt.RoundCap))
        painter.drawLine(6, 6, 26, 26)
        
    painter.end()
    return QIcon(pixmap)


def update_eye_button_icon(window):
    crossed = not window.show_hidden_projects
    window.btn_toggle_hidden.setIcon(create_eye_icon(window, crossed))
    
    t = UI_TRANSLATIONS[window.current_lang]
    tooltip = t["tooltip_show_hidden"] if crossed else t["tooltip_hide_hidden"]
    window.btn_toggle_hidden.setToolTip(tooltip)


def apply_app_theme(window):
    if window.is_dark:
        bg_main = "rgba(18, 18, 18, 0.65)"
        text_main = "#ffffff"
        input_bg = "rgba(0, 0, 0, 0.4)"
        console_bg = "rgba(0, 0, 0, 0.6)"
        tree_bg = "rgba(0, 0, 0, 0.35)"
        border = "rgba(255, 255, 255, 0.15)"
        window.btn_theme.setText(UI_TRANSLATIONS[window.current_lang]["theme_dark"])
    else:
        bg_main = "rgba(240, 240, 240, 0.75)"
        text_main = "#111111"
        input_bg = "rgba(255, 255, 255, 0.6)"
        console_bg = "rgba(255, 255, 255, 0.5)"
        tree_bg = "rgba(255, 255, 255, 0.55)"
        border = "rgba(0, 0, 0, 0.15)"
        window.btn_theme.setText(UI_TRANSLATIONS[window.current_lang]["theme_light"])

    try:
        GlobalBlur(window.winId(), Dark=window.is_dark)
    except Exception:
        pass

    window.central_widget.setStyleSheet(
        f"#CentralWidget {{ background-color: {bg_main}; border: 1px solid {border}; border-radius: 16px; }}"
    )
    window.lbl_title.setStyleSheet(
        f"color: {text_main}; font-family: '{FONT_PRIMARY}'; font-weight: 800; font-size: 13px; letter-spacing: 2px;"
    )
    window.lbl_status.setStyleSheet(
        f"color: {text_main}; font-family: '{FONT_PRIMARY}'; font-weight: bold; font-size: 11px;"
    )

    window.setStyleSheet(f"""
        QTabBar {{
            background-color: transparent;
            border: none;
        }}
        QTabBar::tab {{
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')}, 0.05);
            color: {text_main};
            border: 1px solid {border};
            border-bottom: none;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            padding: 6px 16px;
            font-family: '{FONT_PRIMARY}';
            font-weight: bold;
            font-size: 11px;
            margin-right: 4px;
        }}
        QTabBar::tab:selected {{
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')}, 0.12);
            border-color: {ACCENT_CYAN};
            color: {ACCENT_CYAN};
        }}
        QTabBar::tab:hover {{
            border-color: {ACCENT_CYAN};
        }}
        QGroupBox {{
            color: {text_main};
            font-family: '{FONT_PRIMARY}';
            font-weight: bold;
            font-size: 11px;
            border: 1px solid {border};
            border-radius: 12px;
            margin-top: 10px;
            padding-top: 15px;
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')},0.02);
        }}
        QGroupBox::title {{
            subcontrol-origin: margin;
            subcontrol-position: top left;
            left: 15px;
            padding: 0 5px;
        }}
        QLabel {{
            color: {text_main};
            font-family: '{FONT_PRIMARY}';
            font-size: 11px;
            font-weight: 500;
        }}
        QLabel#ConsoleLabel {{
            color: {ACCENT_CYAN};
            font-weight: 800;
            font-size: 11px;
            letter-spacing: 1px;
        }}
        QLineEdit, QSpinBox {{
            background-color: {input_bg};
            color: {text_main};
            border: 1px solid {border};
            border-radius: 8px;
            padding: 7px 10px;
            font-family: '{FONT_PRIMARY}';
            font-size: 12px;
        }}
        QLineEdit:focus, QSpinBox:focus {{ border: 1px solid {ACCENT_CYAN}; }}
        QPushButton {{
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')},0.05);
            color: {text_main};
            border: 1px solid {border};
            border-radius: 8px;
            font-family: '{FONT_PRIMARY}';
            font-weight: bold;
            font-size: 11px;
            padding: 6px 14px;
        }}
        QPushButton#EyeBtn {{
            background-color: transparent;
            border: none;
            border-radius: 4px;
        }}
        QPushButton#EyeBtn:hover {{
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')}, 0.12);
            border: none;
        }}
        QPushButton#LangBtn {{
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')}, 0.03);
            color: {text_main};
            border: 1px solid {border};
            border-radius: 6px;
            font-family: '{FONT_PRIMARY}';
            font-size: 10px;
            font-weight: bold;
            padding: 4px 6px;
        }}
        QPushButton#LangBtn:hover {{
            border: 1px solid {ACCENT_CYAN};
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')}, 0.12);
        }}
        QPushButton#LangBtn[active="true"] {{
            border: 1px solid {ACCENT_GREEN};
            background-color: rgba(0, 255, 157, 0.12);
            color: {ACCENT_GREEN};
        }}
        QCheckBox {{
            color: {text_main};
            font-family: '{FONT_PRIMARY}';
            font-size: 11px;
        }}
        QPushButton:hover {{
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')},0.15);
            border: 1px solid {ACCENT_CYAN};
        }}
        QTextEdit {{
            background-color: {console_bg};
            color: {ACCENT_GREEN if window.is_dark else '#0d5c3a'};
            border: 1px solid {border};
            border-radius: 12px;
            font-family: '{FONT_MONO}';
            font-size: 12px;
            padding: 10px;
        }}
        QTreeWidget {{
            background-color: {tree_bg};
            color: {text_main};
            border: 1px solid {border};
            border-radius: 12px;
            font-family: '{FONT_PRIMARY}';
            font-size: 11px;
            alternate-background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')},0.04);
        }}
        QScrollBar:vertical {{
            border: none;
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')}, 0.02);
            width: 8px;
            margin: 0px;
            border-radius: 4px;
        }}
        QScrollBar::handle:vertical {{
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')}, 0.15);
            min-height: 20px;
            border-radius: 4px;
        }}
        QScrollBar::handle:vertical:hover {{
            background-color: {ACCENT_CYAN};
        }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
            height: 0px;
            background: none;
        }}
        QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
            background: none;
        }}
        QScrollBar:horizontal {{
            border: none;
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')}, 0.02);
            height: 8px;
            margin: 0px;
            border-radius: 4px;
        }}
        QScrollBar::handle:horizontal {{
            background-color: rgba({('255,255,255' if window.is_dark else '0,0,0')}, 0.15);
            min-width: 20px;
            border-radius: 4px;
        }}
        QScrollBar::handle:horizontal:hover {{
            background-color: {ACCENT_CYAN};
        }}
        QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
            width: 0px;
            background: none;
        }}
        QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{
            background: none;
        }}
        QHeaderView {{
            background-color: transparent;
            border: none;
        }}
        QHeaderView::section {{
            background-color: {('#2d2d2d' if window.is_dark else '#eaeaea')};
            color: {text_main};
            border: none;
            border-right: 1px solid {border};
            border-bottom: 1px solid {border};
            padding: 6px;
            font-family: '{FONT_PRIMARY}';
            font-weight: bold;
            font-size: 11px;
        }}
        QProgressBar {{ background: transparent; border: none; }}
        QProgressBar::chunk {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {ACCENT_CYAN}, stop:1 {ACCENT_GREEN});
            border-radius: 2px;
        }}
        QPushButton#BuildBtn {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {ACCENT_CYAN}, stop:1 {ACCENT_GREEN});
            color: black;
            border: none;
            border-radius: 12px;
            font-weight: 800;
            letter-spacing: 1px;
        }}
        QPushButton#BuildBtn:hover {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00ffff, stop:1 #27ffc9);
        }}
        QPushButton#BuildBtn:disabled {{
            background: rgba(120, 120, 120, 0.2);
            color: rgba(255, 255, 255, 0.3);
        }}
        QPushButton#CommitsBtn {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 rgba(124,58,237,0.75), stop:1 rgba(159,93,254,0.75));
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 8px;
        }}
        QPushButton#CommitsBtn:hover {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 rgba(159,93,254,0.90), stop:1 rgba(0,240,255,0.80));
        }}
        QPushButton#btnRelease {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 rgba(255,107,0,0.80), stop:1 rgba(255,60,120,0.80));
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 8px;
        }}
        QPushButton#btnRelease:hover {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 rgba(255,140,0,0.95), stop:1 rgba(255,80,150,0.95));
        }}
        QPushButton#btnRelease:disabled {{
            background: rgba(120, 120, 120, 0.2);
            color: rgba(255,255,255,0.3);
        }}
        QPushButton#btnCloudRelease {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 rgba(0,180,255,0.80), stop:1 rgba(100,60,255,0.80));
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 8px;
        }}
        QPushButton#btnCloudRelease:hover {{
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 rgba(50,200,255,0.95), stop:1 rgba(130,80,255,0.95));
        }}
        QPushButton#CloseBtn {{
            background-color: {COLOR_CLOSE_NORMAL};
            border: 1px solid {COLOR_CLOSE_BORDER};
            border-radius: 8px;
        }}
        QPushButton#CloseBtn:hover {{ background-color: {COLOR_CLOSE_HOVER}; }}
        QPushButton#MinBtn {{
            background-color: {COLOR_MIN_NORMAL};
            border: 1px solid {COLOR_MIN_BORDER};
            border-radius: 8px;
        }}
        QPushButton#MinBtn:hover {{ background-color: {COLOR_MIN_HOVER}; }}
        QPushButton#MaxBtn {{
            background-color: {COLOR_MAX_NORMAL};
            border: 1px solid {COLOR_MAX_BORDER};
            border-radius: 8px;
        }}
        QPushButton#MaxBtn:hover {{ background-color: {COLOR_MAX_HOVER}; }}
    """)
    update_eye_button_icon(window)
