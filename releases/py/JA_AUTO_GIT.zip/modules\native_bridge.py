# -*- coding: utf-8 -*-
# modules/native_bridge.py
import sys
import platform
import logging

logger = logging.getLogger(__name__)

class NativeBridge:
    def __init__(self):
        self.os_name = platform.system()
        self.engine = None
        self._initialize_engine()

    def _initialize_engine(self):
        """Tự động phát hiện OS để nạp mô-đun tối ưu tương ứng"""
        try:
            if self.os_name == "Windows":
                from modules.native.win_core import WindowsNativeEngine
                self.engine = WindowsNativeEngine()
            elif self.os_name == "Darwin":  # macOS
                from modules.native.mac_core import MacNativeEngine
                self.engine = MacNativeEngine()
            elif self.os_name == "Linux":
                from modules.native.linux_core import LinuxNativeEngine
                self.engine = LinuxNativeEngine()
            else:
                logger.warning(f"[BRIDGE] Hệ điều hành {self.os_name} chưa hỗ trợ Hybrid Core. Dùng Fallback.")
                self.engine = None
        except Exception as e:
            logger.error(f"[BRIDGE] Lỗi khởi tạo Engine cho {self.os_name}: {e}")
            self.engine = None

    def execute_heavy_task(self, data_input):
        """Hàm mẫu bọc tác vụ xử lý hiệu năng cao"""
        # Nếu có Engine tối ưu riêng cho OS đó, cho chạy với tốc độ tối đa
        if self.engine and hasattr(self.engine, 'heavy_compute'):
            return self.engine.heavy_compute(data_input)
        
        # PHƯƠNG ÁN DỰ PHÒNG (Fallback): Nếu OS lạ hoặc lỗi mô-đun, chạy bằng Python thuần
        return self._pure_python_fallback(data_input)

    def _pure_python_fallback(self, data_input):
        """Code Python tiêu chuẩn để đảm bảo chạy được trên mọi máy tính"""
        logger.info("[BRIDGE] Đang xử lý bằng giải thuật Python thuần (Chậm hơn).")
        # Logic dự phòng của bạn viết ở đây...
        return data_input

# Khởi tạo một instance duy nhất để toàn bộ ứng dụng sử dụng (Singleton)
native_agent = NativeBridge()
