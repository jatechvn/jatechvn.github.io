from .main_window import AutoGitApp
