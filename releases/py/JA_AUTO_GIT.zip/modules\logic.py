# Compatibility exports. New code should import the focused modules directly.
from .git_actions import commit_and_push_project
from .git_form import (
    ensure_git_push_bat,
    ensure_gitignore,
    fix_project_git_form,
    gitignore_is_standard,
)
from .git_process import git_output, log, run_git
from .git_runner import GitRunner
from .github_ops import ensure_github_repo, find_gh, gh_repo_exists
from .project_model import ProjectInfo
from .project_scan import (
    build_status,
    detect_project_kind,
    inspect_project,
    relative_depth,
    scan_projects,
)

# Hybrid Engine Core Integration
from modules.native_bridge import native_agent

def execute_hybrid_compute(data_input):
    """Business logic wrapper that routes heavy computation to the OS-native engine"""
    return native_agent.execute_heavy_task(data_input)

