from .constants import DEFAULT_BRANCH
from .git_form import fix_project_git_form
from .git_process import git_output, log, run_git
from .github_ops import ensure_github_repo, resolve_github_owner
from .project_scan import inspect_project
from .utils import repo_name_for_project


def commit_and_push_project(project_dir, remote_base, commit_message, log_callback=None, auto_create_repo=False, is_public=False):
    import os
    info = inspect_project(project_dir)
    if not info.has_git:
        log(log_callback, f"[ERROR] Git repository is not initialized for {os.path.basename(project_dir)}. Please run 'CREATE / EDIT GIT FORM' first.\n")
        return False

    # Ensure Git author identity is configured
    try:
        user_name = git_output(project_dir, ["config", "--get", "user.name"]).strip()
        user_email = git_output(project_dir, ["config", "--get", "user.email"]).strip()
        
        if not user_name or not user_email:
            log(log_callback, "[INFO] Git author identity is unknown. Auto-configuring Git user.name and user.email using GitHub details...\n")
            from .github_ops import find_gh
            import subprocess
            import json
            
            gh_name = ""
            gh_email = ""
            gh = find_gh()
            if gh:
                result = subprocess.run(
                    [gh, "api", "user"],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                if result.returncode == 0:
                    try:
                        user_data = json.loads(result.stdout)
                        gh_name = user_data.get("name") or user_data.get("login") or ""
                        gh_email = user_data.get("email") or ""
                        if not gh_email and user_data.get("login"):
                            gh_email = f"{user_data['login']}@users.noreply.github.com"
                    except Exception:
                        pass
            
            if not gh_name:
                gh_name = resolve_github_owner(remote_base) or "JA Auto Git User"
            if not gh_email:
                clean_login = gh_name.replace(" ", "").lower()
                gh_email = f"{clean_login}@users.noreply.github.com"
                
            if not user_name:
                log(log_callback, f"[INFO] Setting Git user.name to '{gh_name}'...\n")
                res = run_git(project_dir, ["config", "--global", "user.name", gh_name], log_callback, allow_fail=True)
                if not res:
                    run_git(project_dir, ["config", "user.name", gh_name], log_callback, allow_fail=True)
                    
            if not user_email:
                log(log_callback, f"[INFO] Setting Git user.email to '{gh_email}'...\n")
                res = run_git(project_dir, ["config", "--global", "user.email", gh_email], log_callback, allow_fail=True)
                if not res:
                    run_git(project_dir, ["config", "user.email", gh_email], log_callback, allow_fail=True)
    except Exception as e:
        log(log_callback, f"[WARN] Auto-configuration of Git identity failed: {e}\n")

    repo_name = repo_name_for_project(project_dir)
    remote_url = info.remote_url or remote_url_for_repo(remote_base, repo_name)

    if remote_url:
        if auto_create_repo:
            import os
            about_path = os.path.join(project_dir, "ABOUT.txt")
            description = ""
            if os.path.isfile(about_path):
                try:
                    with open(about_path, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                        # Extract the description from the text card if format matches
                        for line in content.splitlines():
                            if "Description  :" in line:
                                description = line.split("Description  :", 1)[1].strip()
                                break
                        if not description:
                            # Fallback if it's a simple text file
                            description = content.strip().splitlines()[0].strip()
                except OSError:
                    pass
            if not description:
                description = f"Project {repo_name} ({info.kind}) managed automatically by JA Auto Git."
                if info.kind == "python":
                    description = f"Python application {repo_name} managed automatically by JA Auto Git."
                elif info.kind == "node":
                    description = f"Node.js project {repo_name} managed automatically by JA Auto Git."
                elif info.kind == "dotnet":
                    description = f".NET application {repo_name} managed automatically by JA Auto Git."
                elif info.kind == "ahk":
                    description = f"AutoHotkey script {repo_name} managed automatically by JA Auto Git."
            homepage = "https://jatechvn.github.io/"
            ensure_github_repo(remote_base, repo_name, log_callback, description, homepage, is_public)
        run_git(project_dir, ["remote", "remove", "origin"], log_callback, allow_fail=True)
        run_git(project_dir, ["remote", "add", "origin", remote_url], log_callback)
        log(log_callback, f"[OK] Remote origin: {remote_url}\n")
    else:
        log(log_callback, "[WARN] No GitHub owner/remote found. Commit only, push skipped.\n")

    run_git(project_dir, ["add", "."], log_callback)
    staged_status = git_output(project_dir, ["diff", "--cached", "--name-status"])
    if staged_status:
        changelog_lines = []
        added_files = []
        modified_files = []
        deleted_files = []
        other_files = []
        
        for line in staged_status.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            if len(parts) < 2:
                parts = line.split(None, 1)
            if len(parts) >= 2:
                status = parts[0].strip()
                path_info = parts[1:]
                
                status_char = status[0] if status else ''
                status_desc = "Modified"
                if status_char == 'A':
                    status_desc = "Added"
                    for p in path_info:
                        added_files.append(os.path.basename(p.strip()))
                elif status_char == 'D':
                    status_desc = "Deleted"
                    for p in path_info:
                        deleted_files.append(os.path.basename(p.strip()))
                elif status_char == 'R':
                    status_desc = "Renamed"
                    if len(path_info) >= 2:
                        other_files.append(os.path.basename(path_info[1].strip()))
                elif status_char == 'C':
                    status_desc = "Copied"
                    if len(path_info) >= 2:
                        other_files.append(os.path.basename(path_info[1].strip()))
                elif status_char == 'T':
                    status_desc = "Type changed"
                    for p in path_info:
                        other_files.append(os.path.basename(p.strip()))
                else:
                    for p in path_info:
                        modified_files.append(os.path.basename(p.strip()))
                
                if len(path_info) >= 2:
                    paths_str = " -> ".join(p.strip() for p in path_info)
                else:
                    paths_str = path_info[0].strip()
                changelog_lines.append(f"- {status_desc}: {paths_str}")
            else:
                changelog_lines.append(f"- Modified: {line}")
                modified_files.append(os.path.basename(line))
        
        # Determine the primary subject message
        primary_msg = commit_message.strip() if commit_message else ""
        if not primary_msg or primary_msg == "Update project":
            total_changes = len(added_files) + len(modified_files) + len(deleted_files) + len(other_files)
            if total_changes == 1:
                if added_files:
                    primary_msg = f"Add {added_files[0]}"
                elif deleted_files:
                    primary_msg = f"Delete {deleted_files[0]}"
                elif modified_files:
                    primary_msg = f"Update {modified_files[0]}"
                else:
                    primary_msg = f"Update {other_files[0]}"
            elif total_changes > 1:
                all_names = added_files + modified_files + deleted_files + other_files
                if len(all_names) <= 3:
                    primary_msg = f"Update {', '.join(all_names)}"
                else:
                    primary_msg = f"Update {', '.join(all_names[:2])} and {len(all_names) - 2} other files"
            else:
                primary_msg = "Update project"
                
        changelog_body = "Change Log:\n" + "\n".join(changelog_lines)
        
        run_git(project_dir, ["commit", "-m", primary_msg, "-m", changelog_body], log_callback)
        log(log_callback, "[OK] Commit created.\n")
    else:
        log(log_callback, "[INFO] Nothing new to commit.\n")

    if remote_url:
        run_git(project_dir, ["push", "-u", "origin", DEFAULT_BRANCH], log_callback)
        log(log_callback, "[OK] Push completed.\n")
    return True


def remote_url_for_repo(remote_base, repo_name):
    owner = resolve_github_owner(remote_base)
    if not owner:
        return ""
    return f"https://github.com/{owner}/{repo_name}.git"


def sync_cloud_project(task, log_callback=None):
    import os
    import subprocess
    action_type = task.get("action_type")
    repo_url = task.get("repo_url")
    local_path = task.get("local_path")
    repo_name = task.get("repo_name")
    
    if action_type == "skip":
        log(log_callback, f"[INFO] Skipped project: {repo_name}\n")
        return True
        
    if action_type == "clone":
        parent_dir = os.path.dirname(local_path)
        if parent_dir and not os.path.isdir(parent_dir):
            try:
                os.makedirs(parent_dir, exist_ok=True)
                log(log_callback, f"[INFO] Created parent directory: {parent_dir}\n")
            except OSError as e:
                log(log_callback, f"[ERROR] Failed to create directory {parent_dir}: {e}\n")
                return False
                
        cmd = ["git", "clone", repo_url, os.path.basename(local_path)]
        log(log_callback, f"$ {' '.join(cmd)} (in {parent_dir})\n")
        
        process = subprocess.run(
            cmd,
            cwd=parent_dir,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if process.stdout:
            log(log_callback, process.stdout)
        if process.stderr:
            log(log_callback, process.stderr)
            
        if process.returncode != 0:
            log(log_callback, f"[ERROR] Failed to clone {repo_name}\n")
            return False
            
        log(log_callback, f"[OK] Successfully cloned {repo_name} to {local_path}\n")
        log(log_callback, f"[INFO] Standardizing project layout for {repo_name}...\n")
        try:
            from .git_form import fix_project_git_form
            fix_project_git_form(local_path, log_callback)
        except Exception as e:
            log(log_callback, f"[WARN] Failed to standardize project layout: {e}\n")
            
        return True

    elif action_type == "pull":
        from .git_process import run_git
        log(log_callback, f"[INFO] Pulling updates for {repo_name}...\n")
        ok = run_git(local_path, ["pull", "origin", DEFAULT_BRANCH], log_callback)
        return ok

    elif action_type == "overwrite":
        from .git_process import run_git
        log(log_callback, f"[WARN] Overwriting local changes for {repo_name}...\n")
        run_git(local_path, ["fetch", "origin"], log_callback)
        ok1 = run_git(local_path, ["reset", "--hard", f"origin/{DEFAULT_BRANCH}"], log_callback)
        ok2 = run_git(local_path, ["pull", "origin", DEFAULT_BRANCH], log_callback)
        return ok1 and ok2

    elif action_type == "stash":
        from .git_process import run_git
        log(log_callback, f"[INFO] Stashing local changes and pulling for {repo_name}...\n")
        run_git(local_path, ["stash"], log_callback)
        ok = run_git(local_path, ["pull", "origin", DEFAULT_BRANCH], log_callback)
        run_git(local_path, ["stash", "pop"], log_callback, allow_fail=True)
        return ok

    return False
