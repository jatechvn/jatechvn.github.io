# 🤖 JA Auto Git — Liquid Glass Edition

<p align="center">
  <img src="../assets/images/icon.ico" alt="JA Auto Git Logo" width="120" height="120">
  <br>
  <i>面向开发者的自动化 Git 管理与智能 GitHub 仓库创建工具。</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=for-the-badge&logo=python&logoColor=white" alt="Python Version">
  <img src="https://img.shields.io/badge/GUI-PySide6-green.svg?style=for-the-badge&logo=qt&logoColor=white" alt="UI Framework">
  <img src="https://img.shields.io/badge/Integrations-GitHub_CLI-purple.svg?style=for-the-badge&logo=github&logoColor=white" alt="Integrations">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge" alt="License">
  <img src="https://img.shields.io/badge/Platform-Windows_%7C_macOS_%7C_Linux-0078D6.svg?style=for-the-badge&logo=windows&logoColor=white" alt="Platform">
  <img src="https://img.shields.io/badge/Version-1.5.0-orange.svg?style=for-the-badge" alt="Version">
</p>

<p align="center"><a href="#quick-start">🚀 快速开始</a> • <a href="#features">💡 功能特性</a> • <a href="#setup">📖 安装配置</a> • <a href="https://jatechvn.github.io/">🌐 官网</a></p>

<p align="center"><a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • 🇨🇳 中文 • <a href="README.ja-JP.md">🇯🇵 日本語</a> • <a href="README.es.md">🇪🇸 Español</a> • <a href="README.fr.md">🇫🇷 Français</a> • <a href="README.de.md">🇩🇪 Deutsch</a> • <a href="README.ru.md">🇷🇺 Русский</a> • <a href="README.pt.md">🇵🇹 Português</a> • <a href="README.ko.md">🇰🇷 한국어</a></p>

---

## 🌟 简介

**JA Auto Git** 是一款专业的 GUI 工具，可同时为多个子项目简化版本控制配置和 GitHub 远程存储流程。专为管理多个小型项目（Python 脚本、Node.js 包、AutoHotkey 脚本、.NET 应用）的开发者设计，只需几次点击即可自动完成目录规范化并将私有仓库部署到 GitHub。

凭借 **Liquid Glass** 设计风格和 macOS 风格的窗口控件，界面提供现代、直观的使用体验，在 Windows、macOS 和 Linux 上全面提升开发效率。

## 📸 界面截图

<p align="center">
  <img src="../assets/images/screenshot_dark.png" alt="JA Auto Git 深色主题" width="48%">
  <img src="../assets/images/screenshot_light.png" alt="JA Auto Git 浅色主题" width="48%">
</p>

---

## ✨ 核心功能

### 1. 🔍 动态项目扫描器
- **自动技术栈检测**：分析文件特征，自动识别项目类型。
- **递归扫描**：按配置深度递归扫描目录，自动忽略 `node_modules`、`.venv`、`__pycache__`、`dist`。
- **多核并行处理**：使用多线程保持界面响应流畅。
- **自动版本检测**：从 `package.json`、`pyproject.toml`、`setup.cfg`、`setup.py`、`*.csproj`、`constants.py`/`version.py`、`ABOUT.txt` 或最新 Git 标签中检测版本号 — 显示在**版本**列中。

### 2. 🛡️ 标准化项目结构（Git 表单）
- **绝对安全**：自动配置 `.gitignore` 文件，忽略凭据和许可证密钥。
- **多语言文档生成器**：创建 `README.md`（英文）及 `i18n/` 目录下的 9 个语言版本。
- **MIT 许可证生成器**：根据当前年份和作者姓名动态生成 `LICENSE` 文件。
- **推送工具**：在每个项目中包含 `git_push.bat` / `git_push.sh`。

### 3. 📝 智能自动变更日志提交引擎
- **自动主题生成**：提交消息为空时 → 自动从暂存差异中生成描述性主题。
- **结构化变更日志主体**：每次提交自动附加 `Change Log:` 部分，包含文件状态（`M`、`A`、`D`、`R`）。

### 4. 🚀 发布管理器 — 推送 GitHub Releases *(v1.5.0 新增)*
- **一键发布**：本地工作区标签页每个项目均有 **🚀 Release** 按钮。
- **自动标签生成**：自动从检测到的版本号填充标签（例如 `v1.5.0`）。
- **附件支持**：通过文件选择器附加构建文件（`.exe`、`.zip`、`.whl` 等）。
- **后台推送**：通过 `gh release create` 在后台线程中运行。
- **实时状态**：`⏳ Pushing...` → `✅ Released`。

### 5. ☁️ GitHub 云端标签页 — 提交记录与发布版本 *(v1.5.0 更新)*

#### 🕐 提交历史与下载
- 每个仓库均有 **🕐 Commits** 按钮 → 打开完整提交历史对话框。
- 每条提交记录提供 **⬇ sha** 下载按钮 → 下载至 `~/Downloads/{repo}_{sha7}.zip`。
- 下载后自动打开资源管理器并高亮显示文件。

#### 📦 发布版本浏览器与下载 *(v1.5.0 新增)*
- 每个仓库均有 **📦 Releases** 按钮 → 打开发布版本浏览器对话框。
- 列出所有 GitHub Releases：标签 · 日期 · 类型 · 附件数量。
- 每个附件均有下载按钮 → 下载至 `~/Downloads/`，下载后自动打开资源管理器。
- 如无附件则回退为源代码 ZIP。
- 通过 Qt Signal 实现线程安全的 UI 更新。

### 6. 🎨 Liquid Glass 界面
- 所有对话框均采用 macOS 风格交通灯窗口控件。
- 4/6 树形结构 + 2/6 控制台面板比例布局。
- 状态筛选按钮、项目隐藏、实时控制台。
- 提交记录与发布版本列使用固定宽度（`QHeaderView.Fixed`）。

### 7. ⚙️ 跨平台混合引擎
- 通过 `native_bridge.py` 原生适配 Windows / macOS / Linux。
- 自动回退至纯 Python 实现。

### 8. 🔄 自动云端同步与选择持久化
- 启动时在后台自动拉取，复选框状态持久化至 `config.ini`。

### 9. 👤 自动 Git 身份配置
- 自动从 GitHub 个人资料配置 `user.name` / `user.email`。

---

## 🚀 安装与配置

### 系统要求
| 组件 | 最低版本 | 备注 |
|---|---|---|
| Python | 3.13 | 需添加至 PATH |
| GitHub CLI (`gh`) | 2.92.0 | `gh auth login` |
| Git Credential Manager | 2.8.0 | 安全推送 |

### 快速安装
```cmd
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY
pip install -r requirements.txt
gh auth login
run.bat
```

---

## 📋 更新日志

### v1.5.0 *(最新版)*
- ✨ **发布管理器**：支持携带标签和附件推送 GitHub Releases
- ✨ **发布版本浏览器**：在云端标签页查看并下载 GitHub Releases
- ✨ **版本列**：自动检测项目版本号
- 🔧 **固定宽度按钮列**：调整窗口大小时不再拉伸

### v1.4.0
- ✨ **提交历史对话框**，支持按提交下载 ZIP
- ✨ **自动变更日志引擎**

### v1.3.0
- ✨ **跨平台混合引擎**
- ✨ **项目隐藏**功能，支持眼睛图标切换

---

## 📜 许可证与版权

MIT 许可证。版权所有 John Alaa @ 2026。
