import os
from configparser import ConfigParser

from .constants import DEFAULT_COMMIT_MESSAGE, DEFAULT_ROOT


APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_INI = os.path.join(APP_ROOT, "config.ini")


def load_settings():
    parser = ConfigParser(interpolation=None)
    parser.read(CONFIG_INI, encoding="utf-8")
    data = parser["DEFAULT"] if parser.defaults() else {}
    return {
        "last_root": expand_path(data.get("last_root", DEFAULT_ROOT)),
        "remote_base": data.get("remote_base", ""),
        "commit_message": "" if data.get("commit_message", DEFAULT_COMMIT_MESSAGE) == "Update project" else data.get("commit_message", DEFAULT_COMMIT_MESSAGE),
        "max_depth": safe_int(data.get("max_depth", 3), 3),
        "auto_create_repo": data.get("auto_create_repo", "yes").lower() in {"1", "yes", "true", "on"},
        "repo_public": data.get("repo_public", "no").lower() in {"1", "yes", "true", "on"},
        "last_explorer_path": expand_path(data.get("last_explorer_path", "")),
        "last_selected_projects": split_paths(data.get("last_selected_projects", "")),
        "last_selected_cloud_projects": split_paths(data.get("last_selected_cloud_projects", "")),
        "last_lang": data.get("last_lang", "en"),
        "hidden_projects": split_paths(data.get("hidden_projects", "")),
        "license_author": data.get("license_author", "John Alaa"),
    }


def save_settings(settings):
    parser = ConfigParser(interpolation=None)
    parser["DEFAULT"] = {
        "last_root": settings.get("last_root", DEFAULT_ROOT),
        "remote_base": settings.get("remote_base", ""),
        "commit_message": settings.get("commit_message", DEFAULT_COMMIT_MESSAGE),
        "max_depth": str(settings.get("max_depth", 3)),
        "auto_create_repo": "yes" if settings.get("auto_create_repo", True) else "no",
        "repo_public": "yes" if settings.get("repo_public", False) else "no",
        "last_explorer_path": settings.get("last_explorer_path", ""),
        "last_selected_projects": join_paths(settings.get("last_selected_projects", [])),
        "last_selected_cloud_projects": join_paths(settings.get("last_selected_cloud_projects", [])),
        "last_lang": settings.get("last_lang", "en"),
        "hidden_projects": join_paths(settings.get("hidden_projects", [])),
        "license_author": settings.get("license_author", "John Alaa"),
    }
    with open(CONFIG_INI, "w", encoding="utf-8") as file:
        parser.write(file)


def expand_path(path):
    return os.path.expandvars(os.path.expanduser(path or ""))


def safe_int(value, default):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def split_paths(value):
    return [item for item in (value or "").split("|") if item]


def join_paths(paths):
    return "|".join(path for path in paths if path)


def normalize_remote_base(remote_base):
    remote_base = (remote_base or "").strip().rstrip("/")
    if remote_base.endswith(".git"):
        remote_base = remote_base[:-4]
    if remote_base.startswith("https://github.com/"):
        remote_base = remote_base[len("https://github.com/"):].strip("/")
    return remote_base


def repo_url_for_project(remote_base, project_name):
    owner = normalize_remote_base(remote_base)
    if not owner:
        return ""
    if "/" in owner:
        owner = owner.split("/")[0]
    return f"https://github.com/{owner}/{project_name}.git"


def repo_name_for_project(project_path):
    return os.path.basename(os.path.abspath(project_path))



def language_suffix_for_project(project_path):
    current = os.path.abspath(project_path)
    while True:
        parent = os.path.basename(os.path.dirname(current))
        if parent.upper().startswith("PROJECT_"):
            raw = parent[len("PROJECT_"):]
            return sanitize_suffix(raw)
        next_current = os.path.dirname(current)
        if next_current == current:
            return ""
        current = next_current


def sanitize_suffix(value):
    value = (value or "").upper().strip()
    replacements = {
        "C#": "CS",
        "C_SHARP": "CS",
        "OPENCLAW_NODE_DEPLOY": "NODE",
    }
    value = replacements.get(value, value)
    cleaned = []
    for char in value:
        if char.isalnum():
            cleaned.append(char)
        elif cleaned and cleaned[-1] != "_":
            cleaned.append("_")
    return "".join(cleaned).strip("_")
