import fnmatch
import json
import os
import re

from .constants import DEFAULT_BRANCH, PROJECT_MARKERS, SKIP_DIRS
from .git_form import gitignore_is_standard
from .git_process import git_output
from .project_model import ProjectInfo


def scan_projects(root_dir, max_depth=3):
    root_dir = os.path.abspath(root_dir)
    if not os.path.isdir(root_dir):
        raise FileNotFoundError(f"Root folder not found: {root_dir}")

    projects = []
    for current, dirs, files in os.walk(root_dir):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        depth = relative_depth(root_dir, current)
        if depth > max_depth:
            dirs[:] = []
            continue

        kind = detect_project_kind(current, files)
        if kind:
            projects.append(inspect_project(current, kind))
            dirs[:] = [d for d in dirs if d not in {"modules", "assets", "src"}]

    return sorted(projects, key=lambda item: item.path.lower())


def inspect_project(project_dir, kind=None):
    project_dir = os.path.abspath(project_dir)
    has_git = os.path.isdir(os.path.join(project_dir, ".git"))
    branch = git_output(project_dir, ["branch", "--show-current"]) if has_git else ""
    remote_url = git_output(project_dir, ["remote", "get-url", "origin"]) if has_git else ""
    clean = git_output(project_dir, ["status", "--short"]) == "" if has_git else True

    has_gitignore = os.path.isfile(os.path.join(project_dir, ".gitignore"))
    gitignore_ok = gitignore_is_standard(project_dir)
    push_bat_ok = os.path.isfile(os.path.join(project_dir, "git_push.bat"))
    readme_ok = os.path.isfile(os.path.join(project_dir, "README.md"))
    license_ok = os.path.isfile(os.path.join(project_dir, "LICENSE"))
    about_ok = os.path.isfile(os.path.join(project_dir, "ABOUT.txt"))
    has_remote = bool(remote_url)
    standard_ok = has_git and branch == DEFAULT_BRANCH and gitignore_ok and push_bat_ok and readme_ok and license_ok and about_ok
    status = build_status(has_git, branch, has_remote, clean, gitignore_ok, push_bat_ok, readme_ok, license_ok, about_ok, has_gitignore)
    version = detect_version(project_dir, has_git)

    return ProjectInfo(
        name=os.path.basename(project_dir),
        path=project_dir,
        kind=kind or detect_project_kind(project_dir, os.listdir(project_dir)) or "project",
        has_git=has_git,
        branch=branch,
        has_remote=has_remote,
        remote_url=remote_url,
        clean=clean,
        gitignore_ok=gitignore_ok,
        push_bat_ok=push_bat_ok,
        readme_ok=readme_ok,
        license_ok=license_ok,
        about_ok=about_ok,
        has_gitignore=has_gitignore,
        standard_ok=standard_ok,
        status=status,
        version=version,
    )


def detect_version(project_dir: str, has_git: bool = False) -> str:
    """
    Detect the version of a project by probing common version sources in order:
      1. package.json          (Node.js)
      2. pyproject.toml        (Python modern)
      3. setup.cfg             (Python classic)
      4. setup.py              (Python legacy, regex)
      5. *.csproj              (.NET)
      6. constants.py / version.py / __version__.py  (any Python app)
      7. ABOUT.txt             (custom, e.g. "Version: 1.2.3")
      8. Latest git tag        (fallback)
    Returns empty string if nothing found.
    """
    p = project_dir

    # 1. package.json
    pkg = os.path.join(p, "package.json")
    if os.path.isfile(pkg):
        try:
            with open(pkg, encoding="utf-8") as f:
                data = json.load(f)
            v = data.get("version", "")
            if v:
                return v
        except Exception:
            pass

    # 2. pyproject.toml
    ppt = os.path.join(p, "pyproject.toml")
    if os.path.isfile(ppt):
        try:
            with open(ppt, encoding="utf-8") as f:
                content = f.read()
            m = re.search(r'^\s*version\s*=\s*["\']([^"\']+)["\']', content, re.MULTILINE)
            if m:
                return m.group(1)
        except Exception:
            pass

    # 3. setup.cfg
    scfg = os.path.join(p, "setup.cfg")
    if os.path.isfile(scfg):
        try:
            with open(scfg, encoding="utf-8") as f:
                content = f.read()
            m = re.search(r'^\s*version\s*=\s*(.+)', content, re.MULTILINE)
            if m:
                v = m.group(1).strip()
                if v and not v.startswith("attr:") and not v.startswith("file:"):
                    return v
        except Exception:
            pass

    # 4. setup.py (regex on version= argument)
    spy = os.path.join(p, "setup.py")
    if os.path.isfile(spy):
        try:
            with open(spy, encoding="utf-8") as f:
                content = f.read()
            m = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
            if m:
                return m.group(1)
        except Exception:
            pass

    # 5. *.csproj — first match
    try:
        for fname in os.listdir(p):
            if fname.endswith(".csproj"):
                with open(os.path.join(p, fname), encoding="utf-8") as f:
                    content = f.read()
                m = re.search(r'<Version>([^<]+)</Version>', content)
                if m:
                    return m.group(1).strip()
                m = re.search(r'<AssemblyVersion>([^<]+)</AssemblyVersion>', content)
                if m:
                    return m.group(1).strip()
    except Exception:
        pass

    # 6. constants.py / version.py / __version__.py — look for APP_VERSION or __version__
    for fname in ("constants.py", "version.py", "__version__.py", "_version.py"):
        fpath = os.path.join(p, fname)
        if not os.path.isfile(fpath):
            # also check in modules/
            fpath = os.path.join(p, "modules", fname)
        if os.path.isfile(fpath):
            try:
                with open(fpath, encoding="utf-8") as f:
                    content = f.read()
                # APP_VERSION = "x.y.z"
                m = re.search(r'APP_VERSION\s*=\s*["\']([^"\']+)["\']', content)
                if m:
                    return m.group(1)
                # __version__ = "x.y.z"
                m = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
                if m:
                    return m.group(1)
                # VERSION = "x.y.z"
                m = re.search(r'\bVERSION\s*=\s*["\']([^"\']+)["\']', content)
                if m:
                    return m.group(1)
            except Exception:
                pass

    # 7. ABOUT.txt — look for "Version: x.y.z"
    about = os.path.join(p, "ABOUT.txt")
    if os.path.isfile(about):
        try:
            with open(about, encoding="utf-8") as f:
                content = f.read()
            m = re.search(r'[Vv]ersion\s*[:\-]\s*([\d][^\s]+)', content)
            if m:
                return m.group(1).strip()
        except Exception:
            pass

    # 8. Latest git tag as fallback
    if has_git:
        try:
            tag = git_output(project_dir, ["describe", "--tags", "--abbrev=0"])
            if tag:
                return tag
        except Exception:
            pass

    return ""


def detect_project_kind(project_dir, names):
    name_set = set(names)
    for kind, markers in PROJECT_MARKERS.items():
        for marker in markers:
            if "*" in marker:
                if any(fnmatch.fnmatch(name.lower(), marker.lower()) for name in name_set):
                    return kind
            elif marker in name_set:
                return kind
    if os.path.isdir(os.path.join(project_dir, ".git")):
        return "git"
    return ""


def build_status(has_git, branch, has_remote, clean, gitignore_ok, push_bat_ok, readme_ok, license_ok, about_ok, has_gitignore):
    missing = []
    if not has_git:
        missing.append(".git")
    if has_git and branch != DEFAULT_BRANCH:
        missing.append("branch main")
    if not has_gitignore:
        missing.append(".gitignore")
    elif not gitignore_ok:
        missing.append(".gitignore (non-standard)")
    if not push_bat_ok:
        missing.append("git_push.bat")
    if not readme_ok:
        missing.append("README.md")
    if not license_ok:
        missing.append("LICENSE")
    if not about_ok:
        missing.append("ABOUT.txt")
    if has_git and not has_remote:
        missing.append("remote")
    if has_git and not clean:
        missing.append("uncommitted")
    return "OK" if not missing else "Missing: " + ", ".join(missing)


def relative_depth(root_dir, path):
    rel = os.path.relpath(path, root_dir)
    if rel == ".":
        return 0
    return len(rel.split(os.sep))
