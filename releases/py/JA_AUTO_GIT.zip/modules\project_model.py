from dataclasses import dataclass, field


@dataclass
class ProjectInfo:
    name: str
    path: str
    kind: str
    has_git: bool
    branch: str
    has_remote: bool
    remote_url: str
    clean: bool
    gitignore_ok: bool
    push_bat_ok: bool
    readme_ok: bool
    license_ok: bool
    about_ok: bool
    has_gitignore: bool
    standard_ok: bool
    status: str
    version: str = ""          # detected from package files or git tags
