# -*- coding: utf-8 -*-
# modules/native/linux_core.py
import ctypes
import os
import logging

logger = logging.getLogger(__name__)

class LinuxNativeEngine:
    def __init__(self):
        self.so = None
        self._load_native_library()

    def _load_native_library(self):
        """Nạp file .so C++/Rust được biên dịch riêng cho Linux để chạy cực nhanh"""
        so_path = os.path.join(os.path.dirname(__file__), "core_linux.so")
        if os.path.exists(so_path):
            try:
                self.so = ctypes.CDLL(so_path)
                logger.info("[NATIVE] Successfully loaded Linux core_linux.so.")
            except Exception as e:
                logger.warning(f"[NATIVE] Failed to load Linux SO: {e}")
        else:
            logger.debug("[NATIVE] Linux core_linux.so not found. Using scripting fallbacks.")

    def heavy_compute(self, data_input):
        if self.so:
            try:
                # Nếu có SO gánh, gọi hàm C++ chạy tẹt ga
                # return self.so.fast_process(data_input)
                pass
            except Exception as e:
                logger.error(f"[NATIVE] Error calling SO function: {e}")
        
        # Nếu không có file SO đi kèm, dùng lệnh tối ưu riêng của Linux (Bash script)
        return "Linux Optimized Result"
