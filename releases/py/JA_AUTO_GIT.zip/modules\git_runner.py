from PySide6.QtCore import QObject, Signal

from .git_actions import commit_and_push_project
from .git_form import fix_project_git_form
from .project_scan import scan_projects


class GitRunner(QObject):
    log_received = Signal(str)
    scan_finished = Signal(list)
    cloud_scan_finished = Signal(list)
    progress_updated = Signal(int)
    operation_finished = Signal(bool, str)

    def fetch_cloud_repositories(self, remote_base, root_dir):
        try:
            from .github_ops import get_github_repositories
            from .git_process import git_output
            import os
            import subprocess

            self.log_received.emit("[INFO] Fetching repository list from GitHub...\n")
            repos = get_github_repositories(remote_base, self.log_received.emit)
            if not repos:
                self.log_received.emit("[WARN] No repositories fetched or GitHub CLI error.\n")
                self.cloud_scan_finished.emit([])
                return

            self.log_received.emit(f"[OK] Fetched {len(repos)} repositories from GitHub.\n")
            self.log_received.emit("[INFO] Checking local synchronization status for fetched repositories...\n")

            total = len(repos)
            cloud_projects = []

            for index, repo in enumerate(repos, start=1):
                name = repo.get("name", "")
                url = repo.get("url", "")
                updated_at = repo.get("updatedAt", "")
                primary_lang = (repo.get("primaryLanguage") or {}).get("name", "") if repo.get("primaryLanguage") else ""

                # 1. First search if a folder with the same name already exists locally under root or subfolders
                found_local_path = None
                subfolders = ["", "PROJECT_PY", "PROJECT_C#", "PROJECT_AHK", "PROJECT_JS", "PROJECT_PS1"]
                for sf in subfolders:
                    path_cand = os.path.join(root_dir, sf, name) if sf else os.path.join(root_dir, name)
                    if os.path.isdir(path_cand):
                        found_local_path = path_cand
                        break

                if found_local_path:
                    local_path = found_local_path
                    parent_dir_name = os.path.basename(os.path.dirname(local_path))
                    if parent_dir_name == "PROJECT_PY":
                        kind = "python"
                    elif parent_dir_name == "PROJECT_C#":
                        kind = "c#"
                    elif parent_dir_name == "PROJECT_AHK":
                        kind = "ahk"
                    elif parent_dir_name == "PROJECT_JS":
                        kind = "node"
                    elif parent_dir_name == "PROJECT_PS1":
                        kind = "powershell"
                    else:
                        kind = "project"
                else:
                    # 2. If not found locally, classify based on suffix or primaryLanguage
                    name_upper = name.upper()
                    subfolder = ""
                    kind = "project"

                    if name_upper.endswith("_PY"):
                        subfolder = "PROJECT_PY"
                        kind = "python"
                    elif name_upper.endswith("_CS"):
                        subfolder = "PROJECT_C#"
                        kind = "c#"
                    elif name_upper.endswith("_AHK"):
                        subfolder = "PROJECT_AHK"
                        kind = "ahk"
                    elif name_upper.endswith("_NODE"):
                        subfolder = "PROJECT_JS"
                        kind = "node"
                    elif name_upper.endswith("_PS1"):
                        subfolder = "PROJECT_PS1"
                        kind = "powershell"
                    elif primary_lang:
                        lang_lower = primary_lang.lower()
                        if "python" in lang_lower:
                            subfolder = "PROJECT_PY"
                            kind = "python"
                        elif "c#" in lang_lower:
                            subfolder = "PROJECT_C#"
                            kind = "c#"
                        elif "autohotkey" in lang_lower or "ahk" in lang_lower or "autoit" in lang_lower:
                            subfolder = "PROJECT_AHK"
                            kind = "ahk"
                        elif "javascript" in lang_lower or "typescript" in lang_lower or "node" in lang_lower:
                            subfolder = "PROJECT_JS"
                            kind = "node"
                        elif "powershell" in lang_lower or "batch" in lang_lower:
                            subfolder = "PROJECT_PS1"
                            kind = "powershell"

                    if subfolder:
                        local_path = os.path.join(root_dir, subfolder, name)
                    else:
                        local_path = os.path.join(root_dir, name)

                sync_status = "Not Cloned"

                if os.path.isdir(local_path):
                    # Check git status
                    is_git = os.path.isdir(os.path.join(local_path, ".git"))
                    if not is_git:
                        sync_status = "Local Modified" # No git but directory exists
                    else:
                        clean = git_output(local_path, ["status", "--short"]) == ""
                        if not clean:
                            sync_status = "Local Modified"
                        else:
                            # Clean, check ahead/behind
                            # Run git fetch in background
                            subprocess.run(["git", "fetch", "origin"], cwd=local_path, capture_output=True)
                            branch = git_output(local_path, ["branch", "--show-current"]) or "main"
                            # Count behind/ahead
                            out = git_output(local_path, ["rev-list", "--left-right", "--count", f"{branch}...origin/{branch}"])
                            if out:
                                parts = out.strip().split()
                                if len(parts) == 2:
                                    try:
                                        behind = int(parts[1])
                                        if behind > 0:
                                            sync_status = "Needs Pull"
                                        else:
                                            sync_status = "Up to date"
                                    except ValueError:
                                        sync_status = "Up to date"
                                else:
                                    sync_status = "Up to date"
                            else:
                                sync_status = "Up to date"
                else:
                    sync_status = "Not Cloned"

                cloud_projects.append({
                    "name": name,
                    "kind": kind,
                    "url": url,
                    "updated_at": updated_at,
                    "local_path": local_path,
                    "sync_status": sync_status,
                    "is_private": repo.get("isPrivate", True),
                })
                self.progress_updated.emit(int(index * 100 / total))

            self.cloud_scan_finished.emit(cloud_projects)
        except Exception as exc:
            self.log_received.emit(f"[ERROR] Comparing statuses failed: {exc}\n")
            self.cloud_scan_finished.emit([])

    def sync_cloud_projects(self, sync_tasks):
        from .git_actions import sync_cloud_project
        total = max(len(sync_tasks), 1)
        ok_count = 0
        try:
            for index, task in enumerate(sync_tasks, start=1):
                repo_name = task.get("repo_name", "")
                action_type = task.get("action_type", "")
                self.log_received.emit(f"\n[SYNC {action_type.upper()}] {repo_name}\n")
                ok = sync_cloud_project(task, self.log_received.emit)
                ok_count += 1 if ok else 0
                self.progress_updated.emit(int(index * 100 / total))
            self.operation_finished.emit(ok_count == len(sync_tasks), f"{ok_count}/{len(sync_tasks)} sync tasks done")
        except Exception as exc:
            self.log_received.emit(f"[ERROR] Sync failed: {exc}\n")
            self.operation_finished.emit(False, str(exc))

    def scan(self, root_dir, max_depth=3):
        try:
            projects = scan_projects(root_dir, max_depth=max_depth)
            self.scan_finished.emit([p.__dict__ for p in projects])
        except Exception as exc:
            self.log_received.emit(f"[ERROR] Scan failed: {exc}\n")
            self.scan_finished.emit([])

    def fix_projects(self, project_paths):
        self._run_many(project_paths, fix_project_git_form, "fix")

    def push_projects(self, project_paths, remote_base, commit_message, auto_create_repo=False, is_public=False):
        def action(path, log_callback):
            return commit_and_push_project(path, remote_base, commit_message, log_callback, auto_create_repo, is_public)

        self._run_many(project_paths, action, "push")

    def _run_many(self, project_paths, action, label):
        total = max(len(project_paths), 1)
        ok_count = 0
        try:
            for index, path in enumerate(project_paths, start=1):
                self.log_received.emit(f"\n[{label.upper()}] {path}\n")
                ok = action(path, self.log_received.emit)
                ok_count += 1 if ok else 0
                self.progress_updated.emit(int(index * 100 / total))
            self.operation_finished.emit(ok_count == len(project_paths), f"{ok_count}/{len(project_paths)} done")
        except Exception as exc:
            self.log_received.emit(f"[ERROR] {exc}\n")
            self.operation_finished.emit(False, str(exc))

    def rename_cloud_repo(self, remote_base, old_name, new_name):
        try:
            from .github_ops import resolve_github_owner, find_github_cli
            import subprocess
            gh = find_github_cli()
            if not gh:
                self.log_received.emit("[ERROR] GitHub CLI 'gh' not found. Cannot rename cloud repository.\n")
                self.operation_finished.emit(False, "gh CLI not found")
                return
            owner = resolve_github_owner(remote_base)
            full_name = f"{owner}/{old_name}"
            
            self.log_received.emit(f"[CLOUD RENAME] Renaming repository {full_name} -> {new_name}...\n")
            cmd = [gh, "repo", "rename", new_name, "-R", full_name, "-y"]
            self.log_received.emit(f"$ {' '.join(cmd)}\n")
            
            res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
            if res.returncode == 0:
                self.log_received.emit(f"[OK] Renamed cloud repository to {new_name}.\n")
                self.operation_finished.emit(True, f"Renamed to {new_name}")
            else:
                self.log_received.emit(f"[ERROR] Failed to rename: {res.stderr}\n")
                self.operation_finished.emit(False, res.stderr.strip() or "Rename failed")
        except Exception as exc:
            self.log_received.emit(f"[ERROR] Rename failed: {exc}\n")
            self.operation_finished.emit(False, str(exc))

    def delete_cloud_repos(self, remote_base, repo_names):
        try:
            from .github_ops import resolve_github_owner, find_github_cli
            import subprocess
            gh = find_github_cli()
            if not gh:
                self.log_received.emit("[ERROR] GitHub CLI 'gh' not found. Cannot delete cloud repository.\n")
                self.operation_finished.emit(False, "gh CLI not found")
                return
            owner = resolve_github_owner(remote_base)
            
            total = len(repo_names)
            ok_count = 0
            for index, name in enumerate(repo_names, start=1):
                full_name = f"{owner}/{name}"
                self.log_received.emit(f"[CLOUD DELETE] Deleting repository {full_name}...\n")
                cmd = [gh, "repo", "delete", full_name, "--yes"]
                self.log_received.emit(f"$ {' '.join(cmd)}\n")
                
                res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
                if res.returncode == 0:
                    self.log_received.emit(f"[OK] Deleted cloud repository {full_name}.\n")
                    ok_count += 1
                else:
                    self.log_received.emit(f"[ERROR] Failed to delete: {res.stderr}\n")
                self.progress_updated.emit(int(index * 100 / total))
                
            self.operation_finished.emit(ok_count == total, f"Deleted {ok_count}/{total} repositories")
        except Exception as exc:
            self.log_received.emit(f"[ERROR] Delete failed: {exc}\n")
            self.operation_finished.emit(False, str(exc))

    def change_cloud_repos_visibility(self, remote_base, repo_items):
        try:
            from .github_ops import resolve_github_owner, find_github_cli
            import subprocess
            gh = find_github_cli()
            if not gh:
                self.log_received.emit("[ERROR] GitHub CLI 'gh' not found. Cannot edit repository visibility.\n")
                self.operation_finished.emit(False, "gh CLI not found")
                return
            owner = resolve_github_owner(remote_base)
            
            total = len(repo_items)
            ok_count = 0
            for index, (name, vis) in enumerate(repo_items, start=1):
                full_name = f"{owner}/{name}"
                self.log_received.emit(f"[CLOUD VISIBILITY] Changing {full_name} to {vis.upper()}...\n")
                cmd = [gh, "repo", "edit", full_name, "--visibility", vis, "--accept-visibility-change-consequences"]
                self.log_received.emit(f"$ {' '.join(cmd)}\n")
                
                res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
                if res.returncode == 0:
                    self.log_received.emit(f"[OK] Changed visibility of {full_name} to {vis}.\n")
                    ok_count += 1
                else:
                    self.log_received.emit(f"[ERROR] Failed to change visibility: {res.stderr}\n")
                self.progress_updated.emit(int(index * 100 / total))
                
            self.operation_finished.emit(ok_count == total, f"Updated visibility of {ok_count}/{total} repositories")
        except Exception as exc:
            self.log_received.emit(f"[ERROR] Visibility update failed: {exc}\n")
            self.operation_finished.emit(False, str(exc))
