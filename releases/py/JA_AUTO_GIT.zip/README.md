# 🤖 JA Auto Git — Liquid Glass Edition

<p align="center">
  <img src="assets/images/icon.ico" alt="JA Auto Git Logo" width="120" height="120">
  <br>
  <i>Automated Git management & smart GitHub Repository creator for developers.</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=for-the-badge&logo=python&logoColor=white" alt="Python Version">
  <img src="https://img.shields.io/badge/GUI-PySide6-green.svg?style=for-the-badge&logo=qt&logoColor=white" alt="UI Framework">
  <img src="https://img.shields.io/badge/Integrations-GitHub_CLI-purple.svg?style=for-the-badge&logo=github&logoColor=white" alt="Integrations">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge" alt="License">
  <img src="https://img.shields.io/badge/Platform-Windows_%7C_macOS_%7C_Linux-0078D6.svg?style=for-the-badge&logo=windows&logoColor=white" alt="Platform">
  <img src="https://img.shields.io/badge/Version-1.5.0-orange.svg?style=for-the-badge" alt="Version">
</p>

<p align="center"><a href="#quick-start">🚀 Quick Start</a> • <a href="#features">💡 Features</a> • <a href="#setup">📖 Setup</a> • <a href="https://jatechvn.github.io/">🌐 Website</a></p>

<p align="center">🇺🇸 English • <a href="i18n/README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="i18n/README.zh-CN.md">🇨🇳 中文</a> • <a href="i18n/README.ja-JP.md">🇯🇵 日本語</a> • <a href="i18n/README.es.md">🇪🇸 Español</a> • <a href="i18n/README.fr.md">🇫🇷 Français</a> • <a href="i18n/README.de.md">🇩🇪 Deutsch</a> • <a href="i18n/README.ru.md">🇷🇺 Русский</a> • <a href="i18n/README.pt.md">🇵🇹 Português</a> • <a href="i18n/README.ko.md">🇰🇷 한국어</a></p>

---

<a id="introduction"></a>
## 🌟 Introduction

**JA Auto Git** is a professional GUI tool that simplifies version control setup and GitHub remote storage for multiple sub-projects simultaneously. Designed for developers managing multiple mini-projects (Python scripts, Node.js packages, AutoHotkey scripts, .NET apps), it automates directory standardization and private repository deployment to GitHub with a few clicks.

With its **Liquid Glass** design style and macOS-inspired window controls, the interface delivers a modern, intuitive experience that maximizes developer productivity across Windows, macOS, and Linux.

## 📸 Screenshots

<p align="center">
  <img src="assets/images/screenshot_dark.png" alt="JA Auto Git Dark Theme" width="48%">
  <img src="assets/images/screenshot_light.png" alt="JA Auto Git Light Theme" width="48%">
</p>

---

<a id="workflow"></a>
## 📊 Workflow

```mermaid
graph TD
    A[Launch JA Auto Git] --> B[Scan working directory up to max depth]
    B --> C[Analyze & detect project types + versions]
    C --> D{Check project status}
    D -->|Missing .git / gitignore / README / LICENSE| E[Show warning in UI tree]
    D -->|Standard files present| F[Show Standard OK status]
    E --> G[User selects projects → CREATE / EDIT GIT FORM]
    G --> H[Init Git · create .gitignore · write LICENSE · generate 10-lang READMEs]
    H --> I[User types Commit Message or leaves blank for auto-message]
    I --> J[Auto-generate subject + structured Change Log from staged diff]
    J --> K[Auto-create Private Repo on GitHub if missing · Push via GitHub CLI]
    K --> L[Update status · Auto-sync Cloud tab]
    L --> M{GitHub Cloud tab}
    M --> N[View per-repo Commit History · Download any commit ZIP]
    M --> O[View GitHub Releases · Download release assets to ~/Downloads]
    K --> P[Push GitHub Release with tag + assets via Release Manager]
```

---

<a id="features"></a>
## ✨ Key Features

### 1. 🔍 Dynamic Project Scanner
- **Auto Tech Stack Detection**: Analyzes file signatures to identify the project type (Python, Node.js, AHK, .NET, Batch/PowerShell).
- **Recursive Scan**: Scans directories up to a configured depth, automatically ignoring large system/dependency directories such as `node_modules`, `.venv`, `__pycache__`, `dist`.
- **Multi-core Parallel Processing**: Scan operations leverage multi-threading to utilize all available CPU cores simultaneously, keeping the UI fully responsive.
- **Auto Version Detection**: Automatically detects each project's version from `package.json`, `pyproject.toml`, `setup.cfg`, `setup.py`, `*.csproj`, `constants.py`/`version.py`, `ABOUT.txt`, or the latest Git tag — displayed in the **Version** column.

### 2. 🛡️ Standardized Project Structure (Git Form)
- **Absolute Security**: Automatically configures language-specific `.gitignore` files, ignoring credentials and license keys (e.g. `license.key`) by default.
- **Multi-language Document Generator**: Automatically creates a root `README.md` (English) and **9 popular language** versions in `i18n/` with cross-linked navigation bars.
- **MIT License Generator**: Generates a standard `LICENSE` file dynamically using the current year and configured author name (customizable via UI / `config.ini`).
- **Push Utility**: Includes a `git_push.bat` / `git_push.sh` script in each sub-project for quick manual pushing.

### 3. 📝 Smart Auto-Changelog Commit Engine
- **Auto Subject Generation**: Leave the commit message blank (or as the placeholder) and the app automatically generates a descriptive subject line such as `"Update main.py, utils.py and 3 other files"` by parsing the staged diff.
- **Structured Change Log Body**: Every commit automatically appends a `Change Log:` section listing all modified, added, and deleted files with their status (`M`, `A`, `D`, `R`).
- **Legacy Migration**: Existing settings using the old default `"Update project"` message are silently migrated to the new empty/auto-commit workflow.

Example auto-generated commit message:
```
Update main.py, config.ini and 2 other files

Change Log:
  M  modules/git_actions.py
  M  modules/ui/main_window.py
  A  modules/ui/dialogs.py
  D  temp_debug.txt
```

### 4. 🚀 Release Manager — Push GitHub Releases *(New in v1.5.0)*
- **One-Click Release**: Each project row with Git + remote configured shows a **🚀 Release** button in the Local Workspace tab.
- **Auto Tag Generation**: The Release Manager auto-fills the tag name from the detected project version (e.g. `v1.5.0`).
- **Asset Attachment**: Attach any build files (`.exe`, `.zip`, `.whl`, etc.) to the release with a file picker.
- **Background Push**: Release creation runs in a background thread via `gh release create`, keeping the UI responsive.
- **Real-time Status**: Button states update live: `⏳ Pushing...` → `✅ Released` on success, with error tooltip on failure.

### 5. ☁️ GitHub Cloud Tab — Commits & Releases *(Updated in v1.5.0)*

#### 🕐 Commit History & Download
- **Per-Repo Commit History**: Every project row shows a **🕐 Commits** button that opens a full commit history dialog.
- **Commit History Dialog**: Frameless macOS-style dialog displaying SHA · Tag/Version badge · Author · Date · Subject (hover for full message).
- **Per-Commit ZIP Download**: Each commit row has a **⬇ sha** button that:
  1. Downloads the snapshot ZIP directly to `~/Downloads/{repo}_{sha7}.zip` via GitHub CLI.
  2. After download, opens **Explorer with the file highlighted** (`explorer /select,file`).
  3. Skips re-download if the file already exists locally.
  4. Real-time button states: `⏳ Downloading...` → `✅ sha7` on success.

#### 📦 Release Browser & Download *(New in v1.5.0)*
- **Per-Repo Release List**: Every project row shows a **📦 Releases** button opening a dedicated Release Browser dialog.
- **Release Browser Dialog**: Frameless macOS-style dialog listing all GitHub Releases with:
  - Tag / Name · Date · Type (Stable / Pre-release / Draft) · Asset count
- **Per-Asset Download**: Each release row shows download buttons for each attached asset (up to 3 visible):
  - Downloads directly to `~/Downloads/` via `urllib`.
  - Falls back to **source ZIP** download if no assets are attached.
  - Opens Explorer with the file highlighted after download.
  - Real-time button states: `⏳` → `✅ Done` on success, `⬇ Retry` on failure.
- **Thread-safe UI Updates**: All download operations use Qt `Signal` emission from worker threads.

### 6. 🎨 Liquid Glass UI — Layout & Controls
- **Optimized Panel Ratios**: The Project Git Status Tree occupies **4/6** of the right panel height; the Live Git Console occupies **2/6** — giving the tree significantly more display area.
- **Unified Console Header**: The "LIVE GIT CONSOLE" label and the "Clear Console" button now share a single toolbar row.
- **macOS-style Window Controls**: All dialogs feature red/green traffic-light buttons (🔴 Close, 🟢 Maximize/Restore), frameless rounded-corner layout, and drag-to-move support.
- **Status Filtering**: Filtering buttons (`Has .git`, `No .git`, `Missing Form`, `Not Cloned`, `Behind Cloud`) for quick selection.
- **Project Hiding (Eye Toggle)**: Hide unwanted projects from tree and sidebar with persistence in `config.ini`.
- **Live Console**: Displays real-time output of all background Git operations.
- **Fixed-Width Button Columns**: Commits and Releases columns use `QHeaderView.Fixed` mode — they never stretch when the window is resized or maximized.

### 7. ⚙️ Cross-Platform Hybrid Engine Core
- **Dynamic OS Routing**: Detects the host OS at runtime (Windows, macOS, Linux) and routes system operations to platform-native optimized components via `native_bridge.py`.
  - **Windows**: Win32 API / PowerShell / optional C++ DLL (`modules/native/win_core.py`)
  - **macOS**: Objective-C / AppleScript / optional `.dylib` (`modules/native/mac_core.py`)
  - **Linux**: Bash / optional `.so` shared library (`modules/native/linux_core.py`)
- **Safe Execution Fallback**: Automatically falls back to pure Python if native components are absent — zero crashes, maximum compatibility.
- **Cross-Platform Startup Scripts**: `run.bat` / `run.sh` and `setup_venv.sh` provided for Windows and Unix-family systems.

```
modules/
├── ui/                        # PySide6 GUI layer
├── native/                    # Hybrid Engine Core
│   ├── win_core.py            # Windows: Win32 API, DLL, PowerShell
│   ├── mac_core.py            # macOS: Objective-C, dylib, AppleScript
│   └── linux_core.py          # Linux: Bash, .so shared library
├── native_bridge.py           # Dynamic OS router (singleton)
├── git_actions.py             # Git operations + auto-changelog
├── github_ops.py              # GitHub CLI + commit/release API
├── project_scan.py            # Project scanner + version detector
├── project_model.py           # ProjectInfo dataclass
├── git_runner.py              # Background thread runner
├── constants.py               # App-wide constants (APP_VERSION)
└── utils.py / i18n_ui.py      # Settings + 10-language translations
```

### 8. 🔄 Automatic Cloud Sync & Selection Persistence
- **Auto Cloud Fetch on Startup**: Retrieves GitHub cloud repository statuses in the background after local scan.
- **Selection Persistence**: Remembers checkbox states across runs via `config.ini`.
- **Multi-commit View Per Repo**: Full commit history (up to 30 commits, with tag annotations) on demand.

### 9. 👤 Automatic Git Identity Setup
- **Zero-Config Commit**: Detects missing Git `user.name` / `user.email` and configures them automatically from the GitHub profile via `gh`.

---

<a id="setup"></a>
## 🚀 Installation & Setup

### System Requirements

| Component | Minimum Version | Notes |
|---|---|---|
| Python | 3.13 | Ensure "Add Python to PATH" is checked |
| GitHub CLI (`gh`) | 2.92.0 | Authenticate via `gh auth login` |
| Git Credential Manager | 2.8.0 | Secure push authentication |

> ⚠️ **Important**: If a system environment variable `GITHUB_TOKEN` is set with an expired or invalid value, the app automatically strips it before calling `gh api` to prevent authentication failures.

<a id="quick-start"></a>
### Step-by-Step Installation

#### Step 1: Install prerequisites

1. **Python 3.13+** — [Download (official)](https://www.python.org/downloads/)
2. **GitHub CLI 2.92.0** — avoid terminal injection vulnerabilities in older versions:
   - [Download gh_2.92.0_windows_amd64.msi](https://github.com/cli/cli/releases/download/v2.92.0/gh_2.92.0_windows_amd64.msi)
3. **Git Credential Manager 2.8.0**:
   - [Download gcm-win-x64-2.8.0.exe](https://github.com/git-ecosystem/git-credential-manager/releases/download/v2.8.0/gcm-win-x64-2.8.0.exe)

#### Step 2: Clone the repository
```cmd
git clone https://github.com/jatechvn/JA_AUTO_GIT_PY.git
cd JA_AUTO_GIT_PY
```

#### Step 3: Install Python dependencies
```cmd
pip install -r requirements.txt
```

#### Step 4: Authenticate GitHub CLI
```cmd
gh auth login
```
*(Select browser or SSH authentication based on your preference.)*

#### Step 5: Launch the application

**Windows:**
```cmd
run.bat
```
**macOS / Linux:**
```bash
chmod +x run.sh && ./run.sh
```

---

<a id="config"></a>
## ⚙️ Configuration

### `config.ini` — Main Settings
```ini
[settings]
root_dir       = D:\Workspaces\MyProjects   ; Root directory to scan
remote_base    = github.com/username         ; Your GitHub username
branch         = main                        ; Default branch
commit_message =                             ; Empty = auto-generate subject & changelog
max_depth      = 3                           ; Maximum scan depth
auto_create_repo = yes                       ; Auto-create GitHub repo if missing
```

> 💡 **Tip**: Leave `commit_message` empty to activate **Auto-Changelog** mode. The app will generate a descriptive subject and full `Change Log:` body automatically from the staged diff.

### `config.json` — Advanced Sync Settings
```json
{
  "git": {
    "default_branch": "main",
    "default_commit_message": "",
    "auto_create_github_repo": true
  }
}
```

---

## 🗂️ Project Structure

```
JA_AUTO_GIT/
├── main.py                    # Entry point
├── run.bat / run.sh           # Quick-launch scripts (Windows / Unix)
├── setup_venv.sh              # Virtual environment setup (Unix)
├── requirements.txt
├── config.ini                 # User settings
├── config.json                # Advanced settings
├── assets/                    # Icons & images
├── i18n/                      # Localized READMEs (9 languages)
├── logs/                      # Runtime logs
└── modules/
    ├── ui/
    │   ├── main_window.py     # Main application window
    │   ├── dialogs.py         # All dialogs (Commit, Release, Cloud Release)
    │   └── styles.py          # Liquid Glass stylesheet
    ├── native/                # Cross-platform Hybrid Engine
    │   ├── win_core.py
    │   ├── mac_core.py
    │   └── linux_core.py
    ├── native_bridge.py       # OS router (singleton)
    ├── git_actions.py         # Git ops + auto-changelog
    ├── github_ops.py          # GitHub CLI + commit/release API
    ├── project_scan.py        # Project scanner + version detector
    ├── project_model.py       # ProjectInfo dataclass
    ├── git_runner.py          # Background thread runner
    ├── constants.py           # App-wide constants (APP_VERSION = "1.5.0")
    └── utils.py               # Settings load/save + migrations
```

---

## 📋 Changelog

### v1.5.0 *(Latest)*
- ✨ **Release Manager**: Push GitHub Releases with tag + assets from Local Workspace tab
- ✨ **Release Browser**: View and download GitHub Releases (with assets) from Cloud tab
- ✨ **Version Column**: Auto-detects project version from package files or git tags
- 🔧 **Fixed-width button columns**: Commits & Releases columns no longer stretch on window resize
- 🔧 **QHeaderView.Fixed**: Applied to all button columns in both workspace tabs

### v1.4.0
- ✨ **Commit History Dialog**: Per-repo commit history with per-commit ZIP download
- ✨ **Auto-Changelog Engine**: Auto-generates commit subject + Change Log body
- 🔧 **Thread-safe downloads**: Qt Signal/Slot cross-thread UI updates

### v1.3.0
- ✨ **Cross-platform Hybrid Engine**: Native bridge for Windows/macOS/Linux
- ✨ **Project Hiding**: Eye toggle with config persistence
- 🔧 **macOS-style window controls**: All dialogs unified

---

<a id="license"></a>
## 📜 License & Copyright

This project is distributed under the **MIT License**. See the [LICENSE](LICENSE) file for details.

Copyright John Alaa @ 2026.
