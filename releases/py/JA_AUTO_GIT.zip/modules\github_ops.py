import os
import shutil
import subprocess

from .git_process import log
from .utils import normalize_remote_base


def resolve_github_owner(remote_base):
    owner = normalize_remote_base(remote_base)
    if "/" in owner:
        owner = owner.split("/")[0]
    return owner or default_github_owner()


def default_github_owner():
    gh = find_gh()
    if gh:
        result = subprocess.run(
            [gh, "api", "user", "--jq", ".login"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()

    result = subprocess.run(
        ["git", "config", "--get", "github.user"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def ensure_github_repo(remote_base, repo_name, log_callback=None, description=None, homepage=None, is_public=False):
    owner = resolve_github_owner(remote_base)
    if not owner:
        log(log_callback, "[WARN] GitHub owner is empty. Cannot auto-create repository.\n")
        return False

    gh = find_gh()
    if not gh:
        log(
            log_callback,
            "[WARN] GitHub CLI 'gh' not found. Auto-create repo skipped. "
            "Create the repo manually or install GitHub CLI.\n",
        )
        return False

    full_name = f"{owner}/{repo_name}"
    if gh_repo_exists(full_name):
        log(log_callback, f"[OK] GitHub repo already exists: {full_name}\n")
        if description or homepage:
            cmd = [gh, "repo", "edit", full_name]
            if description:
                cmd.extend(["-d", description])
            if homepage:
                cmd.extend(["-h", homepage])
            log(log_callback, f"$ {' '.join(cmd)}\n")
            process = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                )
            if process.stdout:
                log(log_callback, process.stdout)
            if process.stderr:
                log(log_callback, process.stderr)
            if process.returncode != 0:
                log(log_callback, "[WARN] Failed to update GitHub repository description/homepage.\n")
        return True

    visibility = "--public" if is_public else "--private"
    cmd = [gh, "repo", "create", full_name, visibility]
    if description:
        cmd.extend(["-d", description])
    if homepage:
        cmd.extend(["-h", homepage])

    log(log_callback, f"$ {' '.join(cmd)}\n")
    process = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if process.stdout:
        log(log_callback, process.stdout)
    if process.stderr:
        log(log_callback, process.stderr)
    if process.returncode != 0:
        raise RuntimeError(f"Could not create GitHub repository: {full_name}")
    return True


def gh_repo_exists(full_name):
    gh = find_gh()
    if not gh:
        return False
    result = subprocess.run(
        [gh, "repo", "view", full_name],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return result.returncode == 0


def find_gh():
    found = shutil.which("gh")
    if found:
        return found

    candidates = [
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "GitHub CLI", "gh.exe"),
        os.path.join(os.environ.get("ProgramFiles", ""), "GitHub CLI", "gh.exe"),
        os.path.join(os.environ.get("ProgramFiles(x86)", ""), "GitHub CLI", "gh.exe"),
    ]
    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return candidate
    return ""


def get_github_repositories(remote_base, log_callback=None):
    owner = resolve_github_owner(remote_base)
    if not owner:
        log(log_callback, "[WARN] GitHub owner is empty. Cannot list repositories.\n")
        return []

    gh = find_gh()
    if not gh:
        log(log_callback, "[WARN] GitHub CLI 'gh' not found. Cannot list repositories.\n")
        return []

    cmd = [gh, "repo", "list", owner, "--limit", "1000", "--json", "name,url,description,updatedAt,primaryLanguage,isPrivate"]
    log(log_callback, f"$ {' '.join(cmd)}\n")
    
    process = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if process.returncode != 0:
        log(log_callback, f"[ERROR] Failed to list repositories:\n{process.stderr}\n")
        return []
        
    import json
    try:
        repos = json.loads(process.stdout)
        return repos
    except Exception as e:
        log(log_callback, f"[ERROR] Failed to parse repositories JSON: {e}\n")
        return []


def get_github_commits(owner, repo_name, per_page=30, log_callback=None):
    """Fetch commit history for a GitHub repo, annotated with tag names."""
    import json

    gh = find_gh()
    if not gh:
        log(log_callback, "[WARN] GitHub CLI 'gh' not found. Cannot fetch commits.\n")
        return []

    # --- fetch commits ---
    commits_cmd = [
        gh, "api",
        f"repos/{owner}/{repo_name}/commits",
        "--paginate",
        "--jq", f".[::{per_page}] | .[]",
    ]
    # simpler: use single page with query param
    commits_cmd = [
        gh, "api",
        f"repos/{owner}/{repo_name}/commits?per_page={per_page}",
    ]
    proc = subprocess.run(
        commits_cmd,
        capture_output=True, text=True,
        encoding="utf-8", errors="replace",
    )
    if proc.returncode != 0:
        log(log_callback, f"[ERROR] Failed to fetch commits: {proc.stderr}\n")
        return []

    try:
        raw = json.loads(proc.stdout)
    except Exception as e:
        log(log_callback, f"[ERROR] Parse commits JSON: {e}\n")
        return []

    # --- fetch tags for annotation ---
    tag_map = {}   # sha -> tag_name
    tags_cmd = [gh, "api", f"repos/{owner}/{repo_name}/tags?per_page=100"]
    tproc = subprocess.run(
        tags_cmd,
        capture_output=True, text=True,
        encoding="utf-8", errors="replace",
    )
    if tproc.returncode == 0:
        try:
            for tag in json.loads(tproc.stdout):
                sha = tag.get("commit", {}).get("sha", "")
                if sha:
                    tag_map[sha] = tag.get("name", "")
        except Exception:
            pass

    # --- build result list ---
    result = []
    for c in raw:
        sha = c.get("sha", "")
        short_sha = sha[:7]
        commit_info = c.get("commit", {})
        author_info = commit_info.get("author", {})
        message_full = commit_info.get("message", "")
        # Split subject / body
        message_lines = message_full.strip().splitlines()
        subject = message_lines[0] if message_lines else ""
        date_raw = author_info.get("date", "")
        date_short = date_raw[:10] if date_raw else ""
        result.append({
            "sha": sha,
            "short_sha": short_sha,
            "author": author_info.get("name", ""),
            "subject": subject,
            "message": message_full,
            "date": date_short,
            "tag": tag_map.get(sha, ""),
        })

    return result


def get_github_releases(owner: str, repo_name: str, per_page: int = 30, log_callback=None) -> list:
    """Fetch GitHub Releases list for a repo. Returns list of release dicts."""
    import json

    gh = find_gh()
    if not gh:
        log(log_callback, "[WARN] GitHub CLI 'gh' not found. Cannot fetch releases.\n")
        return []

    env = {k: v for k, v in os.environ.items() if k != "GITHUB_TOKEN"}
    cmd = [gh, "api", f"repos/{owner}/{repo_name}/releases?per_page={per_page}"]
    proc = subprocess.run(
        cmd, capture_output=True, text=True,
        encoding="utf-8", errors="replace", env=env,
    )
    if proc.returncode != 0:
        log(log_callback, f"[ERROR] Failed to fetch releases: {proc.stderr}\n")
        return []

    try:
        raw = json.loads(proc.stdout)
    except Exception as e:
        log(log_callback, f"[ERROR] Parse releases JSON: {e}\n")
        return []

    result = []
    for r in raw:
        result.append({
            "id":           r.get("id", ""),
            "tag":          r.get("tag_name", ""),
            "name":         r.get("name", "") or r.get("tag_name", ""),
            "prerelease":   r.get("prerelease", False),
            "draft":        r.get("draft", False),
            "published_at": (r.get("published_at") or "")[:10],
            "body":         r.get("body", ""),
            "html_url":     r.get("html_url", ""),
            "assets": [
                {
                    "name":                 a.get("name", ""),
                    "size":                 a.get("size", 0),
                    "browser_download_url": a.get("browser_download_url", ""),
                }
                for a in r.get("assets", [])
            ],
        })
    return result
