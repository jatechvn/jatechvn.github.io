@echo off
setlocal enabledelayedexpansion

:: --- AN CMD XUONG TASKBAR ---
if not "%1"=="min" (
    start /min cmd /c "%~f0" min
    exit /b
)

:: --- TU DONG LAY TEN THU MUC LAM TEN PROJECT ---
for %%I in ("%~dp0.") do set "PROJ_NAME=%%~nxI"
title !PROJ_NAME! - Johnny's Automation Suite

:: --- CAU HINH GIAO DIEN ---
mode con: cols=90 lines=30
color 0B

echo.
echo  #############################################################################
echo  #                                                                           #
echo  #                 JOHNNY'S PROFESSIONAL DEPLOYMENT SYSTEM                   #
echo  #                                                                           #
echo  #  PROJECT: !PROJ_NAME!
echo  #                                                                           #
echo  #############################################################################
echo.
echo  [*] Thoi gian : %date% %time%
echo  [*] Thu muc   : %~dp0
echo  [*] Moi truong: Python .venv (Isolated)
echo.

:: --- KIEM TRA MAIN.PY ---
if not exist "%~dp0main.py" (
    color 0C
    echo  [!] LOI: Khong tim thay main.py
    echo  [?] Dam bao run.bat nam trong thu muc goc cua project.
    pause
    exit /b 1
)

set "VENV_DIR=%~dp0.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"
set "VENV_PIP=%VENV_DIR%\Scripts\pip.exe"
set "REQ_FILE=%~dp0requirements.txt"

:: =============================================================================
echo  -----------------------------------------------------------------------------
echo  [ VENV ] Kiem tra moi truong ao (.venv)...
echo  -----------------------------------------------------------------------------

if not exist "%VENV_PY%" (
    echo.
    echo  [*] .venv chua ton tai. Dang tao moi .venv tu Python he thong...
    echo.

    :: Tim Python tren he thong
    python --version >nul 2>&1
    if %ERRORLEVEL% neq 0 (
        color 0C
        echo  [!] LOI: Khong tim thay Python tren he thong!
        echo  [?] Hay cai dat Python 3.10+ va thu lai.
        pause
        exit /b 1
    )

    python -m venv "%VENV_DIR%"
    if %ERRORLEVEL% neq 0 (
        color 0C
        echo  [!] LOI: Khong the tao .venv!
        pause
        exit /b 1
    )
    echo  [+] Da tao .venv thanh cong!
    echo.
)

:: Verify .venv usable
"%VENV_PY%" -c "import sys; print('[+] Python .venv:', sys.executable)" 2>nul
if %ERRORLEVEL% neq 0 (
    color 0C
    echo  [!] LOI: .venv bi hong! Dang xoa va tao lai...
    rd /s /q "%VENV_DIR%" 2>nul
    python -m venv "%VENV_DIR%"
    if %ERRORLEVEL% neq 0 (
        echo  [!] Tao lai .venv that bai!
        pause
        exit /b 1
    )
    echo  [+] Da tao lai .venv!
    echo.
)

:: =============================================================================
echo  -----------------------------------------------------------------------------
echo  [ DEPS ] Kiem tra va cap nhat thu vien (requirements.txt)...
echo  -----------------------------------------------------------------------------
echo.

if exist "%REQ_FILE%" (
    "%VENV_PY%" -s -m pip install -q --upgrade pip 2>nul
    "%VENV_PY%" -s -m pip install -q -r "%REQ_FILE%"
    if %ERRORLEVEL% neq 0 (
        color 0E
        echo  [!] CANH BAO: Mot so thu vien cai khong thanh cong.
        echo  [*] Ung dung van se khoi chay, co the thieu tinh nang.
        echo.
    ) else (
        echo  [+] Tat ca thu vien da san sang!
        echo.
    )
) else (
    echo  [*] Khong tim thay requirements.txt, bo qua buoc cai thu vien.
    echo.
)

:: =============================================================================
echo  -----------------------------------------------------------------------------
echo  [^] Dang khoi chay [!PROJ_NAME!] qua .venv...
echo  -----------------------------------------------------------------------------
echo.

"%VENV_PY%" -s "%~dp0main.py"

if %ERRORLEVEL% neq 0 (
    color 0C
    echo.
    echo  [!] !PROJ_NAME! DA DUNG DOT NGOT (Exit Code: %ERRORLEVEL%)
    echo  [*] Kiem tra file log trong thu muc logs\ de biet chi tiet.
    echo.
    pause
    exit /b %ERRORLEVEL%
) else (
    echo.
    echo  [ OK ] !PROJ_NAME! da hoan tat.
    echo.
    timeout /t 3 >nul
)
