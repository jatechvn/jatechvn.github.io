import os
import sys
import re
import darkdetect
try:
    from BlurWindow.blurWindow import GlobalBlur
    HAS_BLUR = True
except Exception:
    HAS_BLUR = False
    GlobalBlur = None
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QTextEdit, QPushButton, QLabel, QProgressBar, 
    QMessageBox, QFrame, QGraphicsDropShadowEffect,
    QLineEdit, QFileDialog, QScrollArea, QGroupBox,
    QCheckBox, QGridLayout
)
from PySide6.QtCore import Qt, QPoint, QEvent, QTimer, QSize, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QTextCursor
from BlurWindow.blurWindow import GlobalBlur
from .logic import BuildRunner
from .constants import *
from .utils import *

class SegmentedControl(QFrame):
    """A custom toggle button to switch between PyInstaller and Nuitka."""
    changed = Signal(str) # "PyInstaller" or "Nuitka"

    def __init__(self, is_dark=True, parent=None):
        super().__init__(parent)
        self.is_dark = is_dark
        self.active_mode = "PyInstaller"
        self.init_ui()
        self.apply_style()

    def init_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(0)

        self.btn_pyi = QPushButton("PyInstaller (Fast & Heavy)")
        self.btn_pyi.setCheckable(True)
        self.btn_pyi.setChecked(True)
        self.btn_pyi.clicked.connect(lambda: self.set_mode("PyInstaller"))

        self.btn_nui = QPushButton("Nuitka C++ (Optimized & Light)")
        self.btn_nui.setCheckable(True)
        self.btn_nui.setChecked(False)
        self.btn_nui.clicked.connect(lambda: self.set_mode("Nuitka"))

        layout.addWidget(self.btn_pyi)
        layout.addWidget(self.btn_nui)

    def set_mode(self, mode):
        self.active_mode = mode
        if mode == "PyInstaller":
            self.btn_pyi.setChecked(True)
            self.btn_nui.setChecked(False)
        else:
            self.btn_pyi.setChecked(False)
            self.btn_nui.setChecked(True)
        self.changed.emit(mode)
        self.apply_style()

    def set_theme(self, is_dark):
        self.is_dark = is_dark
        self.apply_style()

    def apply_style(self):
        bg = "rgba(0, 0, 0, 0.4)" if self.is_dark else "rgba(255, 255, 255, 0.6)"
        border = "rgba(255, 255, 255, 0.15)" if self.is_dark else "rgba(0, 0, 0, 0.1)"
        fg = "#fff" if self.is_dark else "#000"
        
        self.setStyleSheet(f"""
            SegmentedControl {{
                background-color: {bg};
                border: 1px solid {border};
                border-radius: 12px;
            }}
            QPushButton {{
                background: transparent;
                border: none;
                border-radius: 9px;
                color: {fg};
                font-family: 'Inter';
                font-weight: bold;
                font-size: 11px;
                padding: 10px 14px;
            }}
            QPushButton:hover {{
                background: rgba(255, 255, 255, 0.05);
            }}
            QPushButton:checked {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00d4ff, stop:1 #00ff9d);
                color: black;
            }}
        """)


class PythonAutoBuilderApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Johnny's Python Auto-Builder")
        self.resize(1150, 800)
        
        try:
            self.is_dark = darkdetect.isDark()
        except Exception:
            self.is_dark = True  # fallback to dark mode
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.WindowMinMaxButtonsHint | Qt.WindowSystemMenuHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        # Initialize Runner
        self.runner = BuildRunner()
        self.runner.log_received.connect(self.append_log)
        self.runner.progress_updated.connect(self.update_progress)
        self.runner.finished.connect(self.on_build_finished)
        
        self._drag_pos = QPoint()
        self.init_ui()
        self.apply_theme()
        
        ensure_project_dirs()
        self.load_last_build_settings()

    def init_ui(self):
        self.central_widget = QFrame()
        self.central_widget.setObjectName("CentralWidget")
        self.setCentralWidget(self.central_widget)
        
        # Support drag and drop files into the app window
        self.setAcceptDrops(True)
        
        layout = QVBoxLayout(self.central_widget)
        layout.setContentsMargins(20, 15, 20, 20)

        # ----------------- CUSTOM TITLE BAR -----------------
        title_bar = QHBoxLayout()
        self.close_btn = QPushButton("")
        self.close_btn.setObjectName("CloseBtn")
        self.close_btn.setFixedSize(16, 16)
        self.close_btn.clicked.connect(self.close)
        self.close_btn.setToolTip("Close")

        self.min_btn = QPushButton("")
        self.min_btn.setObjectName("MinBtn")
        self.min_btn.setFixedSize(16, 16)
        self.min_btn.clicked.connect(self.showMinimized)
        self.min_btn.setToolTip("Minimize")

        self.max_btn = QPushButton("")
        self.max_btn.setObjectName("MaxBtn")
        self.max_btn.setFixedSize(16, 16)
        self.max_btn.clicked.connect(self.toggle_maximize)
        self.max_btn.setToolTip("Maximize/Restore")

        title_bar.addWidget(self.close_btn)
        title_bar.addSpacing(2)
        title_bar.addWidget(self.min_btn)
        title_bar.addSpacing(2)
        title_bar.addWidget(self.max_btn)
        title_bar.addSpacing(15)

        self.lbl_title = QLabel("JOHNNY'S PYTHON AUTO-BUILDER • LIQUID GLASS")
        self.add_shadow(self.lbl_title, radius=10)
        title_bar.addWidget(self.lbl_title)
        title_bar.addStretch()
        
        # Theme Toggle
        self.btn_theme = QPushButton()
        self.btn_theme.setFixedHeight(30)
        self.btn_theme.setCursor(Qt.PointingHandCursor)
        self.btn_theme.clicked.connect(self.toggle_theme)
        title_bar.addWidget(self.btn_theme)
        layout.addLayout(title_bar)

        # ----------------- MAIN SPLIT PANEL -----------------
        split_layout = QHBoxLayout()
        split_layout.setSpacing(20)
        split_layout.setContentsMargins(0, 10, 0, 0)

        # ================= LEFT COLUMN: SETTINGS PANEL =================
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setStyleSheet("QScrollArea { background: transparent; }")
        
        left_widget = QWidget()
        left_widget.setStyleSheet("background: transparent;")
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 10, 0)
        left_layout.setSpacing(15)

        # Group 1: Target script selection
        grp_project = QGroupBox("CẤU HÌNH DỰ ÁN (PROJECT CONFIG)")
        proj_layout = QVBoxLayout(grp_project)
        proj_layout.setSpacing(10)
        
        # Script Entry point
        lbl_script = QLabel("File thực thi chính (Entry script .py):")
        self.txt_script = QLineEdit()
        self.txt_script.setPlaceholderText("Kéo & thả file .py hoặc bấm Browse để chọn...")
        self.btn_browse_script = QPushButton("Browse...")
        self.btn_browse_script.clicked.connect(self.browse_script)
        
        h_script = QHBoxLayout()
        h_script.addWidget(self.txt_script)
        h_script.addWidget(self.btn_browse_script)
        proj_layout.addWidget(lbl_script)
        proj_layout.addLayout(h_script)
        
        # Project Dir
        lbl_proj_dir = QLabel("Thư mục gốc của dự án (Project Root Directory):")
        self.txt_proj_dir = QLineEdit()
        self.txt_proj_dir.setPlaceholderText("Tự động điền theo script hoặc bấm Browse...")
        self.btn_browse_dir = QPushButton("Browse...")
        self.btn_browse_dir.clicked.connect(self.browse_project_dir)
        
        h_dir = QHBoxLayout()
        h_dir.addWidget(self.txt_proj_dir)
        h_dir.addWidget(self.btn_browse_dir)
        proj_layout.addWidget(lbl_proj_dir)
        proj_layout.addLayout(h_dir)
        
        # App Name
        lbl_app_name = QLabel("Tên file thực thi đầu ra (Application Output Name):")
        self.txt_app_name = QLineEdit("StandAloneApp")
        self.txt_app_name.setPlaceholderText("Ví dụ: MyApp")
        proj_layout.addWidget(lbl_app_name)
        proj_layout.addWidget(self.txt_app_name)

        # Output Directory
        lbl_output_dir = QLabel("Thư mục xuất bản build (Output Directory):")
        self.txt_output_dir = QLineEdit()
        self.txt_output_dir.setPlaceholderText("Mặc định: <Project Root>\\build_pyinstall hoặc build_nuitka...")
        self.btn_browse_output = QPushButton("Browse...")
        self.btn_browse_output.clicked.connect(self.browse_output_dir)

        h_output = QHBoxLayout()
        h_output.addWidget(self.txt_output_dir)
        h_output.addWidget(self.btn_browse_output)
        proj_layout.addWidget(lbl_output_dir)
        proj_layout.addLayout(h_output)
        
        left_layout.addWidget(grp_project)

        # Group 2: Compiler Choice & Env Setup
        grp_compiler = QGroupBox("CHẾ ĐỘ & MÔI TRƯỜNG DỊCH (ENVIRONMENT)")
        comp_layout = QVBoxLayout(grp_compiler)
        comp_layout.setSpacing(12)
        
        # Toggle buttons
        comp_layout.addWidget(QLabel("Lựa chọn trình biên dịch (Compiler Mode):"))
        self.compiler_control = SegmentedControl(is_dark=self.is_dark)
        self.compiler_control.changed.connect(self.on_compiler_changed)
        comp_layout.addWidget(self.compiler_control)

        # Virtual Env
        lbl_venv = QLabel("Đường dẫn Python trong Môi trường ảo (Isolated .venv Python):")
        self.txt_venv = QLineEdit()
        self.txt_venv.setPlaceholderText("Tự động quét trong thư mục dự án hoặc chọn thủ công...")
        self.btn_browse_venv = QPushButton("Browse...")
        self.btn_browse_venv.clicked.connect(self.browse_venv)
        
        h_venv = QHBoxLayout()
        h_venv.addWidget(self.txt_venv)
        h_venv.addWidget(self.btn_browse_venv)
        comp_layout.addWidget(lbl_venv)
        comp_layout.addLayout(h_venv)

        # Checkboxes for isolation
        h_checks = QHBoxLayout()
        self.chk_isolation = QCheckBox("Bật cô lập Python (PYTHONNOUSERSITE=1)")
        self.chk_isolation.setChecked(True)
        self.chk_isolated_flag = QCheckBox("Chạy Python độc lập (Cờ -s)")
        self.chk_isolated_flag.setChecked(True)
        h_checks.addWidget(self.chk_isolation)
        h_checks.addWidget(self.chk_isolated_flag)
        comp_layout.addLayout(h_checks)

        # Windowed / Console-less
        self.chk_windowed = QCheckBox("Ẩn cửa sổ dòng lệnh khi chạy ứng dụng đầu ra (Windowed / No Console)")
        self.chk_windowed.setChecked(True)
        comp_layout.addWidget(self.chk_windowed)
        
        left_layout.addWidget(grp_compiler)

        # Group 3: Assets, Copy files & Icon settings
        grp_assets = QGroupBox("TÀI NGUYÊN & ICON (ASSETS & BUNDLING)")
        assets_layout = QVBoxLayout(grp_assets)
        assets_layout.setSpacing(10)

        # Icon file
        lbl_icon = QLabel("File Icon ứng dụng (.ico):")
        self.txt_icon = QLineEdit()
        self.txt_icon.setPlaceholderText("Kéo & thả file .ico hoặc chọn...")
        self.btn_browse_icon = QPushButton("Browse...")
        self.btn_browse_icon.clicked.connect(self.browse_icon)
        
        h_icon = QHBoxLayout()
        h_icon.addWidget(self.txt_icon)
        h_icon.addWidget(self.btn_browse_icon)
        assets_layout.addWidget(lbl_icon)
        assets_layout.addLayout(h_icon)

        h_scan_assets = QHBoxLayout()
        h_scan_assets.addWidget(QLabel("Tự quét tài nguyên trong project:"))
        h_scan_assets.addStretch()
        self.btn_refresh_assets = QPushButton("Quét lại")
        self.btn_refresh_assets.clicked.connect(self.refresh_bundle_candidates)
        h_scan_assets.addWidget(self.btn_refresh_assets)
        assets_layout.addLayout(h_scan_assets)

        # Bundled asset directories
        lbl_asset_dirs = QLabel("Thư mục cần đóng gói theo app:")
        assets_layout.addWidget(lbl_asset_dirs)
        self.asset_checks = {}
        self.asset_checks_widget = QWidget()
        self.asset_checks_layout = QGridLayout(self.asset_checks_widget)
        self.asset_checks_layout.setContentsMargins(0, 0, 0, 0)
        self.asset_checks_layout.setSpacing(6)
        assets_layout.addWidget(self.asset_checks_widget)

        # Files copied next to executable after build
        lbl_copy_files = QLabel("File nằm cạnh main cần sao chép cạnh file chạy:")
        assets_layout.addWidget(lbl_copy_files)
        self.copy_file_checks = {}
        self.copy_file_checks_widget = QWidget()
        self.copy_file_checks_layout = QGridLayout(self.copy_file_checks_widget)
        self.copy_file_checks_layout.setContentsMargins(0, 0, 0, 0)
        self.copy_file_checks_layout.setSpacing(6)
        assets_layout.addWidget(self.copy_file_checks_widget)

        left_layout.addWidget(grp_assets)

        # Group 4: Optimizations
        self.grp_opts = QGroupBox("TỐI ƯU HÓA DUNG LƯỢNG (SIZE OPTIMIZATION - PYINSTALLER ONLY)")
        opts_layout = QVBoxLayout(self.grp_opts)
        opts_layout.setSpacing(10)

        opts_layout.addWidget(QLabel("Chọn thư viện KHÔNG sử dụng để loại bỏ khỏi file chạy:"))
        
        # Grid of checkboxes for exclusions
        grid_widget = QWidget()
        grid_layout = QGridLayout(grid_widget)
        grid_layout.setContentsMargins(0, 0, 0, 0)
        grid_layout.setSpacing(8)
        
        self.exclusion_checks = {}
        row, col = 0, 0
        for exc in DEFAULT_EXCLUSIONS:
            chk = QCheckBox(exc)
            chk.setChecked(True) # Exclude by default
            grid_layout.addWidget(chk, row, col)
            self.exclusion_checks[exc] = chk
            col += 1
            if col > 1:
                col = 0
                row += 1
                
        opts_layout.addWidget(grid_widget)

        # Toggle all exclusions helper link buttons
        h_opt_links = QHBoxLayout()
        self.btn_select_all_exc = QPushButton("Select All")
        self.btn_select_all_exc.setStyleSheet("QPushButton { background: transparent; border: none; text-decoration: underline; color: #00d4ff; }")
        self.btn_select_all_exc.clicked.connect(self.select_all_exclusions)
        
        self.btn_clear_all_exc = QPushButton("Clear All")
        self.btn_clear_all_exc.setStyleSheet("QPushButton { background: transparent; border: none; text-decoration: underline; color: #00d4ff; }")
        self.btn_clear_all_exc.clicked.connect(self.clear_all_exclusions)
        
        h_opt_links.addWidget(self.btn_select_all_exc)
        h_opt_links.addWidget(self.btn_clear_all_exc)
        h_opt_links.addStretch()
        opts_layout.addLayout(h_opt_links)

        # Hidden imports
        lbl_hidden = QLabel("Thư viện liên kết ẩn cần khai báo thêm (Hidden Imports):")
        self.txt_hidden = QLineEdit("BlurWindow, darkdetect, requests")
        self.txt_hidden.setPlaceholderText("Phân tách bởi dấu phẩy (Ví dụ: PySide6.QtNetwork, requests)")
        opts_layout.addWidget(lbl_hidden)
        opts_layout.addWidget(self.txt_hidden)

        self.chk_cython = QCheckBox("Dùng Cython để biên dịch modules/*.py sang .pyd trước khi build PyInstaller")
        self.chk_cython.setChecked(False)
        self.chk_cython.setToolTip("Tùy chọn bảo vệ source nâng cao. Mặc định tắt vì cần C compiler và có thể làm build khó debug hơn.")
        opts_layout.addWidget(self.chk_cython)

        left_layout.addWidget(self.grp_opts)

        # Clean build option
        self.chk_clean = QCheckBox("Dọn dẹp các thư mục tạm (build, main.build) sau khi xong")
        self.chk_clean.setChecked(True)
        left_layout.addWidget(self.chk_clean)

        scroll_area.setWidget(left_widget)
        split_layout.addWidget(scroll_area, 4)

        # ================= RIGHT COLUMN: LIVE MONOSPACE CONSOLE =================
        right_panel = QVBoxLayout()
        right_panel.setSpacing(12)

        lbl_console = QLabel("NHẬT KÝ BIÊN DỊCH TRỰC TIẾP (LIVE COMPILER CONSOLE)")
        lbl_console.setObjectName("ConsoleLabel")
        self.add_shadow(lbl_console)
        right_panel.addWidget(lbl_console)

        self.txt_console = QTextEdit()
        self.txt_console.setReadOnly(True)
        self.txt_console.setPlaceholderText("Trình quản lý Console đang chờ tiến trình khởi chạy...")
        
        # Clear Console button inside console layout
        h_console_hdr = QHBoxLayout()
        h_console_hdr.addStretch()
        self.btn_clear_console = QPushButton("Xóa Console")
        self.btn_clear_console.setCursor(Qt.PointingHandCursor)
        self.btn_clear_console.clicked.connect(self.txt_console.clear)
        h_console_hdr.addWidget(self.btn_clear_console)
        right_panel.addLayout(h_console_hdr)
        right_panel.addWidget(self.txt_console)

        split_layout.addLayout(right_panel, 5)
        layout.addLayout(split_layout)

        # ----------------- BOTTOM CONTROL BAR -----------------
        bottom_bar = QVBoxLayout()
        bottom_bar.setSpacing(8)
        bottom_bar.setContentsMargins(0, 10, 0, 0)

        self.lbl_status = QLabel("Trạng thái: Đang chờ lệnh...")
        bottom_bar.addWidget(self.lbl_status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(5)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        bottom_bar.addWidget(self.progress_bar)

        self.btn_build = QPushButton("BẮT ĐẦU BIÊN DỊCH DỰ ÁN (BUILD STANDALONE)")
        self.btn_build.setObjectName("BuildBtn")
        self.btn_build.setFixedHeight(52)
        self.btn_build.setFont(QFont("Inter", 12, QFont.Bold))
        self.btn_build.setCursor(Qt.PointingHandCursor)
        self.btn_build.clicked.connect(self.start_build_process)
        self.add_shadow(self.btn_build)
        
        bottom_bar.addWidget(self.btn_build)
        layout.addLayout(bottom_bar)

    def add_shadow(self, widget, color=None, radius=12):
        if color is None:
            color = QColor(0, 0, 0, 160) if self.is_dark else QColor(0, 0, 0, 50)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(radius)
        shadow.setColor(color)
        shadow.setOffset(2, 2)
        widget.setGraphicsEffect(shadow)

    # ----------------- EVENT HANDLERS & HELPERS -----------------
    def on_compiler_changed(self, compiler):
        """Disables exclusions since Nuitka handles size optimization internally via C compilation."""
        is_nui = (compiler == "Nuitka")
        self.grp_opts.setEnabled(not is_nui)
        self.chk_cython.setEnabled(not is_nui)
        self.apply_default_output_dir(force_if_default=False)
        if is_nui:
            self.lbl_status.setText("Trạng thái: Trình biên dịch Nuitka C++ được chọn.")
        else:
            self.lbl_status.setText("Trạng thái: Trình biên dịch PyInstaller được chọn.")

    def select_all_exclusions(self):
        for chk in self.exclusion_checks.values():
            chk.setChecked(True)

    def clear_all_exclusions(self):
        for chk in self.exclusion_checks.values():
            chk.setChecked(False)

    def _clear_grid_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    def _scan_base_dir(self):
        script = self.txt_script.text().strip()
        if script and os.path.exists(script):
            return os.path.dirname(script)
        project = self.txt_proj_dir.text().strip()
        if project and os.path.exists(project):
            return project
        return ""

    def default_app_name_for_project(self, project_dir):
        project_name = os.path.basename(os.path.normpath(project_dir)) if project_dir else ""
        return f"{project_name}_build" if project_name else "StandAloneApp"

    def default_output_dir_for_project(self, project_dir, compiler=None):
        if not project_dir:
            return ""
        compiler = compiler or self.compiler_control.active_mode
        folder_name = "build_nuitka" if compiler == "Nuitka" else "build_pyinstall"
        return os.path.join(project_dir, folder_name)

    def is_default_output_dir(self, output_dir):
        if not output_dir:
            return True
        return os.path.basename(os.path.normpath(output_dir)).lower() in {
            "dist", "build_pyinstall", "build_pyinstaller", "build_nuitka"
        }

    def apply_default_app_name(self, project_dir, script_path=""):
        current = self.txt_app_name.text().strip()
        script_name = os.path.splitext(os.path.basename(script_path))[0] if script_path else ""
        if not current or current == "StandAloneApp" or current == script_name:
            self.txt_app_name.setText(self.default_app_name_for_project(project_dir))

    def apply_default_output_dir(self, force_if_default=False):
        project_dir = self.txt_proj_dir.text().strip()
        current = self.txt_output_dir.text().strip()
        if project_dir and (force_if_default or self.is_default_output_dir(current)):
            self.txt_output_dir.setText(self.default_output_dir_for_project(project_dir))

    def load_last_build_settings(self):
        settings = load_last_build_config()
        if not settings:
            return

        project_dir = settings.get("project_dir", "")
        script_path = settings.get("script_path", "")
        if project_dir and not os.path.isdir(project_dir):
            self.lbl_status.setText("Trạng thái: Project build gần nhất không còn tồn tại.")
            return

        self.txt_proj_dir.setText(project_dir)
        if script_path and os.path.exists(script_path):
            self.txt_script.setText(script_path)
        self.txt_output_dir.setText(settings.get("output_dir", ""))
        self.txt_app_name.setText(settings.get("app_name", "") or "StandAloneApp")
        self.txt_venv.setText(settings.get("venv_py", ""))
        self.txt_icon.setText(settings.get("icon_path", ""))
        self.txt_hidden.setText(settings.get("hidden_imports", self.txt_hidden.text()))

        compiler = settings.get("compiler", "PyInstaller")
        if compiler in {"PyInstaller", "Nuitka"}:
            self.compiler_control.set_mode(compiler)

        self.chk_isolation.setChecked(config_bool(settings.get("python_isolation"), True))
        self.chk_isolated_flag.setChecked(config_bool(settings.get("isolated_flag"), True))
        self.chk_windowed.setChecked(config_bool(settings.get("windowed"), True))
        self.chk_clean.setChecked(config_bool(settings.get("clean_build"), True))
        self.chk_cython.setChecked(config_bool(settings.get("pyinstaller_cython"), False))

        if project_dir:
            self.apply_default_app_name(project_dir, script_path)
            self.apply_default_output_dir(force_if_default=False)
            if not self.txt_venv.text().strip():
                self.scan_for_local_venv(project_dir)
            self.auto_detect_icon(project_dir)
            self.refresh_bundle_candidates()
            self.lbl_status.setText(f"Trạng thái: Đã nạp lại project build gần nhất: {project_dir}")

    def save_last_build_settings(self, build_config):
        data = {
            "compiler": build_config.get("compiler", "PyInstaller"),
            "script_path": build_config.get("script_path", ""),
            "project_dir": build_config.get("project_dir", ""),
            "output_dir": build_config.get("output_dir", ""),
            "app_name": build_config.get("app_name", ""),
            "venv_py": build_config.get("venv_py", ""),
            "python_isolation": build_config.get("python_isolation", True),
            "isolated_flag": build_config.get("isolated_flag", True),
            "windowed": build_config.get("windowed", True),
            "icon_path": build_config.get("icon_path", ""),
            "hidden_imports": ", ".join(build_config.get("hidden_imports", [])),
            "clean_build": build_config.get("clean_build", True),
            "pyinstaller_cython": build_config.get("pyinstaller_cython", False),
        }
        save_last_build_config(data)

    def _candidate_asset_dirs(self, project_dir):
        ignored = {
            ".git", ".hg", ".svn", ".venv", "venv", "env", "__pycache__",
            "modules", "build", "dist", "logs", ".mypy_cache", ".pytest_cache"
        }
        output_dir = self.txt_output_dir.text().strip()
        output_abs = os.path.abspath(output_dir) if output_dir else ""
        candidates = []
        if not project_dir or not os.path.isdir(project_dir):
            return candidates

        for name in sorted(os.listdir(project_dir), key=str.lower):
            path = os.path.join(project_dir, name)
            if not os.path.isdir(path):
                continue
            if name in ignored or name.startswith("."):
                continue
            if output_abs and os.path.abspath(path) == output_abs:
                continue
            candidates.append(name)
        return candidates

    def auto_detect_icon(self, project_dir):
        """Fill the icon field from common project icon locations when it is empty."""
        if self.txt_icon.text().strip():
            return
        candidates = [
            os.path.join(project_dir, "assets", "images", "icon.ico"),
            os.path.join(project_dir, "assets", "icon.ico"),
            os.path.join(project_dir, "icon.ico"),
        ]
        for icon_path in candidates:
            if os.path.exists(icon_path):
                self.txt_icon.setText(icon_path)
                return

    def _candidate_copy_files(self, base_dir):
        ignored_exts = {".py", ".pyc", ".pyo", ".spec", ".log", ".exe", ".bat", ".cmd", ".md"}
        ignored_names = {".gitignore", "requirements.txt", "requirements-dev.txt", "pyproject.toml"}
        script = self.txt_script.text().strip()
        script_abs = os.path.abspath(script) if script else ""
        candidates = []
        if not base_dir or not os.path.isdir(base_dir):
            return candidates

        for name in sorted(os.listdir(base_dir), key=str.lower):
            path = os.path.join(base_dir, name)
            if not os.path.isfile(path):
                continue
            if name in ignored_names or name.startswith("."):
                continue
            if script_abs and os.path.abspath(path) == script_abs:
                continue
            if os.path.splitext(name)[1].lower() in ignored_exts:
                continue
            candidates.append(name)
        return candidates

    def _populate_check_grid(self, layout, checks, names, empty_text):
        self._clear_grid_layout(layout)
        checks.clear()
        if not names:
            label = QLabel(empty_text)
            label.setEnabled(False)
            layout.addWidget(label, 0, 0)
            return

        for index, name in enumerate(names):
            chk = QCheckBox(name)
            chk.setChecked(True)
            checks[name] = chk
            layout.addWidget(chk, index // 2, index % 2)

    def refresh_bundle_candidates(self):
        project_dir = self.txt_proj_dir.text().strip()
        base_dir = self._scan_base_dir()
        self._populate_check_grid(
            self.asset_checks_layout,
            self.asset_checks,
            self._candidate_asset_dirs(project_dir),
            "Chưa phát hiện thư mục tài nguyên."
        )
        self._populate_check_grid(
            self.copy_file_checks_layout,
            self.copy_file_checks,
            self._candidate_copy_files(base_dir),
            "Chưa phát hiện file cần copy."
        )

    def browse_script(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Chọn file Python thực thi", "", "Python Files (*.py)")
        if file_path:
            self.txt_script.setText(file_path)
            # Auto fill project path
            proj_dir = os.path.dirname(file_path)
            self.txt_proj_dir.setText(proj_dir)
            # Auto fill app name based on script file name
            self.apply_default_app_name(proj_dir, file_path)
            self.apply_default_output_dir(force_if_default=True)
            self.scan_for_local_venv(proj_dir)
            self.auto_detect_icon(proj_dir)
            self.refresh_bundle_candidates()

    def browse_project_dir(self):
        dir_path = QFileDialog.getExistingDirectory(self, "Chọn thư mục gốc dự án", "")
        if dir_path:
            self.txt_proj_dir.setText(dir_path)
            self.apply_default_app_name(dir_path)
            self.apply_default_output_dir(force_if_default=True)
            self.scan_for_local_venv(dir_path)
            self.auto_detect_icon(dir_path)
            self.refresh_bundle_candidates()

    def browse_output_dir(self):
        start_dir = self.txt_output_dir.text().strip() or self.txt_proj_dir.text().strip() or ""
        dir_path = QFileDialog.getExistingDirectory(self, "Chọn thư mục xuất build", start_dir)
        if dir_path:
            self.txt_output_dir.setText(dir_path)
            self.refresh_bundle_candidates()

    def browse_venv(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Chọn Python.exe trong Môi trường ảo", "", "Executable (*.exe)")
        if file_path:
            self.txt_venv.setText(file_path)

    def browse_icon(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Chọn Icon ứng dụng", "", "Icon Files (*.ico)")
        if file_path:
            self.txt_icon.setText(file_path)

    def scan_for_local_venv(self, directory):
        """Scans the directory automatically to resolve venv path."""
        python_exe = find_venv_in_project(directory)
        if python_exe:
            self.txt_venv.setText(python_exe)
            self.lbl_status.setText("Trạng thái: Phát hiện môi trường ảo cục bộ .venv!")
        else:
            self.txt_venv.clear()
            self.lbl_status.setText("Trạng thái: Không phát hiện .venv hợp lệ, sẽ dùng Python đang chạy app.")

    # ----------------- DRAG AND DROP CAPABILITIES -----------------
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if not urls:
            return
        
        file_path = urls[0].toLocalFile()
        if os.path.isdir(file_path):
            self.txt_proj_dir.setText(file_path)
            self.apply_default_app_name(file_path)
            self.apply_default_output_dir(force_if_default=True)
            self.scan_for_local_venv(file_path)
            self.refresh_bundle_candidates()
        elif file_path.lower().endswith(".py"):
            self.txt_script.setText(file_path)
            proj_dir = os.path.dirname(file_path)
            self.txt_proj_dir.setText(proj_dir)
            self.apply_default_app_name(proj_dir, file_path)
            self.apply_default_output_dir(force_if_default=True)
            self.scan_for_local_venv(proj_dir)
            self.auto_detect_icon(proj_dir)
            self.refresh_bundle_candidates()
        elif file_path.lower().endswith(".ico"):
            self.txt_icon.setText(file_path)

    # ----------------- STYLE & SYSTEM THEMES -----------------
    def toggle_theme(self):
        self.is_dark = not self.is_dark
        self.apply_theme()

    def toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def apply_theme(self):
        if self.is_dark:
            bg_main = "rgba(18, 18, 18, 0.65)"
            text_main = "#ffffff"
            input_bg = "rgba(0, 0, 0, 0.4)"
            console_bg = "rgba(0, 0, 0, 0.6)"
            border = "rgba(255, 255, 255, 0.15)"
            self.btn_theme.setText("🌙 DARK")
        else:
            bg_main = "rgba(240, 240, 240, 0.75)"
            text_main = "#111111"
            input_bg = "rgba(255, 255, 255, 0.6)"
            console_bg = "rgba(255, 255, 255, 0.5)"
            border = "rgba(0, 0, 0, 0.15)"
            self.btn_theme.setText("☀️ LIGHT")

        theme_btn_style = f"""
            QPushButton {{
                color: {text_main}; 
                background: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.08); 
                border-radius: 9px; 
                font-size: 11px; 
                font-weight: bold; 
                padding: 0 10px;
                border: 1px solid {border};
            }}
            QPushButton:hover {{ 
                background: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.15); 
            }}
        """
        self.btn_theme.setStyleSheet(theme_btn_style)

        # Apply system blur using BlurWindow (if available)
        try:
            if HAS_BLUR and GlobalBlur is not None:
                GlobalBlur(self.winId(), Dark=self.is_dark)
        except Exception:
            pass

        self.central_widget.setStyleSheet(f"#CentralWidget {{ background-color: {bg_main}; border: 1px solid {border}; border-radius: 16px; }}")

        # Custom Labels & Groups Stylesheet
        base_style = f"color: {text_main}; font-family: 'Inter';"
        self.lbl_title.setStyleSheet(base_style + "font-weight: 800; font-size: 13px; letter-spacing: 2px;")
        self.lbl_status.setStyleSheet(base_style + "font-weight: bold; font-size: 11px; opacity: 0.85;")
        
        # QTextEdit and GroupBoxes styling
        self.setStyleSheet(f"""
            QGroupBox {{
                color: {text_main};
                font-family: 'Inter';
                font-weight: bold;
                font-size: 11px;
                border: 1px solid {border};
                border-radius: 12px;
                margin-top: 10px;
                padding-top: 15px;
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.02);
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 15px;
                padding: 0 5px;
            }}
            QLabel {{
                color: {text_main};
                font-family: 'Inter';
                font-size: 11px;
                font-weight: 500;
            }}
            QLabel#ConsoleLabel {{
                color: #00d4ff;
                font-weight: 800;
                font-size: 11px;
                letter-spacing: 1px;
            }}
            QLineEdit {{
                background-color: {input_bg};
                color: {text_main};
                border: 1px solid {border};
                border-radius: 8px;
                padding: 7px 10px;
                font-family: 'Inter';
                font-size: 12px;
            }}
            QLineEdit:focus {{
                border: 1px solid #00d4ff;
            }}
            QCheckBox {{
                color: {text_main};
                font-family: 'Inter';
                font-size: 11px;
            }}
            QCheckBox::indicator {{
                width: 14px;
                height: 14px;
            }}
            QScrollBar:vertical {{
                background: transparent;
                width: 8px;
                margin: 0;
            }}
            QScrollBar::handle:vertical {{
                background: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.2);
                border-radius: 4px;
                min-height: 20px;
            }}
            QScrollBar::handle:vertical:hover {{
                background: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.4);
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
            }}
        """)

        # Custom buttons inside groups
        group_btns_style = f"""
            QPushButton {{
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.05);
                color: {text_main};
                border: 1px solid {border};
                border-radius: 8px;
                font-family: 'Inter';
                font-weight: bold;
                font-size: 11px;
                padding: 6px 14px;
            }}
            QPushButton:hover {{
                background-color: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.15);
                border: 1px solid #00d4ff;
            }}
        """
        self.btn_browse_script.setStyleSheet(group_btns_style)
        self.btn_browse_dir.setStyleSheet(group_btns_style)
        self.btn_browse_output.setStyleSheet(group_btns_style)
        self.btn_browse_venv.setStyleSheet(group_btns_style)
        self.btn_browse_icon.setStyleSheet(group_btns_style)
        self.btn_refresh_assets.setStyleSheet(group_btns_style)
        self.btn_clear_console.setStyleSheet(group_btns_style)

        # Style Progress Bar
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                background: transparent;
                border: none;
            }}
            QProgressBar::chunk {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00d4ff, stop:1 #00ff9d);
                border-radius: 2px;
            }}
        """)

        # Style live Monospace Console
        console_fg = "#00ff9d" if self.is_dark else "#0d5c3a"
        self.txt_console.setStyleSheet(f"""
            QTextEdit {{
                background-color: {console_bg};
                color: {console_fg};
                border: 1px solid {border};
                border-radius: 12px;
                font-family: 'Consolas', 'JetBrains Mono', 'Monospace';
                font-size: 12px;
                padding: 10px;
            }}
        """)

        # Main Gradient Build button
        self.btn_build.setStyleSheet("""
            QPushButton#BuildBtn {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00d4ff, stop:1 #00ff9d);
                color: black;
                border: none;
                border-radius: 12px;
                font-weight: 800;
                letter-spacing: 1px;
            }
            QPushButton#BuildBtn:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00ffff, stop:1 #27ffc9);
            }
            QPushButton#BuildBtn:disabled {
                background: rgba(120, 120, 120, 0.2);
                color: rgba(255, 255, 255, 0.3);
            }
        """)

        # segmented control theme matching
        self.compiler_control.set_theme(self.is_dark)

        # MacOS style titlebar colors
        mac_btn_qss = """
            QPushButton#CloseBtn {
                background-color: #ff5f56;
                border: 1px solid #e0443e;
                border-radius: 8px;
            }
            QPushButton#CloseBtn:hover {
                background-color: #ff7b72;
            }
            QPushButton#MinBtn {
                background-color: #ffbd2e;
                border: 1px solid #dea123;
                border-radius: 8px;
            }
            QPushButton#MinBtn:hover {
                background-color: #ffca52;
            }
            QPushButton#MaxBtn {
                background-color: #27c93f;
                border: 1px solid #1aab29;
                border-radius: 8px;
            }
            QPushButton#MaxBtn:hover {
                background-color: #38e04f;
            }
        """
        self.setStyleSheet(self.styleSheet() + mac_btn_qss)

    # ----------------- WINDOW MOUSE DRAG DRAG CONTROLS -----------------
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            child = self.childAt(event.position().toPoint())
            # Allow dragging window only from Title Area labels/frames
            if not child or child == self.central_widget or isinstance(child, QLabel) and child.parent() == self:
                self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self._drag_pos.isNull():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        self._drag_pos = QPoint()
        event.accept()

    # ----------------- BUILD PROCESS TRIGGERS -----------------
    def append_log(self, text):
        """Appends logs to the styled terminal editor."""
        self.txt_console.moveCursor(QTextCursor.End)
        self.txt_console.insertPlainText(text)
        self.txt_console.verticalScrollBar().setValue(self.txt_console.verticalScrollBar().maximum())

    def update_progress(self, val):
        self.progress_bar.setValue(val)

    def start_build_process(self):
        """Gathers GUI form parameters and fires the asynchronous BuildRunner QProcess."""
        script = self.txt_script.text().strip()
        project = self.txt_proj_dir.text().strip()
        app_name = self.txt_app_name.text().strip()
        output_dir = self.txt_output_dir.text().strip()
        
        if not script or not os.path.exists(script):
            QMessageBox.critical(self, "Lỗi", "Vui lòng chọn file script (.py) chính hợp lệ!")
            return
            
        if not project or not os.path.exists(project):
            QMessageBox.critical(self, "Lỗi", "Vui lòng chọn thư mục dự án gốc hợp lệ!")
            return

        script_name = os.path.splitext(os.path.basename(script))[0]
        if not app_name or app_name == "StandAloneApp" or app_name == script_name:
            app_name = self.default_app_name_for_project(project)
            self.txt_app_name.setText(app_name)

        if self.is_default_output_dir(output_dir):
            output_dir = self.default_output_dir_for_project(project, self.compiler_control.active_mode)
            self.txt_output_dir.setText(output_dir)
            
        if not app_name:
            QMessageBox.critical(self, "Lỗi", "Vui lòng nhập tên ứng dụng thực thi mong muốn!")
            return

        if output_dir:
            try:
                os.makedirs(output_dir, exist_ok=True)
            except Exception as e:
                QMessageBox.critical(self, "Lỗi", f"Không thể tạo thư mục output:\n{output_dir}\n\nChi tiết: {e}")
                return

        if not self.asset_checks and not self.copy_file_checks:
            self.refresh_bundle_candidates()

        # Prepare Exclusions array (PyInstaller mode only)
        exclusions = []
        compiler = self.compiler_control.active_mode
        if compiler == "PyInstaller":
            for lib, chk in self.exclusion_checks.items():
                if chk.isChecked():
                    exclusions.append(lib)

        # Collect selected asset directories and sidecar files
        assets = [name for name, chk in self.asset_checks.items() if chk.isChecked()]
        copy_files = [name for name, chk in self.copy_file_checks.items() if chk.isChecked()]
        
        # Parse Hidden imports
        hidden_imports = [h.strip() for h in self.txt_hidden.text().split(",") if h.strip()]
        self.auto_detect_icon(project)
        icon_path = self.txt_icon.text().strip()

        build_config = {
            "compiler": compiler,
            "script_path": script,
            "project_dir": project,
            "output_dir": output_dir,
            "copy_base_dir": self._scan_base_dir(),
            "app_name": app_name,
            "venv_py": self.txt_venv.text().strip(),
            "python_isolation": self.chk_isolation.isChecked(),
            "isolated_flag": self.chk_isolated_flag.isChecked(),
            "windowed": self.chk_windowed.isChecked(),
            "icon_path": icon_path,
            "assets": assets,
            "copy_files": copy_files,
            "exclusions": exclusions,
            "hidden_imports": hidden_imports,
            "clean_build": self.chk_clean.isChecked(),
            "pyinstaller_cython": compiler == "PyInstaller" and self.chk_cython.isChecked()
        }

        self.save_last_build_settings(build_config)

        # Lock UI
        self.btn_build.setEnabled(False)
        self.btn_build.setText("ĐANG BIÊN DỊCH DỰ ÁN (COMPILING...)")
        self.lbl_status.setText("Trạng thái: Đang biên dịch... Vui lòng không tắt ứng dụng.")
        self.txt_console.clear()
        self.progress_bar.setValue(5)

        # Run compilation
        self.runner.start_build(build_config)

    def on_build_finished(self, success, output_dir):
        """Unlocks UI and shows success/failure notices."""
        self.btn_build.setEnabled(True)
        self.btn_build.setText("BẮT ĐẦU BIÊN DỊCH DỰ ÁN (BUILD STANDALONE)")
        
        if success:
            self.lbl_status.setText("Trạng thái: Biên dịch hoàn tất thành công!")
            self.progress_bar.setValue(100)
            
            QMessageBox.information(
                self, 
                "Thành công", 
                f"Dự án đã được biên dịch thành công thành tệp chạy độc lập!\n\nĐường dẫn: {output_dir}"
            )
            
            # Automatically open output path
            if os.path.exists(output_dir):
                os.startfile(output_dir)
        else:
            self.lbl_status.setText("Trạng thái: Quá trình biên dịch xảy ra lỗi.")
            self.progress_bar.setValue(0)
            QMessageBox.critical(
                self, 
                "Thất bại", 
                "Biên dịch thất bại! Vui lòng kiểm tra kỹ chi tiết mã lỗi ở Console ghi nhật ký."
            )
