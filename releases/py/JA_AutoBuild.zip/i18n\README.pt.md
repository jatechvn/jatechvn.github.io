# 🤖 JA_AutoBuild

<p align="center">
  <br>
  <i>**JA_AutoBuild** é um aplicativo desenvolvido em Python.</i>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.13-blue.svg?style=flat-square&logo=python" alt="Python Version">
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square" alt="License">
</p>

<p align="center"><a href="#quick-start">🚀 Quick Start</a> • <a href="#features">💡 Features</a> • <a href="#setup">📖 Setup</a> • <a href="https://jatechvn.github.io/">🌐 Website</a></p>

<p align="center"><a href="../README.md">🇺🇸 English</a> • <a href="README.vi.md">🇻🇳 Tiếng Việt</a> • <a href="README.zh-CN.md">🇨🇳 中文</a> • <a href="README.ja-JP.md">🇯🇵 日本語</a> • <a href="README.es.md">🇪🇸 Español</a> • <a href="README.fr.md">🇫🇷 Français</a> • <a href="README.de.md">🇩🇪 Deutsch</a> • <a href="README.ru.md">🇷🇺 Русский</a> • 🇵🇹 Português • <a href="README.ko.md">🇰🇷 한국어</a></p>

---

<a id="introduction"></a>
## Introdução

O projeto é padronizado de acordo com estruturas de projetos profissionais, suportando gerenciamento eficiente de código-fonte via Git.

<a id="features"></a>
## Recursos Principais

- Configuração rápida e empacotamento profissional.
- Configuração leve, fácil de manter e estender.
- Fluxo de trabalho de push automatizado para Git com o script incluso.

---

## Estrutura de Diretórios

```text
JA_AutoBuild/
├── main.py                    # Ponto de entrada do aplicativo
├── run.bat                    # Script de início rápido no Windows
├── requirements.txt           # Lista de dependências
├── config.ini                 # Arquivo de configuração simples
├── config.json                # Arquivo de configuração JSON estruturado
├── .gitignore                 # Padrões de exclusão do Git
├── README.md                  # Documentação do projeto (este arquivo)
├── LICENSE                    # Arquivo de licença
├── ABOUT.txt                  # Breve descrição do projeto
├── git_push.bat               # Script de push automático para o GitHub
│
├── logs/                      # Logs do aplicativo
│
├── modules/                   # Módulos principais contendo a lógica de negócios
│   ├── ui/                    # User Interface package
│   │   ├── __init__.py        # UI package marker
│   │   ├── main_window.py     # Main window interface
│   │   ├── styles.py          # UI stylesheet & styling
│   │   └── dialogs.py         # Popup dialogs (optional)
│   ├── native/                # Hybrid core engine package
│   │   ├── __init__.py        # Native core package marker
│   │   ├── win_core.py        # Windows optimized core (PowerShell/C++)
│   │   ├── mac_core.py        # macOS optimized core
│   │   └── linux_core.py      # Linux optimized core
│   ├── native_bridge.py       # Dynamic routing bridge to active OS core
│   ├── logic.py               # Core logic / Business rules
│   ├── utils.py               # Shared helper functions
│   ├── constants.py           # Global constants
│   └── logger_config.py       # Logger configuration
│
└── assets/                    # Recursos estáticos do aplicativo
```

---

<a id="setup"></a>
## Guia de Instalação e Uso

### Requisitos do Sistema
*   SO: **Windows 10/11**
*   Intérprete: **Python 3.13** ou ambiente equivalente.

<a id="quick-start"></a>
### Como Executar
1. Instalar as dependências necessárias:
   ```cmd
   pip install -r requirements.txt
   ```
2. Executar o aplicativo:
   ```cmd
   run.bat
   ```

---

## Licença

Este projeto está licenciado sob a **Licença MIT**. Consulte o arquivo [LICENSE](LICENSE) para obter detalhes.
