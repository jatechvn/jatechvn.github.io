import os
import json
import shutil
import subprocess
import sys
import time
from configparser import ConfigParser


def _app_base_dir() -> str:
    """Return the directory that contains the app's entry point.

    Works correctly in three scenarios:
    - Running from Python source:   returns the directory of main.py (via sys.argv[0])
    - Running as Nuitka standalone: sys.frozen is set → use sys.executable directory
    - Running interactively/pytest: falls back to os.getcwd()
    """
    if getattr(sys, "frozen", False):
        # Nuitka / PyInstaller frozen build: sys.executable == path to .exe
        return os.path.dirname(os.path.abspath(sys.executable))
    # Normal Python run: use the directory of the entry script
    entry = sys.argv[0] if sys.argv else ""
    if entry and os.path.isfile(entry):
        return os.path.dirname(os.path.abspath(entry))
    return os.path.abspath(os.getcwd())


CONFIG_INI = os.path.join(_app_base_dir(), "config.ini")
LAST_BUILD_SECTION = "LAST_BUILD"

def ensure_project_dirs():
    """Ensure necessary directories exist for the Auto-Builder tool."""
    dirs = [
        os.path.join(os.getcwd(), "logs"),
        os.path.join(os.getcwd(), "presets")
    ]
    for d in dirs:
        os.makedirs(d, exist_ok=True)

def find_venv_in_project(project_path):
    """
    Search for a Python virtual environment in the selected project folder.
    Returns the path to the python.exe executable, or None if not found.
    """
    if not project_path or not os.path.exists(project_path):
        return None
        
    common_venv_names = [".venv", "venv", "env", "python_env"]
    for name in common_venv_names:
        venv_dir = os.path.join(project_path, name)
        python_exe = os.path.join(venv_dir, "Scripts", "python.exe")
        if os.path.exists(python_exe) and is_python_executable_usable(python_exe):
            return python_exe
    return None

def project_venv_python(project_path):
    """Return the conventional project .venv python.exe path."""
    return os.path.join(project_path, ".venv", "Scripts", "python.exe")

def ensure_project_venv(project_path, log_callback=None):
    """Create or replace a broken project-local .venv for the current Windows user."""
    if not project_path or not os.path.isdir(project_path):
        return "", "Project path does not exist."

    venv_dir = os.path.join(project_path, ".venv")
    python_exe = project_venv_python(project_path)
    if is_python_executable_usable(python_exe):
        return python_exe, ""

    if log_callback:
        log_callback(
            "[VENV] .venv không chạy được hoặc trỏ sang user/máy khác. "
            "Đang tạo lại .venv sạch bằng Python hiện tại...\n"
        )

    if os.path.isdir(venv_dir):
        backup_dir = _unique_backup_path(venv_dir)
        try:
            shutil.move(venv_dir, backup_dir)
        except Exception as e:
            return "", f"Could not move broken .venv to backup: {e}"
        if log_callback:
            log_callback(f"[VENV] Đã backup .venv cũ: {backup_dir}\n")

    venv_args = [sys.executable, "-m", "venv", venv_dir]

    try:
        result = subprocess.run(
            venv_args,
            cwd=project_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=180
        )
    except Exception as e:
        return "", str(e)

    if result.returncode != 0:
        detail = (result.stderr or result.stdout or f"Exited with code {result.returncode}").strip()
        return "", detail

    if is_python_executable_usable(python_exe):
        if log_callback:
            log_callback(f"[VENV] .venv đã sẵn sàng: {python_exe}\n")
        return python_exe, ""

    return "", describe_python_executable_error(python_exe)

def _unique_backup_path(path):
    """Return a non-existing backup path next to the original path."""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    base = f"{path}.bak_{timestamp}"
    candidate = base
    suffix = 1
    while os.path.exists(candidate):
        suffix += 1
        candidate = f"{base}_{suffix}"
    return candidate

def is_python_executable_usable(python_exe):
    """Return True only if a Python executable can start successfully."""
    if not python_exe or not os.path.exists(python_exe):
        return False
    try:
        result = subprocess.run(
            [python_exe, "-c", "import sys; print(sys.executable)"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=8
        )
        return result.returncode == 0
    except Exception:
        return False

def describe_python_executable_error(python_exe):
    """Return the startup error for a Python executable, if any."""
    if not python_exe or not os.path.exists(python_exe):
        return "Python executable does not exist."
    try:
        result = subprocess.run(
            [python_exe, "-c", "import sys; print(sys.executable)"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=8
        )
        if result.returncode == 0:
            return ""
        return (result.stderr or result.stdout or f"Exited with code {result.returncode}").strip()
    except Exception as e:
        return str(e)

def load_build_profile(profile_path):
    """Loads a saved build configuration profile."""
    if os.path.exists(profile_path):
        try:
            with open(profile_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_build_profile(profile_path, data):
    """Saves the current build settings to a JSON profile."""
    try:
        os.makedirs(os.path.dirname(profile_path), exist_ok=True)
        with open(profile_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        return True
    except Exception:
        return False

def load_last_build_config(config_path=CONFIG_INI):
    """Load the most recent build settings from config.ini."""
    parser = ConfigParser()
    parser.optionxform = str
    if not os.path.exists(config_path):
        return {}
    try:
        parser.read(config_path, encoding="utf-8")
    except Exception:
        return {}
    if not parser.has_section(LAST_BUILD_SECTION):
        return {}
    return dict(parser.items(LAST_BUILD_SECTION))

def save_last_build_config(data, config_path=CONFIG_INI):
    """Persist the most recent build settings to config.ini without touching other sections."""
    parser = ConfigParser()
    parser.optionxform = str
    if os.path.exists(config_path):
        try:
            parser.read(config_path, encoding="utf-8")
        except Exception:
            parser = ConfigParser()
            parser.optionxform = str

    if not parser.has_section(LAST_BUILD_SECTION):
        parser.add_section(LAST_BUILD_SECTION)

    for key, value in data.items():
        if isinstance(value, bool):
            value = "1" if value else "0"
        elif value is None:
            value = ""
        parser.set(LAST_BUILD_SECTION, key, str(value))

    try:
        with open(config_path, "w", encoding="utf-8") as f:
            parser.write(f)
        return True
    except Exception:
        return False

def config_bool(value, default=False):
    """Parse a config.ini boolean value."""
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "yes", "true", "on"}
