MyProject/
├── main.py                    # Điểm vào chương trình (entry point)
├── run.bat                    # Script khởi động nhanh trên Windows (chạy main.py)
├── requirements.txt           # Danh sách thư viện cần thiết (dùng với pip install -r)
├── config.ini                 # File cấu hình đơn giản dạng key=value (section-based)
├── config.json                # File cấu hình dạng cấu trúc lồng nhau (nested, list, dict...)
├── .gitignore                 # Git bỏ qua: .venv/, logs/, assets/temp/, __pycache__/...
├── README.md                  # Tài liệu giới thiệu chính bằng Tiếng Anh (English) - Giao diện chính của Repo
├── LICENSE                    # File giấy phép sử dụng mã nguồn (MIT, Apache, v.v.)
├── ABOUT.txt                  # Thẻ thông tin dự án chuyên nghiệp dùng làm mô tả trên GitHub
├── git_push.bat               # Script tự động đẩy code lên GitHub nhanh chóng
│
├── i18n/                      # Thư mục chứa tài liệu đa ngôn ngữ (Internationalization - 10 ngôn ngữ)
│   ├── README.zh-CN.md        # Tiếng Trung (Chinese - Simplified)
│   ├── README.vi.md           # Tiếng Việt (Vietnamese)
│   ├── README.ja.md           # Tiếng Nhật (Japanese)
│   ├── README.ko.md           # Tiếng Hàn (Korean)
│   ├── README.es.md           # Tiếng Tây Ban Nha (Spanish)
│   ├── README.fr.md           # Tiếng Pháp (French)
│   ├── README.de.md           # Tiếng Đức (German)
│   ├── README.ru.md           # Tiếng Nga (Russian)
│   └── README.pt-BR.md        # Tiếng Bồ Đào Nha (Portuguese - Brazil)
│
├── logs/                      # Nhật ký hoạt động của ứng dụng
│   └── yyyy-mm-dd.log         # Log chia theo ngày (lỗi, thông báo hệ thống, debug)
│
├── modules/                   # Các module xử lý chính
│   ├── __init__.py            # Đánh dấu thư mục là Python package
│   ├── ui.py                  # Giao diện người dùng (PySide6 / Tkinter...)
│   ├── logic.py               # Logic nghiệp vụ, xử lý dữ liệu cốt lõi
│   ├── utils.py               # Hàm tiện ích dùng chung (helper functions)
│   ├── constants.py           # Hằng số toàn cục (màu sắc, đường dẫn cố định, giới hạn...)
│   └── logger_config.py       # Cấu hình logging tập trung dùng cho toàn bộ module
│
└── assets/                    # Tài nguyên tĩnh của ứng dụng
    ├── images/                # Hình ảnh, icon (icon.ico, logo.png...)
    ├── sounds/                # File âm thanh đầu ra hoặc âm thanh mẫu
    ├── fonts/                 # Font chữ tùy chỉnh (nếu có)
    ├── models/                # Model AI / file trọng số (KHÔNG commit nếu quá lớn)
    ├── presets/               # Dữ liệu preset người dùng (presets.json, file âm thanh mẫu...)
    ├── data/                  # Dữ liệu đầu vào tĩnh (từ điển, danh sách từ khóa...)
    │   └── example.csv        # Dữ liệu dạng bảng (cấu hình theo hàng/cột, danh sách mẫu...)
    └── temp/                  # File tạm thời sinh ra khi chạy (tự động xóa, KHÔNG commit)

================================================================================
🧩 GỢI Ý TÁCH NHỎ LOGIC
================================================================================

Không nên dồn toàn bộ xử lý vào một file `logic.py` quá lớn. Khi dự án bắt đầu có nhiều tính năng,
hãy tách logic theo chức năng để tránh nhầm lẫn khi sửa lỗi và dễ test hơn.

Ví dụ:

```text
modules/
├── ui.py
├── logic.py              # Chỉ giữ logic điều phối chính nếu cần
├── file_service.py       # Xử lý đọc/ghi file, đường dẫn, export
├── api_client.py         # Gọi API / request HTTP
├── data_parser.py        # Parse dữ liệu đầu vào
├── validators.py         # Kiểm tra dữ liệu nhập
├── workers.py            # Thread / background task
└── utils.py              # Helper nhỏ dùng chung
```

Nguyên tắc: file nào sửa một lỗi/tính năng thì chỉ nên chạm vào đúng khu vực liên quan.

================================================================================
🌿 GIT / .gitignore CHUẨN
================================================================================

File `.gitignore` nên có nội dung cơ bản sau:

```ini
# Virtual environment
.venv/
venv/
ENV/

# Python cache / compiled files
__pycache__/
*.py[cod]
*$py.class
*.pyd

# Build output
build/
dist/
build_pyinstall/
build_nuitka/
*.spec

# Logs and temporary files
logs/*.log
assets/temp/

# Local IDE / OS files
.vscode/
.idea/
.DS_Store
Thumbs.db

# Personal config - bỏ comment nếu config có password/token/key riêng
# config.ini
# config.json
```

Nếu quản lý nhiều template, nên dùng một repo `python-template` và tách branch:

```bash
git checkout main        # nokey cơ bản
git checkout nokey-venv  # nokey + .venv
git checkout key         # key/license
git checkout key-venv    # key/license + .venv
```

Khi tạo project mới từ template:

```bash
git clone <url-template> my-new-project
cd my-new-project
git checkout main
git init
git add .
git commit -m "Initial commit from nokey template"
```

Gợi ý tạo file `git_push.bat` để tự đẩy project lên GitHub:

```bat
@echo off
cd /d %~dp0

set /p remote_url="Nhap GitHub repo URL: "
set /p commit_msg="Nhap commit message: "
if "%commit_msg%"=="" set commit_msg=Update project

if not exist ".git" (
    git init
    git branch -M main
)

git add .
git commit -m "%commit_msg%"
git remote remove origin 2>nul
git remote add origin "%remote_url%"
git push -u origin main

pause
```

================================================================================
🐍 PYTHON MẶC ĐỊNH
================================================================================

- Mặc định dùng Python 3.13 để chạy và build chương trình.
- Trên Windows, ưu tiên `py -3.13` hoặc `python` đang trỏ đúng tới Python 3.13 trong PATH.
- Bản sample này không dùng `.venv`, nên dependency được cài vào Python 3.13 đang dùng trên máy.

================================================================================
💡 KINH NGHIỆM ĐẶC THÙ TRÊN WINDOWS: CẤU HÌNH ICON TASKBAR (AppUserModelID)
================================================================================
Khi ứng dụng Python (dùng PySide6/PyQt/Tkinter) chạy trên Windows qua python.exe 
hoặc môi trường ảo .venv, Windows sẽ gom nhóm cửa sổ của bạn vào tiến trình chung 
của Python và hiển thị icon mặc định của Python trên Taskbar (thay vì icon của bạn).

Để giải quyết triệt để vấn đề này, hãy chèn đoạn code sau vào đầu file 'main.py' 
(ngay sau phần import và TRƯỚC khi khởi tạo QApplication):

```python
import sys
import os
import ctypes

# Buộc Windows nhận diện đây là một ứng dụng độc lập độc nhất trên Taskbar
# thay vì nhóm nó dưới tiến trình chung "python.exe" của Python.
myappid = 'MyCompany.MyProduct.SubProduct.Version' # Đặt ID riêng tùy ý
try:
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
except Exception:
    pass

from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QIcon

# Trong hàm khởi tạo app:
# app = QApplication(sys.argv)
# icon_path = os.path.join(os.path.dirname(__file__), "assets", "images", "icon.ico")
# app.setWindowIcon(QIcon(icon_path))
```

================================================================================
📝 THẺ THÔNG TIN DỰ ÁN (ABOUT.txt)
================================================================================

Tệp 'ABOUT.txt' đóng vai trò là thẻ thông tin tiêu chuẩn của dự án, được công cụ 
JA Auto Git sử dụng để đồng bộ trực tiếp lên phần mô tả (About Description) của kho 
chứa trên GitHub.

Cấu trúc chuẩn chuyên nghiệp của tệp 'ABOUT.txt' (dạng Project Information Card):

```text
========================================================================
                       PROJECT INFORMATION CARD
========================================================================
Project Name : <Tên_Dự_Án>
Tech Stack   : <Công_Nghệ_Sử_Dụng> (Ví dụ: Python 3.13 / PySide6 (Qt))
Managed By   : JA Auto Git
Website      : https://jatechvn.github.io/
------------------------------------------------------------------------
Description  : <Câu_Mô_Tả_Ngắn_Gọn_Và_Chuyên_Nghiệp_Dành_Cho_GitHub>
========================================================================
```

Lưu ý: 
- Dòng bắt đầu bằng 'Description  :' sẽ được JA Auto Git tự động trích xuất thông minh để làm nội dung mô tả kho lưu trữ trên GitHub.
- Nếu bạn thay đổi định dạng tệp sang văn bản thông thường không có dòng 'Description  :', dòng đầu tiên của tệp sẽ được lấy làm mô tả dự phòng.
