import os
import shutil
import subprocess
import sys
import time
import gc
from PySide6.QtCore import QObject, Signal, QProcess, QProcessEnvironment
from modules.cython_builder import ensure_cython_dependencies, prepare_cython_staging
from modules.logger_config import setup_logger
from modules.utils import describe_python_executable_error, ensure_project_venv

logger = setup_logger()

class BuildRunner(QObject):
    log_received = Signal(str)
    finished = Signal(bool, str) # (success, output_directory)
    progress_updated = Signal(int)

    def __init__(self):
        super().__init__()
        self.process = None
        self.config = {}
        self.project_dir = ""
        self.output_dir = ""

    def start_build(self, config):
        """Starts the asynchronous build process using QProcess."""
        self.config = config
        self.project_dir = config.get("project_dir", "")
        script_path = config.get("script_path", "")
        compiler = config.get("compiler", "PyInstaller") # "PyInstaller" or "Nuitka"
        
        if not self.project_dir or not os.path.exists(self.project_dir):
            self.log_received.emit("[ERROR] Thư mục dự án không hợp lệ!")
            self.finished.emit(False, "")
            return
            
        if not script_path or not os.path.exists(script_path):
            self.log_received.emit("[ERROR] File thực thi chính (entry point) không hợp lệ!")
            self.finished.emit(False, "")
            return

        output_parent_dir = self._resolve_output_parent_dir(config)
        try:
            os.makedirs(output_parent_dir, exist_ok=True)
        except Exception as e:
            self.log_received.emit(f"[ERROR] Không thể tạo thư mục output: {output_parent_dir}\nChi tiết: {e}")
            self.finished.emit(False, "")
            return

        app_name = config.get("app_name", "StandAloneApp")
        existing_output = os.path.join(output_parent_dir, app_name)
        if os.path.exists(existing_output):
            if not self._remove_path_with_retries(existing_output):
                self.log_received.emit(
                    "[ERROR] Không thể xóa output cũ trước khi build:\n"
                    f"    {existing_output}\n\n"
                    "Thư mục này có thể đang bị khóa bởi app đang chạy, File Explorer, antivirus hoặc OneDrive.\n"
                    "Hãy đóng app build cũ/Explorer đang mở thư mục này rồi build lại, hoặc chọn Output Directory khác.\n"
                )
                self.finished.emit(False, "")
                return

        if compiler == "Nuitka" and not self._prepare_nuitka_output_paths(config):
            self.finished.emit(False, "")
            return

        # Initialize QProcess
        self.process = QProcess(self)
        self.process.setWorkingDirectory(self.project_dir)
        
        # Configure Environment Variables
        process_env = QProcessEnvironment.systemEnvironment()
        
        # 1. Environment Isolation (PYTHONNOUSERSITE)
        if config.get("python_isolation", True):
            process_env.insert("PYTHONNOUSERSITE", "1")
            self.log_received.emit("[INFO] Đã bật chế độ cô lập Python (PYTHONNOUSERSITE=1)\n")
            
        # 2. Resolve or repair project-local Python environment.
        venv_py = config.get("venv_py", "")
        if not venv_py:
            venv_py, venv_error = ensure_project_venv(self.project_dir, self.log_received.emit)
            if venv_error:
                self.log_received.emit(f"[WARNING] Không thể chuẩn bị .venv cục bộ. Sẽ dùng Python đang chạy app.\nChi tiết: {venv_error}\n")
        elif describe_python_executable_error(venv_py):
            repaired_venv_py, venv_error = ensure_project_venv(self.project_dir, self.log_received.emit)
            if repaired_venv_py:
                venv_py = repaired_venv_py
                self.log_received.emit(f"[VENV] Đã chuyển sang .venv đã repair: {venv_py}\n")
            else:
                self.log_received.emit(f"[WARNING] Không thể repair .venv cục bộ.\nChi tiết: {venv_error}\n")

        # 3. Automatically resolve PyTorch DLL pathways if torch is present in venv
        if venv_py:
            venv_root = os.path.dirname(os.path.dirname(venv_py))
            torch_lib = os.path.join(venv_root, "Lib", "site-packages", "torch", "lib")
            if os.path.exists(torch_lib):
                current_path = process_env.value("PATH")
                process_env.insert("PATH", f"{torch_lib};{current_path}")
                self.log_received.emit(f"[INFO] Phát hiện PyTorch! Đã nhúng đường dẫn CUDA DLLs: {torch_lib}\n")
                
        self.process.setProcessEnvironment(process_env)

        # 4. Setup Python Executable to execute
        python_exe = venv_py if venv_py else sys.executable
        python_error = describe_python_executable_error(python_exe)
        if python_error:
            self.log_received.emit(
                "[ERROR] Python dùng để build không chạy được:\n"
                f"    {python_exe}\n\n"
                f"Chi tiết:\n{python_error}\n\n"
                "Cách sửa: tạo lại .venv bằng Python đang tồn tại trên máy hiện tại, ví dụ:\n"
                f'    "{sys.executable}" -m venv "{os.path.join(self.project_dir, ".venv")}"\n'
                f'    "{os.path.join(self.project_dir, ".venv", "Scripts", "python.exe")}" -m pip install -r "{os.path.join(self.project_dir, "requirements.txt")}" pyinstaller\n'
            )
            self.finished.emit(False, "")
            return

        if not self._ensure_build_dependencies(python_exe, compiler):
            self.finished.emit(False, "")
            return

        if compiler == "PyInstaller" and config.get("pyinstaller_cython", False):
            if not ensure_cython_dependencies(python_exe, self.project_dir, self.log_received.emit):
                self.finished.emit(False, "")
                return
            try:
                staged_script, staging_dir = prepare_cython_staging(
                    self.project_dir,
                    script_path,
                    output_parent_dir,
                    app_name,
                    python_exe,
                    self.log_received.emit,
                )
            except Exception as e:
                self.log_received.emit(f"[ERROR] Chuẩn bị Cython staging thất bại: {e}\n")
                self.finished.emit(False, "")
                return

            config = dict(config)
            config["_original_script_path"] = script_path
            config["script_path"] = staged_script
            config["_build_working_dir"] = staging_dir
            config["_cython_staging_dir"] = staging_dir
            self.config = config
            self.log_received.emit("[CYTHON] PyInstaller sẽ build từ staging đã Cython hóa.\n")
        
        # 5. Generate Command Arguments
        args = []
        if config.get("isolated_flag", True):
            args.append("-s") # Ignore user site-packages
            
        if compiler == "PyInstaller":
            args.extend(["-m", "PyInstaller"])
            args.extend(self._build_pyinstaller_args(config))
        else:
            args.extend(["-m", "nuitka"])
            args.extend(self._build_nuitka_args(config))

        # Output final build command to GUI terminal
        full_command = subprocess.list2cmdline([python_exe] + args)
        self.log_received.emit("=" * 80)
        self.log_received.emit(f"[BUILDING] Đang chạy lệnh biên dịch:\n{full_command}\n")
        self.log_received.emit(f"[OUTPUT] Thư mục xuất build: {output_parent_dir}\n")
        self.log_received.emit("=" * 80 + "\n")
        
        # Connect signals for live terminal capture
        self.process.readyReadStandardOutput.connect(self._handle_stdout)
        self.process.readyReadStandardError.connect(self._handle_stderr)
        self.process.finished.connect(self._handle_finished)

        build_working_dir = self.config.get("_build_working_dir", self.project_dir)
        self.process.setWorkingDirectory(build_working_dir)
        
        # Launch build process
        self.process.start(python_exe, args)

    def stop_build(self):
        """Kills the active build process."""
        if self.process and self.process.state() == QProcess.Running:
            self.process.kill()
            self.log_received.emit("\n[STOPPED] Tiến trình biên dịch đã bị hủy bởi người dùng!")
            self.finished.emit(False, "")

    def _handle_stdout(self):
        data = self.process.readAllStandardOutput()
        stdout_str = data.data().decode("utf-8", errors="replace")
        self.log_received.emit(stdout_str)
        self._check_progress(stdout_str)

    def _handle_stderr(self):
        data = self.process.readAllStandardError()
        stderr_str = data.data().decode("utf-8", errors="replace")
        self.log_received.emit(stderr_str)
        self._check_progress(stderr_str)

    def _check_progress(self, text):
        """Scans compiler logs to update build progress bar values (approximated)."""
        # PyInstaller progress hints
        if "INFO: Building EXE" in text or "Building EXE" in text:
            self.progress_updated.emit(60)
        elif "INFO: Building PKG" in text:
            self.progress_updated.emit(40)
        elif "INFO: Looking for dynamic libraries" in text:
            self.progress_updated.emit(20)
            
        # Nuitka progress hints
        elif "Pass 1:" in text:
            self.progress_updated.emit(30)
        elif "Backend C++ compiler" in text:
            self.progress_updated.emit(50)
        elif "Linking" in text:
            self.progress_updated.emit(80)

    def _handle_finished(self, exit_code, exit_status):
        success = (exit_code == 0 and exit_status == QProcess.NormalExit)
        
        if success:
            self.progress_updated.emit(90)
            self.log_received.emit("\n[SUCCESS] Biên dịch chính hoàn tất! Đang xử lý các tệp cấu hình...")
            
            # Post-build copy and rename logic
            compiler = self.config.get("compiler", "PyInstaller")
            app_name = self.config.get("app_name", "StandAloneApp")
            output_parent_dir = self._resolve_output_parent_dir(self.config)
            
            # Resolve Output Directory
            if compiler == "PyInstaller":
                self.output_dir = os.path.join(output_parent_dir, app_name)
            else:
                # Nuitka creates <entry-script-name>.dist, then we rename it to app_name.
                script_name = os.path.splitext(os.path.basename(self.config.get("script_path", "main.py")))[0]
                nuitka_dist = os.path.join(output_parent_dir, f"{script_name}.dist")
                self.output_dir = os.path.join(output_parent_dir, app_name)
                
                if os.path.exists(nuitka_dist):
                    if os.path.exists(self.output_dir):
                        try:
                            shutil.rmtree(self.output_dir)
                        except Exception:
                            pass
                    try:
                        os.rename(nuitka_dist, self.output_dir)
                        self.log_received.emit(f"[INFO] Đã đổi tên thư mục Nuitka sang: {self.output_dir}")
                    except Exception as e:
                        self.log_received.emit(f"[WARNING] Không thể đổi tên thư mục Nuitka sang {app_name}. Chi tiết: {e}")
                        self.output_dir = nuitka_dist

            # Copy User Configuration files (dynamic config.json / config.ini) next to .exe
            config_files = self.config.get("copy_files", [])
            if config_files and os.path.exists(self.output_dir):
                copy_base_dir = self.config.get("copy_base_dir", "") or self.project_dir
                for filename in config_files:
                    filename = filename.strip()
                    if not filename:
                        continue
                    src_file = os.path.join(copy_base_dir, filename)
                    dst_file = os.path.join(self.output_dir, filename)
                    if os.path.exists(src_file):
                        try:
                            destinations = [dst_file]
                            if compiler == "PyInstaller":
                                destinations.append(os.path.join(self.output_dir, "_internal", filename))
                            for destination in destinations:
                                os.makedirs(os.path.dirname(destination), exist_ok=True)
                                shutil.copy2(src_file, destination)
                                self.log_received.emit(f"[COPY] Đã copy cấu hình: {filename} -> {destination}")
                        except Exception as e:
                            self.log_received.emit(f"[WARNING] Không thể copy {filename}. Chi tiết: {e}")
            
            # Cleanup Temp Folders
            if self.config.get("clean_build", True):
                self.log_received.emit("[CLEAN] Đang dọn dẹp thư mục build tạm thời...")
                build_folder = os.path.join(self.project_dir, "build")
                script_name = os.path.splitext(os.path.basename(self.config.get("_original_script_path", self.config.get("script_path", "main.py"))))[0]
                nuitka_build_folder = os.path.join(output_parent_dir, f"{script_name}.build")
                legacy_nuitka_build_folder = os.path.join(self.project_dir, f"{script_name}.build")
                spec_file = os.path.join(self.project_dir, f"{app_name}.spec")
                
                if os.path.exists(build_folder):
                    self._cleanup_temp_path(build_folder)
                if os.path.exists(nuitka_build_folder):
                    self._cleanup_temp_path(nuitka_build_folder)
                if os.path.exists(legacy_nuitka_build_folder):
                    self._cleanup_temp_path(legacy_nuitka_build_folder)
                if os.path.exists(spec_file):
                    self._cleanup_temp_path(spec_file)
                self._cleanup_cython_staging()
                self.log_received.emit("[CLEAN] Dọn dẹp hoàn tất!")

            self.progress_updated.emit(100)
            self.log_received.emit("\n==============================================================================")
            self.log_received.emit("                    BIÊN DỊCH HOÀN TẤT THÀNH CÔNG!")
            self.log_received.emit(f"[+] Ứng dụng độc lập của bạn đã sẵn sàng tại:\n    {self.output_dir}")
            self.log_received.emit("==============================================================================")
            self.finished.emit(True, self.output_dir)
        else:
            self.progress_updated.emit(0)
            self.log_received.emit(f"\n[ERROR] Biên dịch thất bại với mã lỗi: {exit_code}")
            if self.config.get("clean_build", True):
                self._cleanup_cython_staging()
            self.finished.emit(False, "")

    def _prepare_nuitka_output_paths(self, config):
        """Remove stale Nuitka output folders before starting a new build."""
        output_parent_dir = self._resolve_output_parent_dir(config)
        script_name = os.path.splitext(os.path.basename(config.get("script_path", "main.py")))[0]
        stale_dist = os.path.join(output_parent_dir, f"{script_name}.dist")
        stale_build = os.path.join(output_parent_dir, f"{script_name}.build")

        if os.path.exists(stale_dist):
            self.log_received.emit(f"[CLEAN] Xóa output Nuitka cũ: {stale_dist}\n")
            if not self._remove_path_with_retries(stale_dist, attempts=8, delay=1.0):
                self.log_received.emit(
                    "[ERROR] Không thể xóa thư mục .dist cũ trước khi build:\n"
                    f"    {stale_dist}\n\n"
                    "Hãy đóng app đang chạy, File Explorer, hoặc tạm dừng đồng bộ/antivirus đang khóa thư mục này rồi build lại.\n"
                )
                return False

        if os.path.exists(stale_build):
            self.log_received.emit(f"[CLEAN] Thử xóa thư mục build tạm Nuitka cũ: {stale_build}\n")
            if not self._remove_path_with_retries(stale_build, attempts=60, delay=1.0):
                self.log_received.emit(
                    "[WARNING] Chưa xóa được thư mục build tạm cũ. Sẽ tiếp tục build vì đây chỉ là thư mục tạm:\n"
                    f"    {stale_build}\n"
                )
        return True

    def _resolve_output_parent_dir(self, config):
        """Returns the parent folder that receives build output folders."""
        output_dir = config.get("output_dir", "").strip()
        if not output_dir:
            folder_name = "build_nuitka" if config.get("compiler") == "Nuitka" else "build_pyinstall"
            output_dir = os.path.join(self.project_dir, folder_name)
        if not os.path.isabs(output_dir):
            output_dir = os.path.join(self.project_dir, output_dir)
        return os.path.abspath(output_dir)

    def _remove_path_with_retries(self, path, attempts=5, delay=0.6):
        for attempt in range(attempts):
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path)
                elif os.path.exists(path):
                    os.remove(path)
                return True
            except PermissionError as e:
                self.log_received.emit(f"[WARNING] Output đang bị khóa, thử lại {attempt + 1}/{attempts}: {e}\n")
                time.sleep(delay)
            except Exception as e:
                self.log_received.emit(f"[WARNING] Không thể xóa output cũ, thử lại {attempt + 1}/{attempts}: {e}\n")
                time.sleep(delay)
        return not os.path.exists(path)

    def _cleanup_temp_path(self, path):
        """Best-effort cleanup for build temp folders that antivirus/OneDrive may hold briefly."""
        gc.collect()
        if self._remove_path_with_retries(path, attempts=60, delay=1.0):
            return True
        self.log_received.emit(
            "[WARNING] Chưa xóa được thư mục/file tạm vì đang bị Windows/OneDrive/antivirus khóa:\n"
            f"    {path}\n"
            "Bạn có thể xóa thủ công sau vài phút, hoặc build lại để chương trình thử dọn tiếp.\n"
        )
        return False

    def _cleanup_cython_staging(self):
        staging_dir = self.config.get("_cython_staging_dir", "")
        if staging_dir and os.path.exists(staging_dir):
            self.log_received.emit(f"[CYTHON] Dọn staging: {staging_dir}\n")
            self._cleanup_temp_path(staging_dir)

    def _run_setup_command(self, args, description):
        self.log_received.emit(f"[SETUP] {description}:\n{subprocess.list2cmdline(args)}\n")
        try:
            result = subprocess.run(
                args,
                cwd=self.project_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=600
            )
        except Exception as e:
            self.log_received.emit(f"[ERROR] {description} thất bại: {e}\n")
            return False

        if result.stdout:
            self.log_received.emit(result.stdout)
        if result.returncode != 0:
            self.log_received.emit(f"[ERROR] {description} thất bại với mã lỗi: {result.returncode}\n")
            return False
        return True

    def _python_module_available(self, python_exe, module_name):
        try:
            result = subprocess.run(
                [python_exe, "-m", module_name, "--version"],
                cwd=self.project_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=30
            )
            return result.returncode == 0
        except Exception:
            return False

    def _ensure_build_dependencies(self, python_exe, compiler):
        module_name = "PyInstaller" if compiler == "PyInstaller" else "nuitka"
        package_name = "pyinstaller" if compiler == "PyInstaller" else "nuitka"
        if self._python_module_available(python_exe, module_name):
            return True

        self.log_received.emit(f"[SETUP] Chưa có {package_name} trong Python build. Đang cài dependency cần thiết...\n")

        requirements_path = os.path.join(self.project_dir, "requirements.txt")
        if os.path.exists(requirements_path):
            if not self._run_setup_command(
                [python_exe, "-m", "pip", "install", "-r", requirements_path],
                "Cài requirements.txt"
            ):
                return False

        if not self._run_setup_command(
            [python_exe, "-m", "pip", "install", package_name],
            f"Cài {package_name}"
        ):
            return False

        if not self._python_module_available(python_exe, module_name):
            self.log_received.emit(f"[ERROR] Đã cài {package_name} nhưng vẫn không import/chạy được module {module_name}.\n")
            return False

        return True

    def _build_pyinstaller_args(self, config):
        """Constructs PyInstaller arguments."""
        app_name = config.get("app_name", "StandAloneApp")
        script_path = config.get("script_path", "")
        output_parent_dir = self._resolve_output_parent_dir(config)
        
        args = [
            "--name", app_name,
            "--noconfirm",
            "--onedir",
            "--distpath", output_parent_dir
        ]
        
        if config.get("windowed", True):
            args.append("--windowed")
        else:
            args.append("--nowindowed")
            
        icon_path = config.get("icon_path", "")
        if icon_path and os.path.exists(icon_path):
            args.extend(["--icon", icon_path])

        # Add asset folders (comma/semicolon separated)
        assets = config.get("assets", [])
        for asset in assets:
            asset = asset.strip()
            if not asset:
                continue
            # Support src;dst or just src
            if ";" in asset:
                args.extend(["--add-data", asset])
            elif "=" in asset:
                # convert Nuitka format = to ; for safety
                args.extend(["--add-data", asset.replace("=", ";")])
            else:
                args.extend(["--add-data", f"{asset};{asset}/"])

        # Add hidden imports
        hidden_imports = config.get("hidden_imports", [])
        for imp in hidden_imports:
            imp = imp.strip()
            if imp:
                args.extend(["--hidden-import", imp])

        # Exclusions list to shrink size
        exclusions = config.get("exclusions", [])
        for exc in exclusions:
            exc = exc.strip()
            if exc:
                args.extend(["--exclude-module", exc])

        # Appending script path
        args.append(script_path)
        return args

    def _build_nuitka_args(self, config):
        """Constructs Nuitka arguments."""
        script_path = config.get("script_path", "")
        app_name = config.get("app_name", "StandAloneApp")
        output_parent_dir = self._resolve_output_parent_dir(config)
        
        args = [
            "--standalone",
            "--assume-yes-for-downloads",
            f"--output-dir={output_parent_dir}"
        ]
        
        # Always output file name
        args.append(f'--output-filename={app_name}.exe')

        if config.get("windowed", True):
            args.append("--windows-console-mode=disable")
        else:
            args.append("--windows-console-mode=force")
            
        icon_path = config.get("icon_path", "")
        if icon_path and os.path.exists(icon_path):
            args.append(f'--windows-icon-from-ico={icon_path}')

        # Add PySide6 plugins if PySide6/PyQt is detected
        args.append("--enable-plugin=pyside6")

        # Nuitka asset directories copying
        assets = config.get("assets", [])
        for asset in assets:
            asset = asset.strip()
            if not asset:
                continue
            if ";" in asset:
                # convert PyInstaller ; to Nuitka =
                parts = asset.split(";")
                args.append(f'--include-data-dir={parts[0]}={parts[1]}')
            elif "=" in asset:
                args.append(f'--include-data-dir={asset}')
            else:
                args.append(f'--include-data-dir={asset}={asset}')

        # Nuitka doesn't support basic --exclude-module for normal Python stdlib,
        # but we can pass standard standard compiler flags or enable compression
        # Nuitka handles dependencies statically, we can pass disable plugin flags if needed.
        
        args.append(script_path)
        return args
