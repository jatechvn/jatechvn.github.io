import os
import logging
import platform
import sys
from datetime import datetime
from modules.utils import _app_base_dir

def setup_logger():
    # Make sure logs directory exists next to the exe / entry script
    log_dir = os.path.join(_app_base_dir(), "logs")
    os.makedirs(log_dir, exist_ok=True)
    
    logger = logging.getLogger("PythonAutoBuilder")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    
    # Avoid duplicate handlers if already configured
    if logger.handlers:
        return logger
        
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(process)d:%(threadName)s] [%(filename)s:%(lineno)d:%(funcName)s]: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    
    # Console handler (standard output)
    console_stream = sys.stdout
    if hasattr(console_stream, "reconfigure"):
        try:
            console_stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    console_handler = logging.StreamHandler(console_stream)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Daily log file: logs/yyyy-mm-dd.log
    log_file = os.path.join(log_dir, f"{datetime.now():%Y-%m-%d}.log")
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    def handle_uncaught_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logger.critical("Uncaught exception", exc_info=(exc_type, exc_value, exc_traceback))

    sys.excepthook = handle_uncaught_exception
    logger.debug("Logger initialized: %s", log_file)
    logger.debug("Platform: %s", platform.platform())
    
    return logger
