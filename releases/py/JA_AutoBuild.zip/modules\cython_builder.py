import os
import shutil
import subprocess


IGNORED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "env",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    "build",
    "dist",
    "build_pyinstall",
    "build_pyinstaller",
    "build_nuitka",
}


def ensure_cython_dependencies(python_exe, project_dir, log_callback):
    return _run(
        [
            python_exe,
            "-m",
            "pip",
            "install",
            "cython",
            "setuptools",
            "wheel",
        ],
        project_dir,
        "Cài Cython/setuptools/wheel",
        log_callback,
    )


def prepare_cython_staging(project_dir, script_path, output_parent_dir, app_name, python_exe, log_callback):
    staging_root = os.path.join(output_parent_dir, "_cython_staging")
    staging_dir = os.path.join(staging_root, app_name)
    if os.path.exists(staging_dir):
        shutil.rmtree(staging_dir)
    os.makedirs(staging_root, exist_ok=True)

    project_abs = os.path.abspath(project_dir)
    output_abs = os.path.abspath(output_parent_dir)

    def ignore(src, names):
        ignored = set()
        for name in names:
            path = os.path.abspath(os.path.join(src, name))
            if name in IGNORED_DIRS or name.startswith(".nuitka"):
                ignored.add(name)
            elif path == output_abs or path.startswith(output_abs + os.sep):
                ignored.add(name)
        return ignored

    log_callback(f"[CYTHON] Tạo staging project: {staging_dir}\n")
    shutil.copytree(project_abs, staging_dir, ignore=ignore)

    rel_script = os.path.relpath(script_path, project_abs)
    staged_script = os.path.join(staging_dir, rel_script)
    modules_dir = os.path.join(staging_dir, "modules")
    module_files = _find_module_files(modules_dir)
    if not module_files:
        log_callback("[CYTHON] Không tìm thấy modules/*.py để biên dịch. Bỏ qua Cython.\n")
        return staged_script, staging_dir

    setup_path = os.path.join(staging_dir, "_cython_setup.py")
    _write_setup_file(setup_path, staging_dir, module_files)

    if not _run(
        [python_exe, setup_path, "build_ext", "--inplace"],
        staging_dir,
        "Biên dịch modules/*.py sang .pyd bằng Cython",
        log_callback,
    ):
        raise RuntimeError("Cython build failed.")

    for py_file in module_files:
        try:
            os.remove(py_file)
        except OSError:
            pass
        generated_c = os.path.splitext(py_file)[0] + ".c"
        if os.path.exists(generated_c):
            try:
                os.remove(generated_c)
            except OSError:
                pass

    for cleanup_name in ["_cython_setup.py", "build"]:
        cleanup_path = os.path.join(staging_dir, cleanup_name)
        if os.path.isdir(cleanup_path):
            shutil.rmtree(cleanup_path, ignore_errors=True)
        elif os.path.exists(cleanup_path):
            try:
                os.remove(cleanup_path)
            except OSError:
                pass

    log_callback(f"[CYTHON] Đã biên dịch {len(module_files)} module Python sang .pyd.\n")
    return staged_script, staging_dir


def _find_module_files(modules_dir):
    if not os.path.isdir(modules_dir):
        return []
    module_files = []
    for root, dirs, files in os.walk(modules_dir):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for filename in files:
            if not filename.endswith(".py") or filename == "__init__.py":
                continue
            module_files.append(os.path.join(root, filename))
    return module_files


def _write_setup_file(setup_path, staging_dir, module_files):
    lines = [
        "from setuptools import Extension, setup",
        "from Cython.Build import cythonize",
        "",
        "extensions = [",
    ]
    for path in module_files:
        rel = os.path.relpath(path, staging_dir)
        module_name = os.path.splitext(rel)[0].replace(os.sep, ".")
        rel_posix = rel.replace(os.sep, "/")
        lines.append(f"    Extension({module_name!r}, [{rel_posix!r}]),")
    lines.extend(
        [
            "]",
            "",
            "setup(",
            "    name='cythonized_project_modules',",
            "    ext_modules=cythonize(",
            "        extensions,",
            "        compiler_directives={'language_level': '3'},",
            "        annotate=False,",
            "    ),",
            ")",
            "",
        ]
    )
    with open(setup_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def _run(args, cwd, description, log_callback):
    log_callback(f"[CYTHON] {description}:\n{subprocess.list2cmdline(args)}\n")
    result = subprocess.run(
        args,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=900,
    )
    if result.stdout:
        log_callback(result.stdout)
    if result.returncode != 0:
        log_callback(f"[ERROR] {description} thất bại với mã lỗi: {result.returncode}\n")
        return False
    return True
