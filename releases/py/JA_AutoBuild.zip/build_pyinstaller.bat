@echo off
title JA Translate - PyInstaller Standalone Builder
color 0B
cls

echo ==============================================================================
echo             JA TRANSLATE - PREMIUM PYINSTALLER BUILDER
echo ==============================================================================
echo.
echo [*] Project Path: %~dp0
echo [*] Checking PyInstaller installation in local .venv...

set "VENV_DIR=%~dp0.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"

:: Force Python isolation for PyInstaller subprocesses to prevent user-site package DLL mismatches
set PYTHONNOUSERSITE=1

:: Verify virtual environment python
if not exist "%VENV_PY%" (
    color 0C
    echo [X] ERROR: Local virtual environment (.venv) not found!
    echo     Please run run.bat first to initialize it.
    echo.
    pause
    exit /b 1
)

:: Verify PyInstaller installation inside .venv
"%VENV_PY%" -s -m PyInstaller --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [*] PyInstaller is not installed in the virtual environment. Installing...
    "%VENV_PY%" -s -m pip install pyinstaller
    if %ERRORLEVEL% neq 0 (
        color 0C
        echo [X] ERROR: Failed to install PyInstaller!
        echo.
        pause
        exit /b 1
    )
)

echo [+] PyInstaller is ready! Version:
"%VENV_PY%" -s -m PyInstaller --version
echo.

:: Clean up old builds
echo [*] Cleaning up old build directories...
if exist "build" rd /s /q "build"
if exist "dist" rd /s /q "dist"
if exist "Python_Auto_Builder.spec" del /q "Python_Auto_Builder.spec"
echo [+] Clean complete!
echo.

echo [*] Starting PyInstaller Standalone packaging (onedir)...
echo     Bundling assets, icons, and hidden imports...
echo.

"%VENV_PY%" -s -m PyInstaller --name "Python_Auto_Builder" ^
    --noconfirm ^
    --onedir ^
    --windowed ^
    --icon="assets\images\icon.ico" ^
    --paths ".venv\Lib\site-packages" ^
    --add-data "assets;assets/" ^
    --hidden-import "BlurWindow" ^
    --hidden-import "darkdetect" ^
    --hidden-import "requests" ^
    --hidden-import "pypinyin" ^
    --hidden-import "PySide6" ^
    --hidden-import "PySide6.QtCore" ^
    --hidden-import "PySide6.QtWidgets" ^
    --hidden-import "PySide6.QtGui" ^
    --hidden-import "PySide6.QtNetwork" ^
    --hidden-import "BlurWindow.blurWindow" ^
    --hidden-import "modules.ui" ^
    --hidden-import "modules.logic" ^
    --hidden-import "modules.logger_config" ^
    --hidden-import "modules.utils" ^
    --hidden-import "modules.constants" ^
    --exclude-module tkinter ^
    --exclude-module matplotlib ^
    --exclude-module numpy ^
    --exclude-module pandas ^
    --exclude-module PyQt5 ^
    --exclude-module PyQt6 ^
    --exclude-module PySide6.QtWebEngine ^
    --exclude-module PySide6.QtWebEngineCore ^
    --exclude-module PySide6.QtWebEngineWidgets ^
    --exclude-module PySide6.Qt3DCore ^
    --exclude-module PySide6.QtSensors ^
    --exclude-module PySide6.QtMultimedia ^
    --exclude-module PySide6.QtSql ^
    main.py

if %ERRORLEVEL% neq 0 (
    color 0C
    echo.
    echo [X] ERROR: PyInstaller build failed! Please check the output logs above.
    echo.
    pause
    exit /b %ERRORLEVEL%
)

:: Finalizing build structure
echo.
echo [*] Finalizing build structure...
echo.
echo ==============================================================================
echo                       BUILD COMPLETED SUCCESSFULLY!
echo ==============================================================================
echo [+] Your standalone application is ready at:
echo     %~dp0dist\Python_Auto_Builder
echo.
echo [*] Opening output directory...
start "" "%~dp0dist\Python_Auto_Builder"
echo.
echo Press any key to exit.
pause >nul
exit /b 0
