@echo off
title JA AutoBuild - Nuitka Standalone C++ Builder
color 0B
cls

echo ==============================================================================
echo             JA AUTOBUILD - NUITKA C++ STANDALONE BUILDER
echo ==============================================================================
echo.
echo [*] Project Path: %~dp0
echo [*] Checking Nuitka installation in local .venv...

set "VENV_DIR=%~dp0.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"

:: Force Python isolation for Nuitka processes to prevent global package pollution
set PYTHONNOUSERSITE=1

:: Verify virtual environment python
if not exist "%VENV_PY%" (
    color 0C
    echo [X] ERROR: Local virtual environment (.venv) not found!
    echo     Please run run.bat first to initialize it.
    echo.
    pause
    exit /b 1
)

:: Verify Nuitka installation inside .venv
"%VENV_PY%" -s -m nuitka --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [*] Nuitka is not installed in the virtual environment. Installing...
    "%VENV_PY%" -s -m pip install nuitka
    if %ERRORLEVEL% neq 0 (
        color 0C
        echo [X] ERROR: Failed to install Nuitka!
        echo.
        pause
        exit /b 1
    )
)

echo [+] Nuitka is ready! Version info:
"%VENV_PY%" -s -m nuitka --version
echo.

:: Clean up old builds
echo [*] Cleaning up old build directories...
if exist "dist\main.dist"              rd /s /q "dist\main.dist"
if exist "dist\Python_Auto_Builder"    rd /s /q "dist\Python_Auto_Builder"
if exist "main.build"                  rd /s /q "main.build"
if exist "dist\main.build"             rd /s /q "dist\main.build"
echo [+] Clean complete!
echo.

echo ==============================================================================
echo [*] Starting Nuitka C++ Compilation...
echo     Mode: STANDALONE (onedir)
echo     This compiles Python code into native C++ machine code.
echo ==============================================================================
echo.

"%VENV_PY%" -s -m nuitka ^
    --standalone ^
    --assume-yes-for-downloads ^
    --enable-plugin=pyside6 ^
    --include-package=BlurWindow ^
    --include-package=darkdetect ^
    --include-package=modules ^
    --include-data-dir=assets=assets ^
    --windows-icon-from-ico=assets\images\icon.ico ^
    --windows-console-mode=disable ^
    --output-filename=Python_Auto_Builder.exe ^
    --output-dir=dist ^
    main.py

if %ERRORLEVEL% neq 0 (
    color 0C
    echo.
    echo [X] ERROR: Nuitka C++ compilation failed!
    echo.
    pause
    exit /b %ERRORLEVEL%
)

:: Rename the output folder to Python_Auto_Builder
echo.
echo [*] Finalizing build structure...
if exist "dist\main.dist" (
    move "dist\main.dist" "dist\Python_Auto_Builder"
    echo [+] Output directory renamed to: dist\Python_Auto_Builder
)

:: Copy runtime config files next to the .exe
echo [*] Copying runtime config files...
if exist "dist\Python_Auto_Builder" (
    if exist "config.ini" (
        copy /Y "config.ini" "dist\Python_Auto_Builder\config.ini" >nul
        echo [+] Copied: config.ini
    )
    if exist "config.json" (
        copy /Y "config.json" "dist\Python_Auto_Builder\config.json" >nul
        echo [+] Copied: config.json
    )
)

color 0A
echo.
echo ==============================================================================
echo                   NUITKA C++ BUILD COMPLETED SUCCESSFULLY!
echo ==============================================================================
echo [+] Your optimized native standalone application is ready at:
echo     %~dp0dist\Python_Auto_Builder
echo.
echo [*] Opening output directory...
start "" "%~dp0dist\Python_Auto_Builder"
echo.
echo Press any key to exit.
pause >nul
exit /b 0
