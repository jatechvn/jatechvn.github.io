import sys
import os
import ctypes

# 1. Windows taskbar icon grouping bypass
# Force Windows to see this as a standalone application on the taskbar instead of grouping it under python.exe
APP_USER_MODEL_ID = "JohnAlaa.PythonAutoBuilder.1.0"
if sys.platform == "win32":
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
    except Exception:
        pass

from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QIcon
from modules.utils import ensure_project_dirs, _app_base_dir
from modules.logger_config import setup_logger
from modules.ui import PythonAutoBuilderApp

def main():
    # Setup necessary workspace folders
    ensure_project_dirs()
    
    # Initialize logger
    logger = setup_logger()
    logger.debug("Startup argv: %s", sys.argv)
    logger.debug("Python executable: %s", sys.executable)
    logger.debug("Python version: %s", sys.version.replace("\n", " "))
    logger.debug("Working directory: %s", os.getcwd())
    logger.debug("Application directory: %s", _app_base_dir())
    logger.info("Initializing Johnny's Python Auto-Builder application...")
    
    app = QApplication(sys.argv)
    
    # Setup application icon — use _app_base_dir() to work in both source and Nuitka .exe
    icon_path = os.path.join(_app_base_dir(), "assets", "images", "icon.ico")
    if os.path.exists(icon_path):
        app_icon = QIcon(icon_path)
        app.setWindowIcon(app_icon)
        logger.info(f"Loaded icon from: {icon_path}")
    else:
        logger.warning(f"App icon not found at {icon_path}. Launching with system default icon.")
        
    window = PythonAutoBuilderApp()
    window.show()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
