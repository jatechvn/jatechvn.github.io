# Global Constants for Johnny's Python Auto-Builder

APP_ID = "JA_PYTHON_AUTO_BUILDER"
APP_NAME = "Johnny's Python Auto-Builder"
APP_VERSION = "1.0.0"
APP_USER_MODEL_ID = "JohnAlaa.PythonAutoBuilder.1.0"

# Styling & Theme constants (Liquid Glass & Modern Gradients)
ACCENT_CYAN = "#00d4ff"
ACCENT_GREEN = "#00ff9d"
ACCENT_PURPLE = "#b026ff"

LIGHT_THEME_ACCENT = "#0056ff"
DARK_THEME_ACCENT = "#00d4ff"

# Default libraries that are commonly excluded to optimize executable file sizes
DEFAULT_EXCLUSIONS = [
    "tkinter",
    "matplotlib",
    "numpy",
    "pandas",
    "scipy",
    "PyQt5",
    "PyQt6",
    "PySide6.QtWebEngine",
    "PySide6.QtWebEngineCore",
    "PySide6.QtWebEngineWidgets",
    "PySide6.Qt3DCore",
    "PySide6.QtSensors",
    "PySide6.QtMultimedia",
    "PySide6.QtSql",
    "PySide6.QtCharts",
    "PySide6.QtQml",
    "PySide6.QtQuick",
    "sqlite3"
]

# Preset options for PyInstaller hidden imports
DEFAULT_HIDDEN_IMPORTS = [
    "BlurWindow",
    "darkdetect",
    "requests",
    "PySide6"
]
