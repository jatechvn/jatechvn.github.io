import sys
import os
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QIcon
from modules.ui import TranslateApp

def main():
    app = QApplication(sys.argv)

    # Set App ID for Windows Taskbar Icon
    try:
        import ctypes
        myappid = 'ja.translate.lan.nim'
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
    except:
        pass

    # Set Window Icon if exists
    icon_path = os.path.join(os.path.dirname(__file__), "assets", "icon.ico")
    if os.path.exists(icon_path):
        app_icon = QIcon(icon_path)
        app.setWindowIcon(app_icon)

    window = TranslateApp()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
