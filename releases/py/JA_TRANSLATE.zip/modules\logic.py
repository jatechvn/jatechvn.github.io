from __future__ import annotations
import configparser
import json
import requests
import base64
import mimetypes
from pathlib import Path
from typing import Generator
from pypinyin import pinyin, Style
from .logger_config import setup_logger

logger = setup_logger(__name__)

def get_pinyin_offline(text: str) -> str:
    """Converts Chinese text to Pinyin with tone marks locally."""
    try:
        pinyin_list = pinyin(text, style=Style.TONE)
        return " ".join([item[0] for item in pinyin_list])
    except Exception as e:
        logger.error(f"Pinyin conversion error: {e}")
        return ""

def load_config(config_path: str = "config.ini"):
    config = configparser.ConfigParser()
    if config_path == "config.ini":
        current_dir = Path(__file__).resolve().parent.parent
        config_path = str(current_dir / "config.ini")
    config.read(config_path)
    
    proxy_config = {}
    if config.has_section("PROXY"):
        proxy_config = {
            "enabled": config.getboolean("PROXY", "enabled", fallback=False),
            "host": config.get("PROXY", "host", fallback=""),
            "port": config.get("PROXY", "port", fallback=""),
            "user": config.get("PROXY", "user", fallback=""),
            "pass": config.get("PROXY", "pass", fallback="")
        }
        
    return {
        "api_key": config.get("NVIDIA", "api_key", fallback=""),
        "api_base": config.get("NVIDIA", "api_base", fallback="https://integrate.api.nvidia.com/v1"),
        "model": config.get("NVIDIA", "model", fallback="meta/llama-3.1-405b-instruct"),
        "vision_model": config.get("NVIDIA", "vision_model", fallback="meta/llama-3.2-90b-vision-instruct"),
        "auto_translate_delay": config.getint("SETTINGS", "auto_translate_delay", fallback=0),
        "default_target_lang": config.get("SETTINGS", "default_target_lang", fallback="VN"),
        "proxy": proxy_config
    }

def translate_with_nvidia(
    text: str, 
    target_lang: str, 
    api_key: str, 
    model: str, 
    vision_model: str,
    source_lang: str = "Auto",
    image_paths: list[str] = None, 
    api_base: str = "https://integrate.api.nvidia.com/v1",
    is_pinyin_task: bool = False,
    proxy_settings: dict = None
) -> Generator[str, None, None]:
    
    invoke_url = f"{api_base}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "text/event-stream",
        "Content-Type": "application/json"
    }
    
    # Setup Proxy
    proxies = None
    if proxy_settings and proxy_settings.get("enabled"):
        host = proxy_settings.get("host")
        port = proxy_settings.get("port")
        user = proxy_settings.get("user")
        pwd = proxy_settings.get("pass")
        
        if host and port:
            proxy_url = f"http://{user}:{pwd}@{host}:{port}" if user and pwd else f"http://{host}:{port}"
            proxies = {
                "http": proxy_url,
                "https": proxy_url
            }
    
    if is_pinyin_task:
        system_content = "You are a Pinyin expert. For the given Chinese text, provide only the Pinyin with tone marks. Do not include the original Chinese or any explanations."
    else:
        lang_map = {"VN": "Vietnamese", "ENG": "English", "CN": "Chinese (Simplified)"}
        target_name = lang_map.get(target_lang, "Vietnamese")
        source_name = lang_map.get(source_lang, "Auto-detect")
        system_content = f"You are a professional translator. Translate from {source_name} to {target_name}. Maintain meaning and formatting. Only output the translation result."
    
    user_msg_content = []
    if text:
        user_msg_content.append({"type": "text", "text": text})
    
    # Only use images for the main translation task, not for pinyin task
    if image_paths and not is_pinyin_task:
        model = vision_model
        for image_path in image_paths:
            try:
                mime_type, _ = mimetypes.guess_type(image_path)
                if not mime_type: mime_type = "image/jpeg"
                with open(image_path, "rb") as image_file:
                    encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
                user_msg_content.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime_type};base64,{encoded_string}"}
                })
            except Exception as e:
                logger.error(f"Error reading image {image_path}: {e}")
                continue

    messages = [{"role": "system", "content": system_content}]
    
    if user_msg_content:
        if len(user_msg_content) == 1 and user_msg_content[0]["type"] == "text":
            messages.append({"role": "user", "content": user_msg_content[0]["text"]})
        else:
            messages.append({"role": "user", "content": user_msg_content})

    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.1,
        "top_p": 1.0,
        "max_tokens": 4096,
        "stream": True,
        "chat_template_kwargs": {"enable_thinking": False}
    }
    
    logger.info(f"Sending request to {invoke_url} with model: {model} (Proxy: {'Yes' if proxies else 'No'})")
    
    try:
        response = requests.post(invoke_url, headers=headers, json=payload, stream=True, timeout=180, proxies=proxies)
        
        if response.status_code != 200:
            logger.error(f"API Error ({response.status_code}): {response.text}")
            
        response.raise_for_status()
        
        for line in response.iter_lines():
            if line:
                decoded = line.decode("utf-8")
                if decoded.startswith("data: "): decoded = decoded[6:]
                if decoded == "[DONE]": break
                try:
                    data = json.loads(decoded)
                    choice = data.get("choices", [{}])[0]
                    delta = choice.get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        yield content
                except:
                    continue
    except Exception as e:
        logger.error(f"Request failed: {str(e)}", exc_info=True)
        yield f"Error: {str(e)}"
