import os
import re
import darkdetect
import configparser
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QTextEdit, QPushButton, QComboBox, QLabel, 
    QProgressBar, QMessageBox, QFrame, QGraphicsDropShadowEffect,
    QDialog, QLineEdit, QFormLayout
)
from PySide6.QtCore import Qt, QThread, Signal, QPoint, QEvent, QTimer
from PySide6.QtGui import QColor, QFont, QIcon, QTextCursor
from BlurWindow.blurWindow import GlobalBlur
from .logic import load_config, translate_with_nvidia, get_pinyin_offline, logger

class ProxyDialog(QDialog):
    def __init__(self, current_config, is_dark=True, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Proxy Settings")
        self.setFixedWidth(300)
        self.is_dark = is_dark
        self.init_ui(current_config)
        self.apply_style()
        self.validate_inputs()

    def init_ui(self, config):
        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.btn_enabled = QPushButton("Proxy Enabled" if config.get("enabled") else "Proxy Disabled")
        self.btn_enabled.setCheckable(True)
        self.btn_enabled.setChecked(config.get("enabled", False))
        self.btn_enabled.clicked.connect(self.toggle_proxy_text)
        
        self.host_input = QLineEdit(config.get("host", ""))
        self.port_input = QLineEdit(config.get("port", ""))
        self.user_input = QLineEdit(config.get("user", ""))
        self.pass_input = QLineEdit(config.get("pass", ""))
        self.pass_input.setEchoMode(QLineEdit.Password)

        # Connect signals for validation
        self.host_input.textChanged.connect(self.validate_inputs)
        self.port_input.textChanged.connect(self.validate_inputs)
        self.user_input.textChanged.connect(self.validate_inputs)
        self.pass_input.textChanged.connect(self.validate_inputs)

        form.addRow("Enable:", self.btn_enabled)
        form.addRow("Host:", self.host_input)
        form.addRow("Port:", self.port_input)
        form.addRow("Username:", self.user_input)
        form.addRow("Password:", self.pass_input)
        
        layout.addLayout(form)

        btn_box = QHBoxLayout()
        self.btn_save = QPushButton("Save")
        self.btn_save.clicked.connect(self.accept)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        btn_box.addWidget(self.btn_save)
        btn_box.addWidget(self.btn_cancel)
        layout.addLayout(btn_box)

    def validate_inputs(self):
        host = self.host_input.text().strip()
        port = self.port_input.text().strip()
        
        # Only host and port are strictly required for a proxy
        is_valid = all([host, port])
        
        self.btn_enabled.setEnabled(is_valid)
        self.btn_save.setEnabled(is_valid)

        if is_valid:
            if not self.btn_enabled.isChecked():
                self.btn_enabled.setChecked(True)
                self.btn_enabled.setText("Proxy Enabled")
        else:
            self.btn_enabled.setChecked(False)
            self.btn_enabled.setText("Proxy Disabled")

    def toggle_proxy_text(self):
        self.btn_enabled.setText("Proxy Enabled" if self.btn_enabled.isChecked() else "Proxy Disabled")

    def apply_style(self):
        bg = "#222" if self.is_dark else "#f0f0f0"
        fg = "white" if self.is_dark else "#333"
        input_bg = "rgba(255,255,255,0.1)" if self.is_dark else "white"
        
        self.setStyleSheet(f"""
            QDialog {{ background-color: {bg}; color: {fg}; }}
            QLabel {{ color: {fg}; font-weight: bold; }}
            QLineEdit {{ 
                background: {input_bg}; 
                color: {fg}; 
                border: 1px solid rgba(128,128,128,0.5); 
                border-radius: 5px; 
                padding: 5px; 
            }}
            QPushButton {{
                background-color: rgba(0, 212, 255, 0.2);
                color: {fg};
                border: 1px solid #00d4ff;
                border-radius: 5px;
                padding: 8px;
            }}
            QPushButton:hover {{ background-color: #00d4ff; color: white; }}
            QPushButton:disabled {{ 
                background-color: rgba(100, 100, 100, 0.2); 
                color: rgba(150, 150, 150, 0.5);
                border: 1px solid rgba(100, 100, 100, 0.3);
            }}
        """)

    def get_settings(self):
        return {
            "enabled": self.btn_enabled.isChecked(),
            "host": self.host_input.text().strip(),
            "port": self.port_input.text().strip(),
            "user": self.user_input.text().strip(),
            "pass": self.pass_input.text().strip()
        }

class TranslationThread(QThread):
    chunk_received = Signal(str)
    finished = Signal(str)
    error = Signal(str)

    def __init__(self, text, source_lang, target_lang, config, image_paths=None):
        super().__init__()
        self.text = text
        self.source_lang = source_lang
        self.target_lang = target_lang
        self.config = config
        self.image_paths = image_paths
        self.full_result = ""

    def run(self):
        try:
            generator = translate_with_nvidia(
                text=self.text,
                source_lang=self.source_lang,
                target_lang=self.target_lang,
                api_key=self.config["api_key"],
                model=self.config["model"],
                vision_model=self.config["vision_model"],
                image_paths=self.image_paths,
                api_base=self.config["api_base"],
                proxy_settings=self.config.get("proxy")
            )
            for chunk in generator:
                self.full_result += chunk
                self.chunk_received.emit(chunk)
            self.finished.emit(self.full_result)
        except Exception as e:
            self.error.emit(str(e))

class PinyinThread(QThread):
    chunk_received = Signal(str)
    finished = Signal()

    def __init__(self, text, config):
        super().__init__()
        self.text = text
        self.config = config

    def run(self):
        try:
            result = get_pinyin_offline(self.text)
            if result:
                self.chunk_received.emit(result)
            self.finished.emit()
        except Exception as e:
            logger.error(f"Pinyin thread error: {e}")
            self.finished.emit()

class LiquidButton(QPushButton):
    def __init__(self, text, parent=None, accent=False, is_dark=True):
        super().__init__(text, parent)
        self.accent = accent
        self.is_dark = is_dark
        self.apply_style()

    def set_theme(self, is_dark):
        self.is_dark = is_dark
        self.apply_style()

    def apply_style(self):
        if self.accent:
            bg = "rgba(0, 212, 255, 0.8)"
            color = "white"
        else:
            bg = "rgba(255, 255, 255, 0.1)" if self.is_dark else "rgba(0, 0, 0, 0.05)"
            color = "white" if self.is_dark else "#333333"

        border = "rgba(255, 255, 255, 0.2)" if self.is_dark else "rgba(0, 0, 0, 0.1)"

        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg};
                color: {color};
                border: 1px solid {border};
                border-radius: 10px;
                padding: 6px 14px;
                font-family: 'Inter';
                font-weight: bold;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: rgba(0, 212, 255, 0.9);
                color: white;
                border: 1px solid #00d4ff;
            }}
            QPushButton:disabled {{
                background-color: rgba(100, 100, 100, 0.2);
                color: rgba(150, 150, 150, 0.4);
            }}
            QPushButton:checked {{
                background-color: #00d4ff;
                color: white;
                border: 2px solid {"white" if self.is_dark else "#00d4ff"};
            }}
        """)

class CopyButton(QPushButton):
    def __init__(self, target_editor, is_dark=True):
        super().__init__("📋", target_editor)
        self.target_editor = target_editor
        self.is_dark = is_dark
        self.setFixedSize(32, 32)
        self.setCursor(Qt.PointingHandCursor)
        self.apply_style()
        self.clicked.connect(self.copy_text)
        
        # Overlay logic
        self.target_editor.installEventFilter(self)
        self.target_editor.verticalScrollBar().rangeChanged.connect(self.update_position)
        self.update_position()

    def eventFilter(self, obj, event):
        if obj == self.target_editor and event.type() == QEvent.Resize:
            self.update_position()
        return super().eventFilter(obj, event)

    def update_position(self):
        margin = 8
        w = self.target_editor.width()
        scrollbar_w = 0
        if self.target_editor.verticalScrollBar().isVisible():
            scrollbar_w = self.target_editor.verticalScrollBar().width()
        self.move(w - self.width() - margin - scrollbar_w, margin)

    def set_theme(self, is_dark):
        self.is_dark = is_dark
        self.apply_style()

    def apply_style(self):
        bg = "rgba(255, 255, 255, 0.05)" if self.is_dark else "rgba(0, 0, 0, 0.03)"
        hover_bg = "rgba(255, 255, 255, 0.5)" if self.is_dark else "rgba(0, 0, 0, 0.2)"
        color = "white" if self.is_dark else "#333333"
        hover_color = "black" if not self.is_dark else "white"
        border = "rgba(255, 255, 255, 0.1)" if self.is_dark else "rgba(0, 0, 0, 0.05)"
        
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg};
                color: {color};
                border: 1px solid {border};
                border-radius: 8px;
                font-size: 15px;
            }}
            QPushButton:hover {{
                background-color: {hover_bg};
                color: {hover_color};
                border: 1px solid #00d4ff;
            }}
        """)

    def copy_text(self):
        full_text = self.target_editor.toPlainText()
        if "Pinyin:" in full_text:
            text_to_copy = full_text.split("Pinyin:")[0].strip()
        else:
            text_to_copy = full_text.strip()
            
        if text_to_copy:
            from PySide6.QtWidgets import QApplication
            clipboard = QApplication.clipboard()
            clipboard.setText(text_to_copy)
            self.setText("✅")
            QTimer.singleShot(1000, lambda: self.setText("📋"))

class TranslateApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("JA Translate")
        self.resize(1000, 750)
        
        self.is_dark = darkdetect.isDark()
        # Giữ frameless nhưng vẫn là cửa sổ chuẩn để taskbar có thể toggle ẩn/hiện
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.WindowMinMaxButtonsHint | Qt.WindowSystemMenuHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        self.config = load_config()
        self.attached_images = []
        self._main_response_html = ""
        self._pinyin_response_html = ""
        self._drag_pos = QPoint()
        self.thread = None
        self.pinyin_thread = None
        
        self.auto_translate_timer = QTimer(self)
        self.auto_translate_timer.setSingleShot(True)
        self.auto_translate_timer.timeout.connect(self.start_translation)
        
        self.init_ui()
        self.apply_theme()

    def add_shadow(self, widget, color=None, radius=15):
        if color is None:
            color = QColor(0, 0, 0, 180) if self.is_dark else QColor(0, 0, 0, 60)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(radius)
        shadow.setColor(color)
        shadow.setOffset(2, 2)
        widget.setGraphicsEffect(shadow)

    def init_ui(self):
        self.central_widget = QFrame()
        self.central_widget.setObjectName("CentralWidget")
        self.setCentralWidget(self.central_widget)
        
        layout = QVBoxLayout(self.central_widget)
        layout.setContentsMargins(20, 15, 20, 20)

        # Title Bar
        title_bar = QHBoxLayout()

        # macOS style buttons on the left: Red (Close), Yellow (Min), Green (Max)
        self.close_btn = QPushButton("")
        self.close_btn.setObjectName("CloseBtn")
        self.close_btn.setFixedSize(16, 16)
        self.close_btn.clicked.connect(self.close)
        self.close_btn.setToolTip("Close")

        self.min_btn = QPushButton("")
        self.min_btn.setObjectName("MinBtn")
        self.min_btn.setFixedSize(16, 16)
        self.min_btn.clicked.connect(self.showMinimized)
        self.min_btn.setToolTip("Minimize")

        self.max_btn = QPushButton("")
        self.max_btn.setObjectName("MaxBtn")
        self.max_btn.setFixedSize(16, 16)
        self.max_btn.clicked.connect(self.toggle_maximize)
        self.max_btn.setToolTip("Maximize/Restore")

        title_bar.addWidget(self.close_btn)
        title_bar.addSpacing(2)
        title_bar.addWidget(self.min_btn)
        title_bar.addSpacing(2)
        title_bar.addWidget(self.max_btn)
        title_bar.addSpacing(12)

        self.lbl_title = QLabel("JA TRANSLATE • LIQUID GLASS")
        self.add_shadow(self.lbl_title)
        title_bar.addWidget(self.lbl_title)
        title_bar.addStretch()
        
        # Proxy Button
        self.btn_proxy = QPushButton("🌐 PROXY")
        self.btn_proxy.setFixedHeight(30)
        self.btn_proxy.setCursor(Qt.PointingHandCursor)
        self.btn_proxy.clicked.connect(self.open_proxy_settings)
        title_bar.addWidget(self.btn_proxy)
        
        title_bar.addSpacing(10)

        # Theme Toggle Button
        self.btn_theme = QPushButton()
        self.btn_theme.setFixedHeight(30)
        self.btn_theme.setCursor(Qt.PointingHandCursor)
        self.btn_theme.clicked.connect(self.toggle_theme)
        title_bar.addWidget(self.btn_theme)

        layout.addLayout(title_bar)

        # Language Selection Panel
        lang_panel = QHBoxLayout()
        lang_panel.setSpacing(15)
        
        src_group = QVBoxLayout()
        self.src_label = QLabel("SOURCE")
        self.add_shadow(self.src_label)
        self.src_langs = QHBoxLayout()
        self.src_buttons = {}
        for code in ["Auto", "VN", "ENG", "CN"]:
            btn = LiquidButton(code, is_dark=self.is_dark)
            btn.setCheckable(True)
            if code == "Auto": btn.setChecked(True)
            btn.clicked.connect(self.on_src_lang_changed)
            self.src_buttons[code] = btn
            self.src_langs.addWidget(btn)
        src_group.addWidget(self.src_label)
        src_group.addLayout(self.src_langs)
        
        self.spacer = QLabel("➜")
        
        tgt_group = QVBoxLayout()
        self.tgt_label = QLabel("TARGET")
        self.add_shadow(self.tgt_label)
        default_tgt = self.config.get("default_target_lang", "VN")
        self.tgt_langs = QHBoxLayout()
        self.tgt_buttons = {}
        for code in ["VN", "ENG", "CN"]:
            btn = LiquidButton(code, is_dark=self.is_dark)
            btn.setCheckable(True)
            if code == default_tgt: btn.setChecked(True)
            btn.clicked.connect(self.on_tgt_lang_changed)
            self.tgt_buttons[code] = btn
            self.tgt_langs.addWidget(btn)
        tgt_group.addWidget(self.tgt_label)
        tgt_group.addLayout(self.tgt_langs)
        
        lang_panel.addLayout(src_group)
        lang_panel.addWidget(self.spacer)
        lang_panel.addLayout(tgt_group)
        lang_panel.addStretch()
        
        self.btn_clear = LiquidButton("CLEAR", is_dark=self.is_dark)
        self.btn_clear.clicked.connect(self.clear_all)
        lang_panel.addWidget(self.btn_clear)
        layout.addLayout(lang_panel)

        # Editor Area
        text_layout = QHBoxLayout()
        text_layout.setSpacing(20)
        
        input_container = QVBoxLayout()
        self.lbl_in_title = QLabel("INPUT")
        self.input_text = QTextEdit()
        self.input_text.setPlaceholderText("Paste text or drag images here...")
        self.btn_copy_in = CopyButton(self.input_text, is_dark=self.is_dark)
        
        input_container.addWidget(self.lbl_in_title)
        input_container.addWidget(self.input_text)
        text_layout.addLayout(input_container)
        
        output_container = QVBoxLayout()
        self.lbl_out_title = QLabel("RESULT")
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.btn_copy_out = CopyButton(self.output_text, is_dark=self.is_dark)
        
        output_container.addWidget(self.lbl_out_title)
        output_container.addWidget(self.output_text)
        text_layout.addLayout(output_container)
        layout.addLayout(text_layout)

        # Bottom Bar
        self.lbl_status = QLabel("Ready")
        layout.addWidget(self.lbl_status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.hide()
        layout.addWidget(self.progress_bar)

        self.btn_translate = LiquidButton("START TRANSLATION", accent=True, is_dark=self.is_dark)
        self.btn_translate.setFixedHeight(50)
        self.btn_translate.clicked.connect(self.start_translation)
        layout.addWidget(self.btn_translate)

        self.input_text.installEventFilter(self)
        self.input_text.textChanged.connect(self.on_text_changed)

    def open_proxy_settings(self):
        dialog = ProxyDialog(self.config.get("proxy", {}), is_dark=self.is_dark, parent=self)
        if dialog.exec():
            new_proxy = dialog.get_settings()
            self.config["proxy"] = new_proxy
            
            # Save to config.ini
            ini = configparser.ConfigParser()
            ini_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.ini")
            ini.read(ini_path)
            if not ini.has_section("PROXY"): ini.add_section("PROXY")
            ini.set("PROXY", "enabled", str(new_proxy["enabled"]))
            ini.set("PROXY", "host", new_proxy["host"])
            ini.set("PROXY", "port", new_proxy["port"])
            ini.set("PROXY", "user", new_proxy["user"])
            ini.set("PROXY", "pass", new_proxy["pass"])
            with open(ini_path, "w") as f:
                ini.write(f)
            
            self.lbl_status.setText(f"PROXY UPDATED: {'ENABLED' if new_proxy['enabled'] else 'DISABLED'}")

    def on_text_changed(self):
        if not self.btn_translate.isEnabled(): return
        delay = self.config.get("auto_translate_delay", 0)
        if delay > 0: self.auto_translate_timer.start(delay * 1000)

    def eventFilter(self, obj, event):
        if obj is self.input_text and event.type() == QEvent.KeyPress:
            if event.key() in (Qt.Key_Return, Qt.Key_Enter) and event.modifiers() & Qt.ControlModifier:
                if self.btn_translate.isEnabled():
                    self.start_translation()
                return True
        return super().eventFilter(obj, event)

    def apply_theme(self):
        if self.is_dark:
            bg_main = "rgba(20, 20, 20, 0.65)"
            text_main = "white"
            input_bg = "rgba(0, 0, 0, 0.4)"
            output_bg = "rgba(0, 0, 0, 0.2)"
            border = "rgba(255, 255, 255, 0.2)"
            self.btn_theme.setText("🌙 DARK")
        else:
            bg_main = "rgba(245, 245, 245, 0.75)"
            text_main = "#111111"
            input_bg = "rgba(255, 255, 255, 0.6)"
            output_bg = "rgba(255, 255, 255, 0.4)"
            border = "rgba(0, 0, 0, 0.15)"
            self.btn_theme.setText("☀️ LIGHT")

        btn_style = f"""
            QPushButton {{
                color: {text_main}; background: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.1); 
                border-radius: 10px; font-size: 11px; font-weight: bold; padding: 0 10px;
            }}
            QPushButton:hover {{ background: rgba({('255,255,255' if self.is_dark else '0,0,0')},0.2); }}
        """
        self.btn_theme.setStyleSheet(btn_style)
        self.btn_proxy.setStyleSheet(btn_style)

        try:
            GlobalBlur(self.winId(), Dark=self.is_dark)
        except Exception as e:
            logger.warning(f"BlurWindow initialization failed: {e}")

        self.central_widget.setStyleSheet(f"#CentralWidget {{ background-color: {bg_main}; border: 1px solid {border}; border-radius: 15px; }}")

        label_style = f"color: {text_main}; font-family: 'Inter';"
        self.lbl_title.setStyleSheet(label_style + "font-weight: 800; font-size: 14px; letter-spacing: 2px;")
        self.src_label.setStyleSheet("color: #00d4ff; font-weight: bold; font-size: 10px;")
        self.tgt_label.setStyleSheet("color: #00ff9d; font-weight: bold; font-size: 10px;")
        self.spacer.setStyleSheet(f"color: {text_main if not self.is_dark else 'rgba(255,255,255,0.3)'}; font-size: 20px;")
        self.lbl_in_title.setStyleSheet(f"color: {text_main}; opacity: 0.5; font-weight: bold; font-size: 10px;")
        self.lbl_out_title.setStyleSheet(f"color: {text_main}; opacity: 0.5; font-weight: bold; font-size: 10px;")
        self.lbl_status.setStyleSheet(f"color: {text_main}; opacity: 0.4; font-size: 11px;")

        editor_base = f"color: {text_main}; border: 1px solid {border}; border-radius: 12px; padding: 12px;"
        self.input_text.setStyleSheet(f"QTextEdit {{ background-color: {input_bg}; {editor_base} font-family: 'JetBrains Mono'; font-size: 14px; }}")
        self.output_text.setStyleSheet(f"QTextEdit {{ background-color: {output_bg}; {editor_base} font-family: 'Segoe UI'; font-size: 15px; }}")

        for btn in list(self.src_buttons.values()) + list(self.tgt_buttons.values()) + [self.btn_clear, self.btn_translate, self.btn_copy_in, self.btn_copy_out]:
            btn.set_theme(self.is_dark)

        self.setStyleSheet(f"QProgressBar {{ background: transparent; border: none; }} QProgressBar::chunk {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00d4ff, stop:1 #00ff9d); border-radius: 2px; }}")

        # macOS buttons style
        mac_btn_qss = """
            QPushButton#CloseBtn {
                background-color: #ff5f56;
                border: 1px solid #e0443e;
                border-radius: 8px;
            }
            QPushButton#CloseBtn:hover {
                background-color: #ff7b72;
            }
            QPushButton#MinBtn {
                background-color: #ffbd2e;
                border: 1px solid #dea123;
                border-radius: 8px;
            }
            QPushButton#MinBtn:hover {
                background-color: #ffca52;
            }
            QPushButton#MaxBtn {
                background-color: #27c93f;
                border: 1px solid #1aab29;
                border-radius: 8px;
            }
            QPushButton#MaxBtn:hover {
                background-color: #38e04f;
            }
        """
        self.setStyleSheet(self.styleSheet() + mac_btn_qss)

    def toggle_theme(self):
        self.is_dark = not self.is_dark
        self.apply_theme()

    def toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def on_src_lang_changed(self):
        clicked_btn = self.sender()
        src_code = ""
        for code, btn in self.src_buttons.items():
            is_clicked = (btn == clicked_btn)
            btn.setChecked(is_clicked)
            if is_clicked: src_code = code
        if src_code == "Auto": return
        current_tgt = self.get_current_tgt_lang()
        if src_code == current_tgt:
            new_tgt = "VN" if src_code != "VN" else "CN"
            for code, btn in self.tgt_buttons.items(): btn.setChecked(code == new_tgt)

    def on_tgt_lang_changed(self):
        clicked_btn = self.sender()
        tgt_code = ""
        for code, btn in self.tgt_buttons.items():
            is_clicked = (btn == clicked_btn)
            btn.setChecked(is_clicked)
            if is_clicked: tgt_code = code
        current_src = self.get_current_src_lang()
        if tgt_code == current_src:
            new_src = "Auto"
            for code, btn in self.src_buttons.items(): btn.setChecked(code == new_src)

    def get_current_src_lang(self):
        for code, btn in self.src_buttons.items():
            if btn.isChecked(): return code
        return "Auto"

    def get_current_tgt_lang(self):
        for code, btn in self.tgt_buttons.items():
            if btn.isChecked(): return code
        return "VN"

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            child = self.childAt(event.position().toPoint())
            if not child or isinstance(child, (QLabel, QFrame)) or child.objectName() == "CentralWidget":
                self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self._drag_pos.isNull():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        self._drag_pos = QPoint()
        event.accept()

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()

    def dropEvent(self, event):
        files = [u.toLocalFile() for u in event.mimeData().urls()]
        image_exts = ('.png', '.jpg', '.jpeg', '.webp', '.bmp')
        new_images = [f for f in files if f.lower().endswith(image_exts)]
        if new_images:
            self.attached_images.extend(new_images)
            self.lbl_status.setText(f"ATTACHED {len(self.attached_images)} IMAGES")

    def clear_all(self):
        self.input_text.clear()
        self.output_text.clear()
        self.attached_images = []
        self._main_response_html = ""
        self._pinyin_response_html = ""
        self.lbl_status.setText("READY")

    def start_translation(self):
        if not self.btn_translate.isEnabled(): return
        if self.thread and self.thread.isRunning(): return
        
        text = self.input_text.toPlainText().strip()
        if not text and not self.attached_images: return
        self.auto_translate_timer.stop()
        
        if hasattr(self, '_original_input_html'):
            del self._original_input_html
            
        self.btn_translate.setEnabled(False)
        self.output_text.clear()
        self._main_response_html = ""
        self._pinyin_response_html = ""
        self.progress_bar.show()
        self.progress_bar.setRange(0, 0)
        self.lbl_status.setText("THINKING...")
        self.thread = TranslationThread(text, self.get_current_src_lang(), self.get_current_tgt_lang(), self.config, self.attached_images)
        self.thread.chunk_received.connect(self.on_main_chunk)
        self.thread.finished.connect(self.on_main_finished)
        self.thread.error.connect(self.on_error)
        self.thread.start()

    def on_main_chunk(self, chunk):
        self._main_response_html += chunk.replace("\n", "<br>")
        cursor = self.output_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        cursor.insertHtml(chunk.replace("\n", "<br>"))
        self.output_text.verticalScrollBar().setValue(self.output_text.verticalScrollBar().maximum())

    def on_main_finished(self, full_result):
        self.lbl_status.setText("PROCESSING PINYIN...")
        chinese_pattern = re.compile(r'[\u4e00-\u9fff]')
        source_text = self.input_text.toPlainText()
        
        self.pinyin_target = ""
        text_to_pinyin = ""
        
        if chinese_pattern.search(source_text):
            text_to_pinyin = source_text
            self.pinyin_target = "input"
        elif chinese_pattern.search(full_result):
            text_to_pinyin = full_result
            self.pinyin_target = "output"
            
        if text_to_pinyin:
            self._pinyin_response_html = f"<br><br><b style='color: #00d4ff;'>Pinyin:</b><br>"
            self.pinyin_thread = PinyinThread(text_to_pinyin, self.config)
            self.pinyin_thread.chunk_received.connect(self.on_pinyin_chunk)
            self.pinyin_thread.finished.connect(self.on_all_finished)
            self.pinyin_thread.start()
        else: self.on_all_finished()

    def on_pinyin_chunk(self, chunk):
        color = "rgba(255,255,255,0.4)" if self.is_dark else "rgba(0,0,0,0.5)"
        self._pinyin_response_html += f"<span style='color: {color}; font-style: italic;'>{chunk}</span>"
        
        if getattr(self, 'pinyin_target', 'output') == "input":
            source_html = self.input_text.toPlainText().replace("\n", "<br>")
            if not hasattr(self, '_original_input_html'):
                self._original_input_html = source_html
            
            self.input_text.blockSignals(True)
            self.input_text.setHtml(self._original_input_html + self._pinyin_response_html)
            self.input_text.blockSignals(False)
            self.input_text.verticalScrollBar().setValue(self.input_text.verticalScrollBar().maximum())
        else:
            self.output_text.setHtml(self._main_response_html + self._pinyin_response_html)

    def on_all_finished(self):
        self.btn_translate.setEnabled(True)
        self.progress_bar.hide()
        self.lbl_status.setText("COMPLETE")
        self.attached_images = []
        if hasattr(self, '_original_input_html'):
            del self._original_input_html
        if hasattr(self, 'pinyin_target'):
            del self.pinyin_target

    def on_error(self, message):
        self.btn_translate.setEnabled(True)
        self.progress_bar.hide()
        QMessageBox.critical(self, "Error", message)
